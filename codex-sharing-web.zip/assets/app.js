"use strict";

const api = Object.freeze({
  me: "/api/v1/me",
  persons: "/api/v1/admin/persons",
  profiles: "/api/v1/admin/profiles",
  grants: "/api/v1/admin/grants",
  leases: "/api/v1/admin/leases",
  audit: "/api/v1/admin/audit-events"
});

const state = {
  view: "dashboard",
  selectedProfileId: null,
  viewRevision: 0,
  dashboardRevision: 0,
  dashboardLoading: false,
  dashboard: { mode: "table", sortKey: "rate", sortDir: "desc", statuses: new Set(), buckets: new Set(), updatedAt: null },
  usage: new Map(),
  chart: null,
  // 詳情頁每日使用量：daily 為 API 回傳的原始列，range 為目前選取的統計區間（跨帳號沿用）。
  detail: { daily: [], range: "30d" },
  persons: [],
  personIndex: new Map(),
  profiles: [],
  grants: [],
  leases: [],
  audit: []
};

class AdminApiError extends Error {
  constructor(code, correlationId, status) {
    super(code);
    this.name = "AdminApiError";
    this.code = code;
    this.correlationId = correlationId;
    this.status = status;
  }
}

const byId = id => document.getElementById(id);

function requestCorrelationId() {
  return globalThis.crypto?.randomUUID?.() ?? `web-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

async function requestJson(path, options = {}) {
  const correlationId = requestCorrelationId();
  const requestOptions = {
    method: options.method ?? "GET",
    headers: {
      Accept: "application/json",
      "X-Correlation-ID": correlationId
    },
    cache: "no-store"
  };
  if (options.body !== undefined) {
    requestOptions.headers["Content-Type"] = "application/json";
    requestOptions.body = JSON.stringify(options.body);
  }

  let response;
  try {
    response = await fetch(path, requestOptions);
  } catch {
    throw new AdminApiError("BACKEND_UNAVAILABLE", correlationId, 0);
  }

  const responseCorrelationId = response.headers.get("X-Correlation-ID") ?? correlationId;
  if (!response.ok) {
    let code = `HTTP_${response.status}`;
    try {
      const error = await response.json();
      if (typeof error?.code === "string" && error.code.length <= 80) {
        code = error.code;
      }
    } catch {
    }
    throw new AdminApiError(code, responseCorrelationId, response.status);
  }
  if (response.status === 204) {
    return null;
  }
  try {
    return await response.json();
  } catch {
    throw new AdminApiError("ADMIN_RESPONSE_INVALID", responseCorrelationId, response.status);
  }
}

function requireArray(value) {
  if (!Array.isArray(value)) {
    throw new AdminApiError("ADMIN_RESPONSE_INVALID", requestCorrelationId(), 200);
  }
  return value;
}

function errorText(error) {
  if (!(error instanceof AdminApiError)) {
    return "操作失敗。請重新整理後再試一次。";
  }
  const labels = {
    BACKEND_UNAVAILABLE: "無法連線伺服器。",
    ADMIN_ACCESS_DENIED: "目前身分不是管理者（ADMIN）。",
    PERSON_ACCESS_DENIED: "目前來源 IP 沒有有效的人員使用權。",
    PERSON_IP_CONFLICT: "此 IP 位址已由其他人員使用。",
    PERSON_NOT_FOUND: "找不到指定的人員。",
    VALIDATION_REQUIRED: "有必填欄位未填寫。",
    FORCE_RELEASE_REASON_REQUIRED: "強制釋放必須填寫原因。",
    ADMIN_RESPONSE_INVALID: "伺服器回應格式不相容。"
  };
  const message = labels[error.code] ?? `伺服器拒絕操作（錯誤代碼 ${error.code}）。`;
  return `${message}\n追蹤編號（Correlation ID）：${error.correlationId}`;
}

function setGlobalMessage(message) {
  const element = byId("global-message");
  element.textContent = message;
  element.hidden = !message;
}

function setSectionMessage(section, message, kind = "") {
  const element = byId(`${section}-message`);
  element.textContent = message;
  element.className = `section-message ${kind}`.trim();
}

async function runSection(section, operation, { quiet = false } = {}) {
  const revision = state.viewRevision;
  setSectionMessage(section, quiet ? "" : "載入中…");
  try {
    await operation();
    if (revision === state.viewRevision && !quiet) setSectionMessage(section, "已更新", "success");
  } catch (error) {
    if (revision === state.viewRevision) setSectionMessage(section, errorText(error), "error");
  }
}

function formatValue(value) {
  if (value === null || value === undefined || value === "") return "—";
  if (typeof value === "boolean") return value ? "是" : "否";
  return String(value);
}

function cell(value) {
  const element = document.createElement("td");
  element.textContent = formatValue(value);
  return element;
}

function button(label, action, className = "btn btn-secondary") {
  const element = document.createElement("button");
  element.type = "button";
  element.className = className;
  element.textContent = label;
  element.addEventListener("click", action);
  return element;
}

function icon(name, className = "icon") {
  const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute("class", className);
  svg.setAttribute("aria-hidden", "true");
  const use = document.createElementNS("http://www.w3.org/2000/svg", "use");
  use.setAttribute("href", `#icon-${name}`);
  svg.append(use);
  return svg;
}

function initials(name) {
  const text = String(name ?? "").trim();
  if (!text) return "?";
  if (/[\u3400-\u9fff]/.test(text)) return text.length > 2 ? text.slice(-2) : text;
  const words = text.split(/\s+/).filter(Boolean);
  return words.slice(0, 2).map(word => word[0].toUpperCase()).join("") || text.slice(0, 2).toUpperCase();
}

const tooltip = {
  element: null,
  target: null,
  show(target) {
    const text = target.dataset.tip;
    if (!text) return;
    if (!this.element) {
      this.element = document.createElement("div");
      this.element.className = "tooltip";
      this.element.setAttribute("role", "tooltip");
      document.body.append(this.element);
    }
    this.target = target;
    this.element.textContent = text;
    this.element.classList.add("is-visible");
    const rect = target.getBoundingClientRect();
    const tip = this.element.getBoundingClientRect();
    let left = rect.left + rect.width / 2 - tip.width / 2;
    left = Math.max(8, Math.min(left, window.innerWidth - tip.width - 8));
    let top = rect.top - tip.height - 8;
    if (top < 8) top = rect.bottom + 8;
    this.element.style.left = `${left}px`;
    this.element.style.top = `${top}px`;
  },
  hide(target) {
    if (target && target !== this.target) return;
    this.target = null;
    this.element?.classList.remove("is-visible");
  }
};

function setPopoverOpen(open) {
  byId("identity-popover").hidden = !open;
  byId("avatar-button").setAttribute("aria-expanded", String(open));
}

// 清單工具列的篩選選單。
function setFilterMenuOpen(open) {
  byId("filter-popover").hidden = !open;
  byId("filter-toggle").setAttribute("aria-expanded", String(open));
}

// ------------------------------------------------------------------
// 表單欄位驗證：欄位 blur 後才顯示錯誤，之後每次輸入即時更新；送出時全部檢查並停在第一個錯誤欄位。
// 日期欄位的格式與先後檢查由 datetimeField 以 setCustomValidity 提供，這裡只負責統一呈現。
// ------------------------------------------------------------------
const IPV4_PATTERN = /^(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)$/;

function isIpAddress(value) {
  if (IPV4_PATTERN.test(value)) return true;
  if (!value.includes(":")) return false;
  // WHATWG URL 解析器內建 IPv6 驗證，不必手寫 regex。
  try {
    new URL(`http://[${value}]/`);
    return true;
  } catch {
    return false;
  }
}

const FIELD_VALIDATORS = Object.freeze({
  ip: value => (isIpAddress(value) ? "" : "IP 位址格式不正確，例：10.0.0.20 或 2001:db8::1")
});
const FIELD_SELECTOR = "input:not([type=hidden]):not([type=checkbox]), select";

function fieldMessage(field) {
  if (field.disabled) return "";
  if (field.validity.valueMissing) return field.tagName === "SELECT" ? "請選擇" : "此欄位必填";
  if (field.validity.customError) return field.validationMessage;
  if (!field.validity.valid) return "輸入內容不符合格式";
  const validator = FIELD_VALIDATORS[field.dataset.validate];
  return validator ? validator(field.value.trim()) : "";
}

function setFieldError(field, message) {
  const error = field.closest(".field")?.querySelector(".field-error");
  if (error) {
    error.textContent = message;
    error.hidden = !message;
  }
  if (message) field.setAttribute("aria-invalid", "true");
  else field.removeAttribute("aria-invalid");
}

function validateField(field) {
  const message = fieldMessage(field);
  setFieldError(field, message);
  return !message;
}

// 只重驗已 touched 的欄位；日期先後互相牽動，所以任一欄位變動都整份重驗。
function revalidateForm(form) {
  for (const field of form.querySelectorAll(FIELD_SELECTOR)) if (field.dataset.touched) validateField(field);
}

function validateForm(form) {
  let firstInvalid = null;
  for (const field of form.querySelectorAll(FIELD_SELECTOR)) {
    field.dataset.touched = "true";
    if (!validateField(field) && !firstInvalid) firstInvalid = field;
  }
  firstInvalid?.focus();
  return firstInvalid === null;
}

// 表單層級的錯誤（API 拒絕等）顯示在 drawer 底部，表單維持開啟讓使用者修正後重試。
function setFormError(form, message) {
  const error = form.querySelector(".form-error");
  error.replaceChildren();
  if (message) error.append(icon("alert-circle", "icon icon-sm"), document.createTextNode(message));
  error.hidden = !message;
}

// 儲存中：送出與關閉按鈕停用、送出鈕前置旋轉圖示；requestCloseDrawer 也會因 aria-busy 拒絕關閉。
function setFormBusy(form, busy) {
  form.setAttribute("aria-busy", String(busy));
  for (const control of form.querySelectorAll("button[type=submit], [data-drawer-close]")) control.disabled = busy;
  const submit = form.querySelector("button[type=submit]");
  submit.querySelector(".is-spinning")?.remove();
  if (busy) submit.prepend(icon("refresh", "icon icon-sm is-spinning"));
}

function clearFormErrors(form) {
  for (const field of form.querySelectorAll(FIELD_SELECTOR)) {
    delete field.dataset.touched;
    delete field.dataset.dirty;
    setFieldError(field, "");
  }
  setFormError(form, "");
}

// ------------------------------------------------------------------
// 表單 Drawer：原生 <dialog> 以 showModal() 開啟，瀏覽器提供 top layer、焦點鎖定與背景 inert。
// 開啟時記下欄位快照，關閉前若有未儲存的變更先 confirm；退場動畫結束才真正 close()。
// ------------------------------------------------------------------
function snapshotForm(form) {
  return Array.from(form.elements, field => (field.type === "checkbox" ? field.checked : field.value)).join("\u0000");
}

function openDrawer(dialogId, { title, subtitle = "", focusId }) {
  const dialog = byId(dialogId);
  setPopoverOpen(false);
  dialog.querySelector(".drawer-head h2").replaceChildren(title);
  dialog.querySelector(".drawer-head .hint").textContent = subtitle;
  dialog.classList.remove("is-closing");
  if (!dialog.open) dialog.showModal();
  dialog.dataset.snapshot = snapshotForm(dialog.querySelector("form"));
  byId(focusId)?.focus();
}

// 回傳是否真的開始關閉；儲存中或使用者在 confirm 取消時回 false。
function requestCloseDrawer(dialog, { force = false } = {}) {
  if (!dialog.open || dialog.classList.contains("is-closing")) return false;
  const form = dialog.querySelector("form");
  if (form.getAttribute("aria-busy") === "true") return false;
  if (!force && snapshotForm(form) !== dialog.dataset.snapshot && !globalThis.confirm("尚未儲存的變更將會遺失，確定關閉？")) return false;
  datetimePickers.current?.close();
  dialog.classList.add("is-closing");
  let closed = false;
  const finish = () => {
    if (closed) return;
    closed = true;
    dialog.removeEventListener("animationend", onAnimationEnd);
    dialog.close();
  };
  const onAnimationEnd = event => {
    if (event.animationName === "drawer-out") finish();
  };
  dialog.addEventListener("animationend", onAnimationEnd);
  setTimeout(finish, 300); // 動畫沒跑（樣式未載入等）時的保險
  return true;
}

function closeDrawers() {
  for (const dialog of document.querySelectorAll(".drawer[open]")) requestCloseDrawer(dialog, { force: true });
}

function bindDrawer(dialog) {
  const form = dialog.querySelector("form");
  // blur 後才顯示錯誤（focusout 會冒泡、blur 不會），但只針對有值或打過字的欄位：
  // 只是 Tab 經過的空白必填欄位不標錯，留到送出時再一併提示。之後任何輸入都即時重驗。
  form.addEventListener("focusout", event => {
    const field = event.target;
    if (!(field instanceof Element) || !field.matches(FIELD_SELECTOR)) return;
    if (!field.value && !field.dataset.dirty && !field.dataset.touched) return;
    field.dataset.touched = "true";
    validateField(field);
  });
  form.addEventListener("input", event => {
    if (event.target instanceof Element && event.target.matches(FIELD_SELECTOR)) event.target.dataset.dirty = "true";
    setFormError(form, "");
    revalidateForm(form);
  });
  form.addEventListener("change", () => revalidateForm(form));
  // Esc 走 cancel 事件；先攔下來改走同一套「未儲存確認 + 退場動畫」流程。
  dialog.addEventListener("cancel", event => {
    event.preventDefault();
    requestCloseDrawer(dialog);
  });
  // 點遮罩關閉：pointerdown 與 click 都要落在 dialog 本身，避免從表單拖曳選字到遮罩上放開也被當成點外面。
  let pressedOnBackdrop = false;
  dialog.addEventListener("pointerdown", event => {
    pressedOnBackdrop = event.target === dialog;
  });
  dialog.addEventListener("click", event => {
    if (event.target === dialog && pressedOnBackdrop) requestCloseDrawer(dialog);
  });
  for (const closeButton of dialog.querySelectorAll("[data-drawer-close]")) closeButton.addEventListener("click", () => requestCloseDrawer(dialog));
  dialog.addEventListener("close", () => {
    dialog.classList.remove("is-closing");
    datetimePickers.current?.close();
    clearFormErrors(form);
    clearEditingRows();
  });
}

// ------------------------------------------------------------------
// 術語對照：zh 為畫面用語、en 為後端契約／技術名稱。畫面以中文為主，
// 英文只出現在面板標題、表頭、表單 label 的括號或 data-tip；
// index.html 的靜態標題必須與此表一致。
// ------------------------------------------------------------------
const TERMS = Object.freeze({
  person: { zh: "人員", en: "Person" },
  profile: { zh: "ChatGPT 帳號", en: "Profile" },
  grant: { zh: "授權", en: "Grant" },
  lease: { zh: "使用紀錄", en: "Lease" },
  owner: { zh: "擁有者", en: "Owner" },
  operator: { zh: "使用人員", en: "Operator" },
  actor: { zh: "操作者", en: "Actor" },
  audit: { zh: "操作紀錄", en: "Audit Log" },
  correlation: { zh: "追蹤編號", en: "Correlation ID" },
  forceRelease: { zh: "強制釋放", en: "Force release" }
});

// "人員（Person）" 純字串，用於 aria-label、data-tip、document.title。
function term(key) {
  const entry = TERMS[key];
  return `${entry.zh}（${entry.en}）`;
}

// 「前綴＋中文＋灰色括號英文」節點，用於表頭與 Drawer 標題；每次呼叫都建立新節點，不可快取。
function termNode(key, prefix = "") {
  const entry = TERMS[key];
  const node = el("span", "term", `${prefix}${entry.zh}`);
  node.append(el("span", "term-en", `（${entry.en}）`));
  return node;
}

const ROLE_META = Object.freeze({
  ADMIN: { label: "管理者", icon: "shield", tone: "brand" },
  USER: { label: "使用者", icon: "user", tone: "muted" }
});
const RESULT_META = Object.freeze({
  SUCCESS: { label: "成功", icon: "check-circle", tone: "success" },
  DENIED: { label: "已拒絕", icon: "alert-circle", tone: "danger" }
});
// 操作紀錄的動作代碼；後端未提供完整清單，除 mock 已出現的四種外其餘依命名慣例預填，未命中一律顯示原始代碼。
const AUDIT_ACTION_LABELS = Object.freeze({
  PROFILE_STATUS_UPDATE: `變更 ${TERMS.profile.zh}狀態`,
  GRANT_CREATE: `新增${TERMS.grant.zh}`,
  GRANT_UPDATE: `修改${TERMS.grant.zh}`,
  GRANT_REVOKE: `撤銷${TERMS.grant.zh}`,
  LEASE_FORCE_RELEASE: TERMS.forceRelease.zh,
  PERSON_CREATE: `新增${TERMS.person.zh}`,
  PERSON_UPDATE: `修改${TERMS.person.zh}`,
  PERSON_DISABLE: `停用${TERMS.person.zh}`
});
// 操作紀錄的目標類型 → TERMS key。
const AUDIT_TARGET_TERMS = Object.freeze({ PROFILE: "profile", GRANT: "grant", LEASE: "lease", PERSON: "person" });

const STATUS_META = Object.freeze({
  AVAILABLE: { label: "可用", icon: "check-circle", tone: "success" },
  DISABLED: { label: "已停用", icon: "ban", tone: "muted" },
  REAUTH_REQUIRED: { label: "需重新授權", icon: "key", tone: "warning" }
});
const USAGE_THRESHOLDS = Object.freeze({ warning: 0.5, danger: 0.8 });
// 使用率分組；key 與 usageTone() 回傳的 tone 一致，供 KPI 卡片與篩選選單點選篩選清單。
const USAGE_BUCKETS = Object.freeze({
  danger: { label: `> ${Math.round(USAGE_THRESHOLDS.danger * 100)}% 吃緊`, tone: "danger" },
  warning: { label: `${Math.round(USAGE_THRESHOLDS.warning * 100)}–${Math.round(USAGE_THRESHOLDS.danger * 100)}% 偏高`, tone: "warning" },
  success: { label: `< ${Math.round(USAGE_THRESHOLDS.warning * 100)}% 充裕`, tone: "success" },
  muted: { label: "未取得", tone: "muted" }
});

function svgEl(tag, attributes = {}) {
  const element = document.createElementNS("http://www.w3.org/2000/svg", tag);
  for (const [key, value] of Object.entries(attributes)) element.setAttribute(key, String(value));
  return element;
}

function el(tag, className, text) {
  const element = document.createElement(tag);
  if (className) element.className = className;
  if (text !== undefined) element.textContent = text;
  return element;
}

function formatNumber(value) {
  return typeof value === "number" && Number.isFinite(value) ? value.toLocaleString("zh-TW", { maximumFractionDigits: 3 }) : null;
}

function formatPercent(rate) {
  return rate === null ? "—" : `${Math.round(rate * 100)}%`;
}

function usageTone(rate) {
  if (rate === null) return "tone-muted";
  if (rate > USAGE_THRESHOLDS.danger) return "tone-danger";
  if (rate >= USAGE_THRESHOLDS.warning) return "tone-warning";
  return "tone-success";
}

function usageBucket(rate) {
  return usageTone(rate).replace("tone-", "");
}

function usageRate(usage) {
  if (!usage || usage.error) return null;
  const limit = usage.limit;
  if (typeof limit !== "number" || !Number.isFinite(limit) || limit <= 0) return null;
  if (typeof usage.used === "number" && Number.isFinite(usage.used)) return Math.max(0, usage.used / limit);
  if (typeof usage.remaining === "number" && Number.isFinite(usage.remaining)) return Math.max(0, (limit - usage.remaining) / limit);
  return null;
}

function statusBadge(status) {
  const meta = STATUS_META[status];
  const badge = el("span", `badge ${meta ? `badge-${meta.tone}` : "badge-muted"}`);
  badge.dataset.tip = `狀態：${formatValue(status)}`;
  badge.append(icon(meta?.icon ?? "info"), document.createTextNode(meta?.label ?? formatValue(status)));
  return badge;
}

function donut({ rate, size = 40, stroke = 5, label, tone, tip }) {
  const wrapper = el("span", "inline-flex");
  if (tip) wrapper.dataset.tip = tip;
  const svg = svgEl("svg", { class: `donut ${tone ?? usageTone(rate)}`, width: size, height: size, viewBox: `0 0 ${size} ${size}`, role: "img" });
  svg.setAttribute("aria-label", label ?? formatPercent(rate));
  const radius = (size - stroke) / 2;
  const circumference = 2 * Math.PI * radius;
  svg.append(svgEl("circle", { class: "donut-track", cx: size / 2, cy: size / 2, r: radius, "stroke-width": stroke }));
  if (rate !== null) {
    svg.append(svgEl("circle", {
      class: "donut-value", cx: size / 2, cy: size / 2, r: radius, "stroke-width": stroke,
      "stroke-dasharray": circumference.toFixed(2), "stroke-dashoffset": (circumference * (1 - Math.min(1, rate))).toFixed(2)
    }));
  }
  const text = svgEl("text", { class: "donut-text", x: size / 2, y: size / 2, "font-size": (size * 0.24).toFixed(1) });
  text.textContent = label ?? formatPercent(rate);
  svg.append(text);
  wrapper.append(svg);
  return wrapper;
}

// 多段環狀圖（KPI 卡片用）：每段是獨立的 <path> 弧線，可帶 data-tip、data-segment 與點擊切換篩選。
// segments: [{ key, label, value, valueText, tone, tip, track, pressed, onToggle }]；center: { value, label, tone, tip }。
function ringChart({ size = 104, stroke = 12, segments, center }) {
  const svg = svgEl("svg", { class: "arc-chart", width: size, height: size, viewBox: `0 0 ${size} ${size}`, role: "group" });
  const cx = size / 2;
  const cy = size / 2;
  const radius = (size - stroke) / 2 - 2;
  const total = segments.reduce((sum, segment) => sum + Math.max(0, segment.value), 0);
  svg.append(svgEl("circle", { class: "arc-track", cx, cy, r: radius, "stroke-width": stroke }));
  const visible = segments.filter(segment => segment.value > 0);
  const arc = (from, to) => {
    const start = { x: (cx + radius * Math.cos(from)).toFixed(2), y: (cy + radius * Math.sin(from)).toFixed(2) };
    const end = { x: (cx + radius * Math.cos(to)).toFixed(2), y: (cy + radius * Math.sin(to)).toFixed(2) };
    return `M ${start.x} ${start.y} A ${radius} ${radius} 0 ${to - from > Math.PI ? 1 : 0} 1 ${end.x} ${end.y}`;
  };
  // 多段時各段之間留一點縫隙，單段（或滿圈）就畫整圈。
  const gap = visible.length > 1 ? 0.05 : 0;
  let angle = -Math.PI / 2;
  for (const segment of visible) {
    const sweep = (segment.value / total) * Math.PI * 2;
    const from = angle + gap / 2;
    const to = Math.max(from + 0.02, angle + sweep - gap / 2);
    const full = visible.length === 1;
    const path = full
      ? svgEl("circle", { cx, cy, r: radius })
      : svgEl("path", { d: arc(from, to) });
    path.setAttribute("class", `arc-seg ${segment.track ? "is-track" : segment.tone}${segment.onToggle ? " is-action" : ""}`);
    path.setAttribute("stroke-width", stroke);
    path.setAttribute("fill", "none");
    if (segment.tip) path.dataset.tip = segment.tip;
    if (segment.key) path.dataset.segment = segment.key;
    if (segment.onToggle) {
      path.setAttribute("role", "button");
      path.setAttribute("aria-label", `${segment.label}：${segment.valueText ?? segment.value}，${segment.pressed ? "點擊取消篩選" : "點擊篩選清單"}`);
      path.setAttribute("aria-pressed", String(Boolean(segment.pressed)));
      path.addEventListener("click", segment.onToggle);
    } else {
      path.setAttribute("aria-label", `${segment.label}：${segment.valueText ?? segment.value}`);
    }
    svg.append(path);
    angle += sweep;
  }
  if (center) {
    const group = svgEl("g", { class: "arc-center" });
    if (center.tip) group.dataset.tip = center.tip;
    const hasLabel = Boolean(center.label);
    const value = svgEl("text", { class: `arc-value ${center.tone ?? ""}`.trim(), x: cx, y: hasLabel ? cy - size * 0.06 : cy, "font-size": (size * (hasLabel ? 0.27 : 0.23)).toFixed(1) });
    value.textContent = center.value;
    group.append(value);
    if (hasLabel) {
      const label = svgEl("text", { class: "arc-label", x: cx, y: cy + size * 0.13, "font-size": (size * 0.105).toFixed(1) });
      label.textContent = center.label;
      group.append(label);
    }
    svg.append(group);
  }
  return svg;
}

function emptyState(title, description, iconName = "inbox") {
  const box = el("div", "empty-state");
  box.append(icon(iconName, "icon icon-xl"), el("strong", "", title));
  if (description) box.append(el("span", "", description));
  return box;
}

const PREFS_KEY = "codex-admin.dashboard";
const SORT_COLUMNS = Object.freeze({
  name: { label: "擁有者", type: "text", defaultDir: "asc" },
  status: { label: "狀態", type: "status", defaultDir: "asc" },
  rate: { label: "使用率", type: "number", defaultDir: "desc" },
  limit: { label: "額度", type: "number", defaultDir: "desc" },
  used: { label: "已使用", type: "number", defaultDir: "desc" },
  remaining: { label: "剩餘", type: "number", defaultDir: "asc" }
});

function loadPrefs() {
  try {
    const saved = JSON.parse(globalThis.localStorage?.getItem(PREFS_KEY) ?? "null");
    if (!saved || typeof saved !== "object") return;
    if (saved.mode === "table" || saved.mode === "cards") state.dashboard.mode = saved.mode;
    if (saved.sortKey === null || SORT_COLUMNS[saved.sortKey]) state.dashboard.sortKey = saved.sortKey;
    if (saved.sortDir === "asc" || saved.sortDir === "desc") state.dashboard.sortDir = saved.sortDir;
  } catch {
  }
}

function savePrefs() {
  try {
    const { mode, sortKey, sortDir } = state.dashboard;
    globalThis.localStorage?.setItem(PREFS_KEY, JSON.stringify({ mode, sortKey, sortDir }));
  } catch {
  }
}

// key 為 null 代表取消排序，清單維持 API 回傳順序。
function setSort(key, dir) {
  state.dashboard.sortKey = key;
  state.dashboard.sortDir = key ? dir ?? SORT_COLUMNS[key].defaultDir : "desc";
  savePrefs();
  renderProfiles();
}

// 欄位標題點擊循環：未排序 → 預設方向 → 反方向 → 取消排序。
function cycleSort(key) {
  const { sortKey, sortDir } = state.dashboard;
  const { defaultDir } = SORT_COLUMNS[key];
  if (sortKey !== key) return setSort(key, defaultDir);
  if (sortDir === defaultDir) return setSort(key, defaultDir === "asc" ? "desc" : "asc");
  return setSort(null);
}

function setViewMode(mode) {
  state.dashboard.mode = mode;
  savePrefs();
  syncToolbar();
  if (state.dashboardLoading) renderSkeleton(byId("profiles-table"), Math.max(3, Math.min(8, state.profiles.length || 5)));
  else renderProfiles();
}

function syncToolbar() {
  const { mode, sortKey, sortDir } = state.dashboard;
  for (const element of document.querySelectorAll("[data-view-mode]")) element.setAttribute("aria-pressed", String(element.dataset.viewMode === mode));
  byId("card-sort").hidden = mode !== "cards";
  byId("profile-sort").value = sortKey ?? "";
  const direction = byId("sort-direction");
  direction.replaceChildren(icon(!sortKey ? "sort" : sortDir === "asc" ? "arrow-up" : "arrow-down"));
  direction.disabled = !sortKey;
  direction.dataset.tip = !sortKey ? "未排序" : sortDir === "asc" ? "目前：由低到高，點擊改為由高到低" : "目前：由高到低，點擊改為由低到高";
  const container = byId("profiles-table");
  container.className = mode === "cards" ? "card-grid" : "table-wrap";
}

function renderTable(containerId, columns, rows, actionFactory, options = {}) {
  const container = byId(containerId);
  container.replaceChildren();
  if (rows.length === 0) {
    container.append(emptyState(options.emptyTitle ?? "目前沒有資料", options.emptyDescription, options.emptyIcon));
    return;
  }

  const table = document.createElement("table");
  const headRow = document.createElement("tr");
  for (const column of columns) {
    const header = document.createElement("th");
    header.scope = "col";
    if (typeof column.label === "string") header.textContent = column.label;
    else header.append(column.label);
    if (column.className) header.className = column.className;
    headRow.append(header);
  }
  if (actionFactory) {
    const header = document.createElement("th");
    header.scope = "col";
    header.textContent = "操作";
    headRow.append(header);
  }
  const head = document.createElement("thead");
  head.append(headRow);
  table.append(head);

  const body = document.createElement("tbody");
  for (const row of rows) {
    const tableRow = document.createElement("tr");
    if (options.rowKey) tableRow.dataset.rowId = String(options.rowKey(row));
    for (const column of columns) {
      const element = column.render ? document.createElement("td") : cell(column.value(row));
      if (column.render) element.append(column.render(row));
      if (column.className) element.className = column.className;
      tableRow.append(element);
    }
    if (actionFactory) {
      const actionCell = document.createElement("td");
      actionCell.append(actionFactory(row));
      tableRow.append(actionCell);
    }
    body.append(tableRow);
  }
  table.append(body);
  container.append(table);
}

// 列標示：編輯中的列以 .is-editing 高亮，讓 drawer 旁的表格看得出在改哪一筆；
// 儲存後以 .is-flash 閃一下並捲到可視範圍。兩者都需要 renderTable 的 rowKey。
function markEditingRow(containerId, id) {
  clearEditingRows();
  byId(containerId).querySelector(`tr[data-row-id="${id}"]`)?.classList.add("is-editing");
}

function clearEditingRows() {
  for (const row of document.querySelectorAll("tr.is-editing")) row.classList.remove("is-editing");
}

function flashRow(containerId, id) {
  if (id === undefined || id === null) return;
  const row = byId(containerId).querySelector(`tr[data-row-id="${id}"]`);
  if (!row) return;
  row.classList.add("is-flash");
  row.scrollIntoView({ block: "nearest" });
  row.addEventListener("animationend", () => row.classList.remove("is-flash"), { once: true });
}

function formatDateTime(value) {
  if (!value) return null;
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return String(value);
  return date.toLocaleString("zh-TW", { year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hour12: false });
}

function dateNode(value) {
  const text = formatDateTime(value);
  const node = el("span", text ? "" : "tone-muted", text ?? "—");
  if (text && text !== String(value)) node.dataset.tip = String(value);
  return node;
}

function boolBadge(value, labels = ["啟用", "停用"]) {
  const badge = el("span", `badge ${value ? "badge-success" : "badge-muted"}`);
  badge.dataset.tip = `${value}`;
  badge.append(icon(value ? "check-circle" : "ban"), document.createTextNode(value ? labels[0] : labels[1]));
  return badge;
}

const LEASE_META = Object.freeze({
  ACTIVE: { label: "使用中", tone: "success", icon: "check-circle" },
  STALE: { label: "逾時未回報", tone: "warning", icon: "alert-circle" },
  RELEASED: { label: "已釋放", tone: "muted", icon: "check" },
  FORCE_RELEASED: { label: "強制釋放", tone: "danger", icon: "unlock" }
});

function leaseBadge(status) {
  const meta = LEASE_META[status];
  const badge = el("span", `badge badge-${meta?.tone ?? "muted"}`);
  badge.dataset.tip = `狀態：${formatValue(status)}`;
  badge.append(icon(meta?.icon ?? "info"), document.createTextNode(meta?.label ?? formatValue(status)));
  return badge;
}

// ------------------------------------------------------------------
// 日期時間欄位 datetimeField()
// 文字輸入固定顯示 YYYY/MM/DD HH:mm（24 小時制，與 formatDateTime() 一致），可直接打字或貼上；
// 右側日曆按鈕開啟月曆 popover。值一律以 ISO 字串（UTC）進出，顯示用瀏覽器時區。
// ------------------------------------------------------------------
const DATETIME_PRESETS = Object.freeze([
  { label: "+7 天", days: 7 },
  { label: "+30 天", days: 30 },
  { label: "+90 天", days: 90 }
]);
const WEEKDAY_LABELS = Object.freeze(["日", "一", "二", "三", "四", "五", "六"]);
// 同一時間只會有一個月曆開著；全域的 click（點外面）與 Escape 處理靠它關閉。
const datetimePickers = { current: null };

function pad2(value) {
  return String(value).padStart(2, "0");
}

function formatDateTimeText(date) {
  return `${date.getFullYear()}/${pad2(date.getMonth() + 1)}/${pad2(date.getDate())} ${pad2(date.getHours())}:${pad2(date.getMinutes())}`;
}

// 解析使用者輸入：年月日可用 / - . 分隔，時間以空白或 T 接在後面、可省略（視為 00:00）。
function parseDateTimeText(text) {
  const match = /^\s*(\d{4})[/.-](\d{1,2})[/.-](\d{1,2})(?:[\sT]+(\d{1,2}):(\d{2}))?\s*$/.exec(text);
  if (!match) return null;
  const [year, month, day, hour, minute] = match.slice(1).map(part => Number(part ?? 0));
  const date = new Date(year, month - 1, day, hour, minute);
  // Date 會把 2/31、25:00 之類自動進位成合法時間，逐項比對把這種輸入當成格式錯誤。
  const valid = date.getFullYear() === year && date.getMonth() === month - 1 && date.getDate() === day && date.getHours() === hour && date.getMinutes() === minute;
  return valid ? date : null;
}

function sameDay(a, b) {
  return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
}

function sameMonth(a, b) {
  return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth();
}

function startOfDay(date) {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate());
}

function addDays(date, days) {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate() + days, date.getHours(), date.getMinutes());
}

// 月份加減時把日期夾在目標月份的天數內，避免 1/31 加一個月變成 3/3。
function addMonths(date, months) {
  const target = new Date(date.getFullYear(), date.getMonth() + months, 1, date.getHours(), date.getMinutes());
  const lastDay = new Date(target.getFullYear(), target.getMonth() + 1, 0).getDate();
  target.setDate(Math.min(date.getDate(), lastDay));
  return target;
}

function dayKey(date) {
  return `${date.getFullYear()}-${pad2(date.getMonth() + 1)}-${pad2(date.getDate())}`;
}

function timeZoneLabel() {
  const offset = -new Date().getTimezoneOffset();
  const sign = offset >= 0 ? "+" : "-";
  return `${Intl.DateTimeFormat().resolvedOptions().timeZone} (UTC${sign}${pad2(Math.floor(Math.abs(offset) / 60))}:${pad2(Math.abs(offset) % 60)})`;
}

// options.empty：選填欄位空值時顯示的文案（如「永久有效」）；未提供則視為必填。
// options.after：另一個 datetimeField，本欄位必須晚於它（失效必須晚於生效），月曆會停用更早的日期。
function datetimeField(input, { empty, after } = {}) {
  let value = null; // Date | null，唯一的狀態來源
  let sync = () => {}; // 把 value 寫回輸入框與月曆（月曆建好後才補上實作）
  const listeners = new Set();
  const required = !empty;
  input.required = required;
  input.autocomplete = "off";

  // 錯誤訊息接在輸入框後（同一個 label 內）；同時設成 customValidity，送出時瀏覽器原生提示也用同一段文字。
  const error = el("small", "field-error");
  error.hidden = true;
  const message = text => {
    input.setCustomValidity(text);
    error.textContent = text;
    error.hidden = !text;
  };
  const validate = () => {
    if (value && after?.date && value < after.date) return message("失效時間必須晚於生效時間");
    if (!value && input.value.trim()) return message("格式需為 YYYY/MM/DD HH:mm");
    return message("");
  };
  const notify = () => {
    for (const listener of listeners) listener();
  };
  const commit = date => {
    value = date instanceof Date && !Number.isNaN(date.getTime()) ? date : null;
    sync();
    validate();
    notify();
  };
  // form.reset() 會清空輸入框，內部狀態也要跟著歸零；事件在實際清空前觸發，只動狀態不碰輸入框。
  input.form?.addEventListener("reset", () => {
    value = null;
    message("");
    notify();
  });

  const api = {
    input,
    get value() { return value ? value.toISOString() : null; },
    get date() { return value; },
    set(next) { commit(next ? new Date(next) : null); },
    clear() { commit(null); },
    subscribe(listener) { listeners.add(listener); },
    close() {}
  };

  input.type = "text";
  input.placeholder = empty ?? "YYYY/MM/DD HH:mm";
  const wrap = el("div", "datetime-field");
  input.replaceWith(wrap);
  const trigger = el("button", "datetime-trigger");
  trigger.type = "button";
  trigger.setAttribute("aria-label", "開啟月曆");
  trigger.setAttribute("aria-haspopup", "dialog");
  trigger.setAttribute("aria-expanded", "false");
  trigger.append(icon("calendar", "icon icon-sm"));
  wrap.append(input, trigger);
  wrap.after(error);
  const labelText = input.closest("label")?.firstChild?.textContent?.trim() ?? "日期時間";

  // popover 掛在 body 下以 fixed 定位，避免被包在 label 裡讓讀屏軟體把整個月曆唸成欄位名稱。
  let popover = null;
  let grid = null;
  let title = null;
  let hourSelect = null;
  let minuteSelect = null;
  let view = null; // 月曆顯示中的月份（該月 1 日）

  const isOpen = () => popover !== null && !popover.hidden;
  const syncTip = () => {
    trigger.dataset.tip = value ? `開啟月曆\n儲存值（UTC）：${value.toISOString()}` : "開啟月曆";
  };
  sync = () => {
    input.value = value ? formatDateTimeText(value) : "";
    syncTip();
    if (isOpen()) {
      if (value) view = new Date(value.getFullYear(), value.getMonth(), 1);
      renderCalendar();
    }
  };
  syncTip();

  const timeSelect = (count, label) => {
    const select = el("select");
    select.setAttribute("aria-label", label);
    for (let index = 0; index < count; index++) select.append(new Option(pad2(index), String(index)));
    select.addEventListener("change", () => {
      const base = value ?? new Date();
      commit(new Date(base.getFullYear(), base.getMonth(), base.getDate(), Number(hourSelect.value), Number(minuteSelect.value)));
    });
    return select;
  };

  // 月曆固定 6 週 × 7 天，從該月 1 日所在週的週日開始；鄰月日期以 is-outside 淡化但仍可點。
  const renderCalendar = () => {
    title.textContent = `${view.getFullYear()} 年 ${view.getMonth() + 1} 月`;
    grid.replaceChildren();
    const today = new Date();
    const minDay = after?.date ? startOfDay(after.date) : null;
    const first = new Date(view.getFullYear(), view.getMonth(), 1 - view.getDay());
    for (let week = 0; week < 6; week++) {
      const row = el("tr");
      for (let weekday = 0; weekday < 7; weekday++) {
        const day = addDays(first, week * 7 + weekday);
        const dayButton = el("button", "cal-day", String(day.getDate()));
        dayButton.type = "button";
        dayButton.dataset.day = dayKey(day);
        dayButton.setAttribute("aria-label", day.toLocaleDateString("zh-TW", { year: "numeric", month: "long", day: "numeric", weekday: "short" }));
        if (!sameMonth(day, view)) dayButton.classList.add("is-outside");
        if (sameDay(day, today)) {
          dayButton.classList.add("is-today");
          dayButton.setAttribute("aria-current", "date");
        }
        if (value && sameDay(day, value)) {
          dayButton.classList.add("is-selected");
          dayButton.setAttribute("aria-pressed", "true");
        }
        if (minDay && day < minDay) dayButton.disabled = true;
        dayButton.addEventListener("click", () => commit(new Date(day.getFullYear(), day.getMonth(), day.getDate(), Number(hourSelect.value), Number(minuteSelect.value))));
        const cell = el("td");
        cell.append(dayButton);
        row.append(cell);
      }
      grid.append(row);
    }
    const time = value ?? today;
    hourSelect.value = String(time.getHours());
    minuteSelect.value = String(time.getMinutes());
  };

  const position = () => {
    const rect = wrap.getBoundingClientRect();
    const width = popover.offsetWidth;
    const height = popover.offsetHeight;
    const left = Math.max(8, Math.min(rect.left, window.innerWidth - width - 8));
    let top = rect.bottom + 6;
    // 下方放不下且上方放得下時往上翻；上下都放不下就貼齊視窗底部，至少不被切掉。
    if (top + height > window.innerHeight - 8 && rect.top - height - 6 > 8) top = rect.top - height - 6;
    top = Math.max(8, Math.min(top, window.innerHeight - height - 8));
    popover.style.left = `${left}px`;
    popover.style.top = `${top}px`;
  };

  const build = () => {
    popover = el("div", "popover datetime-popover");
    popover.setAttribute("role", "dialog");
    popover.setAttribute("aria-label", `選擇${labelText}`);
    popover.hidden = true;

    const head = el("div", "cal-head");
    const prev = el("button", "icon-btn");
    prev.type = "button";
    prev.setAttribute("aria-label", "上個月");
    prev.append(icon("chevron-left", "icon icon-sm"));
    prev.addEventListener("click", () => {
      view = addMonths(view, -1);
      renderCalendar();
    });
    title = el("strong", "cal-title");
    title.setAttribute("aria-live", "polite");
    const next = el("button", "icon-btn");
    next.type = "button";
    next.setAttribute("aria-label", "下個月");
    next.append(icon("chevron-right", "icon icon-sm"));
    next.addEventListener("click", () => {
      view = addMonths(view, 1);
      renderCalendar();
    });
    head.append(prev, title, next);

    const table = el("table", "cal-grid");
    table.setAttribute("role", "grid");
    const headRow = el("tr");
    for (const weekday of WEEKDAY_LABELS) {
      const th = el("th", "", weekday);
      th.scope = "col";
      headRow.append(th);
    }
    const thead = el("thead");
    thead.append(headRow);
    grid = el("tbody");
    table.append(thead, grid);

    const time = el("div", "cal-time");
    hourSelect = timeSelect(24, "時");
    minuteSelect = timeSelect(60, "分");
    time.append(icon("clock", "icon icon-sm"), hourSelect, el("span", "cal-time-sep", ":"), minuteSelect, button("現在", () => commit(new Date()), "btn btn-ghost btn-sm"));

    // 快捷以生效時間為基準（沒有 after 的欄位以現在為基準）。
    const presets = el("div", "cal-presets");
    for (const preset of DATETIME_PRESETS) {
      const presetButton = button(preset.label, () => commit(addDays(after?.date ?? new Date(), preset.days)), "btn btn-secondary btn-sm");
      presetButton.dataset.tip = after ? `生效時間起 ${preset.days} 天` : `現在起 ${preset.days} 天`;
      presets.append(presetButton);
    }
    if (!required) {
      presets.append(button("清除", () => {
        commit(null);
        close(true);
      }, "btn btn-ghost btn-sm"));
    }

    const foot = el("div", "cal-foot");
    foot.append(el("span", "hint", `時區 ${timeZoneLabel()}`), button("完成", () => close(true), "btn btn-sm"));

    popover.append(head, table, time, presets, foot);
    // Tab 離開月曆時關閉；relatedTarget 為空代表點到不可聚焦處，交給全域 click 判斷。
    popover.addEventListener("focusout", event => {
      if (event.relatedTarget && !popover.contains(event.relatedTarget) && !wrap.contains(event.relatedTarget)) close();
    });
    // 欄位在 modal dialog 內時 popover 必須掛在 dialog 裡，否則會被 top layer 蓋住、也被 inert 擋掉點擊。
    (input.closest("dialog") ?? document.body).append(popover);
  };

  const open = () => {
    if (!popover) build();
    datetimePickers.current?.close();
    datetimePickers.current = api;
    view = value ? new Date(value.getFullYear(), value.getMonth(), 1) : new Date(new Date().getFullYear(), new Date().getMonth(), 1);
    renderCalendar();
    popover.hidden = false;
    trigger.setAttribute("aria-expanded", "true");
    position();
    window.addEventListener("scroll", position, true);
    window.addEventListener("resize", position);
  };
  const close = (refocus = false) => {
    if (!isOpen()) return;
    popover.hidden = true;
    trigger.setAttribute("aria-expanded", "false");
    if (datetimePickers.current === api) datetimePickers.current = null;
    window.removeEventListener("scroll", position, true);
    window.removeEventListener("resize", position);
    if (refocus) trigger.focus();
  };
  api.close = close;
  api.contains = node => wrap.contains(node) || (popover?.contains(node) ?? false);
  api.trigger = trigger;

  trigger.addEventListener("click", () => (isOpen() ? close(true) : open()));
  // 打字時即時解析但不改寫輸入框內容，離開欄位（change）才正規化成固定格式。
  input.addEventListener("input", () => {
    value = parseDateTimeText(input.value);
    validate();
    notify();
    syncTip();
    if (isOpen()) {
      if (value) view = new Date(value.getFullYear(), value.getMonth(), 1);
      renderCalendar();
    }
  });
  input.addEventListener("change", () => {
    if (value) input.value = formatDateTimeText(value);
  });
  after?.subscribe(() => {
    validate();
    if (isOpen()) renderCalendar();
  });
  return api;
}

// Person 表單的日期欄位；失效留空代表永久有效，且必須晚於生效。
const personDates = {
  from: datetimeField(byId("person-effective-from")),
  until: null
};
personDates.until = datetimeField(byId("person-effective-until"), { empty: "永久有效", after: personDates.from });
// 用月曆選值不會發 input 事件，訂閱變更讓欄位錯誤即時更新。
for (const field of Object.values(personDates)) field.subscribe(() => revalidateForm(byId("person-form")));

function resetPersonForm() {
  byId("person-form").reset();
  byId("person-id").value = "";
  byId("person-role").value = "USER";
  byId("person-enabled").checked = true;
  personDates.from.set(new Date());
}

// 不帶 person 為新增；帶 person 為編輯，標題與副標標示對象。
function openPersonDrawer(person = null) {
  resetPersonForm();
  if (person) {
    byId("person-id").value = person.id;
    byId("person-display-name").value = person.displayName;
    byId("person-ip-address").value = person.normalizedIpAddress;
    byId("person-role").value = person.role;
    byId("person-enabled").checked = person.enabled;
    personDates.from.set(person.effectiveFrom);
    personDates.until.set(person.effectiveUntil);
    markEditingRow("persons-table", person.id);
  }
  openDrawer("person-drawer", {
    title: termNode("person", person ? "編輯" : "新增"),
    subtitle: person ? `${person.displayName}（編號 ${person.id}）` : "依來源 IP 識別身分",
    focusId: "person-display-name"
  });
}

function personActions(person) {
  const actions = el("div", "actions");
  const edit = button("編輯", () => openPersonDrawer(person), "btn btn-secondary btn-sm");
  edit.prepend(icon("edit", "icon icon-sm"));
  const disable = button("停用", () => disablePerson(person), "btn btn-danger btn-sm");
  disable.prepend(icon("ban", "icon icon-sm"));
  disable.disabled = !person.enabled;
  actions.append(edit, disable);
  return actions;
}

function roleBadge(role) {
  const meta = ROLE_META[role];
  const badge = el("span", `badge ${meta ? `badge-${meta.tone}` : "badge-muted"}`);
  badge.dataset.tip = `角色：${formatValue(role)}`;
  badge.append(icon(meta?.icon ?? "info"), document.createTextNode(meta?.label ?? formatValue(role)));
  return badge;
}

// state.persons 唯一的寫入點：同時重建 id 索引，其他地方一律透過 personById() 查詢。
function setPersons(list) {
  state.persons = requireArray(list);
  state.personIndex = new Map(state.persons.map(person => [person.id, person]));
}

// audit 的 actorPersonId 可能是字串，統一轉數字再查。
function personById(personId) {
  return state.personIndex.get(Number(personId)) ?? null;
}

function personName(personId) {
  return personById(personId)?.displayName ?? null;
}

// 顯示用名稱：找不到時退回「人員 #N」，供 confirm 等純文字情境。
function personLabel(personId) {
  return personName(personId) ?? `${TERMS.person.zh} #${formatValue(personId)}`;
}

// 「名稱 + 編號小字」儲存格，人員、授權、使用紀錄、操作紀錄四張表共用。
// 傳入 sub（字串或字串陣列，每項一行）可改放其他編號（如「授權編號 1」），此時人員編號移到名稱的 data-tip。
function personCell(personId, { sub } = {}) {
  const person = personById(personId);
  const idText = `Person ID：${formatValue(personId)}`;
  const node = el("div");
  const title = el("div", person ? "row-title" : "row-title tone-muted", person ? formatValue(person.displayName) : personLabel(personId));
  if (!person) title.dataset.tip = `找不到編號 ${formatValue(personId)} 的${TERMS.person.zh}，可能已被移除`;
  else if (sub) title.dataset.tip = idText;
  node.append(title);
  for (const line of [].concat(sub ?? `編號 ${formatValue(personId)}`)) {
    const subNode = el("div", "row-sub row-id", line);
    if (!sub) subNode.dataset.tip = idText;
    node.append(subNode);
  }
  return node;
}

// 名稱下方的「編號 N」小字，hover 顯示原始欄位名稱（如 Profile ID）。
function idSub(id, enLabel) {
  const node = el("div", "row-sub row-id", `編號 ${formatValue(id)}`);
  node.dataset.tip = `${enLabel}：${formatValue(id)}`;
  return node;
}

// 詳情頁也需要 Person 名單（Grant 表格顯示名稱、Operator 下拉）；沒載過才抓，不重繪設定頁表格。
async function ensurePersons() {
  if (state.persons.length === 0) setPersons(await requestJson(api.persons));
}

async function loadPersons() {
  setPersons(await requestJson(api.persons));
  renderTable("persons-table", [
    { label: "名稱", render: row => personCell(row.id) },
    { label: "來源 IP", value: row => row.normalizedIpAddress, className: "mono" },
    { label: "角色", render: row => roleBadge(row.role) },
    { label: "狀態", render: row => boolBadge(row.enabled) },
    { label: "生效", render: row => dateNode(row.effectiveFrom) },
    { label: "失效", render: row => dateNode(row.effectiveUntil) }
  ], state.persons, personActions, { rowKey: row => row.id, emptyTitle: `尚無${TERMS.person.zh}`, emptyDescription: `點擊「新增${TERMS.person.zh}」建立第一位使用者。`, emptyIcon: "users" });
}

async function savePerson(event) {
  event.preventDefault();
  const form = byId("person-form");
  if (!validateForm(form)) return;
  const id = byId("person-id").value;
  const body = {
    displayName: byId("person-display-name").value.trim(),
    ipAddress: byId("person-ip-address").value.trim(),
    role: byId("person-role").value,
    enabled: byId("person-enabled").checked,
    effectiveFrom: personDates.from.value,
    effectiveUntil: personDates.until.value
  };
  setFormError(form, "");
  setFormBusy(form, true);
  try {
    await requestJson(id ? `${api.persons}/${id}` : api.persons, { method: id ? "PUT" : "POST", body });
  } catch (error) {
    setFormError(form, errorText(error));
    return;
  } finally {
    setFormBusy(form, false);
  }
  // 新增時不依賴 POST 回傳格式，改以重載前後的 id 差集找出新列。
  const before = new Set(state.persons.map(person => person.id));
  requestCloseDrawer(byId("person-drawer"), { force: true });
  await runSection("persons", async () => {
    await loadPersons();
    flashRow("persons-table", id ? Number(id) : state.persons.find(person => !before.has(person.id))?.id);
  });
}

async function disablePerson(person) {
  if (!globalThis.confirm(`確定停用${TERMS.person.zh}「${person.displayName}」（編號 ${person.id}）？相關使用權可能立即被撤銷。`)) return;
  await runSection("persons", async () => {
    await requestJson(`${api.persons}/${person.id}`, { method: "DELETE" });
    await loadPersons();
  });
}

function profileActions(profile) {
  const actions = el("div", "status-control");
  const label = el("label", "", "狀態");
  label.htmlFor = "profile-status-select";
  const select = document.createElement("select");
  select.id = "profile-status-select";
  for (const status of ["AVAILABLE", "DISABLED", "REAUTH_REQUIRED"]) {
    const option = document.createElement("option");
    option.value = status;
    option.textContent = `${STATUS_META[status]?.label ?? status}（${status}）`;
    option.selected = profile.status === status;
    select.append(option);
  }
  const apply = button("套用", () => setProfileStatus(profile.id, select.value), "btn btn-secondary");
  apply.disabled = true;
  select.addEventListener("change", () => { apply.disabled = select.value === profile.status; });
  actions.append(label, select, apply);
  return actions;
}

function setDashboardLoading(loading, done = 0, total = 0) {
  state.dashboardLoading = loading;
  const note = byId("profiles-loading");
  note.hidden = !loading;
  for (const element of document.querySelectorAll('[data-refresh="profiles"]')) {
    element.disabled = loading;
    element.querySelector(".icon")?.classList.toggle("is-spinning", loading);
  }
  if (loading && total === 0) renderKpiSkeleton();
  if (!loading) return;
  byId("profiles-loading-text").textContent = total > 0 ? `載入使用量 ${done} / ${total}` : `載入${TERMS.profile.zh}清單…`;
  byId("profiles-progress").style.width = total > 0 ? `${Math.round((done / total) * 100)}%` : "0%";
}

function renderSkeleton(container, count) {
  container.replaceChildren();
  const cards = state.dashboard.mode === "cards";
  const widths = cards ? ["60%", "35%", "100%", "80%"] : ["70%", "55%", "40%", "40%", "40%", "35%", "60%"];
  for (let index = 0; index < count; index += 1) {
    const row = document.createElement("div");
    row.className = cards ? "skeleton-card" : "skeleton-row";
    row.setAttribute("aria-hidden", "true");
    for (const width of widths) {
      const block = document.createElement("span");
      block.className = "skeleton";
      block.style.width = width;
      row.append(block);
    }
    container.append(row);
  }
}

async function loadProfiles() {
  const revision = ++state.dashboardRevision;
  setDashboardLoading(true);
  renderSkeleton(byId("profiles-table"), Math.max(3, Math.min(8, state.profiles.length || 5)));
  const [profiles, persons] = await Promise.all([requestJson(api.profiles), requestJson(api.persons)]);
  if (revision !== state.dashboardRevision) return;
  state.profiles = requireArray(profiles);
  setPersons(persons);
  const total = state.profiles.length;
  let done = 0;
  setDashboardLoading(true, done, total);
  renderSkeleton(byId("profiles-table"), Math.max(3, Math.min(8, total)));

  // 先把所有 usage 抓完，再一次排序、渲染，避免資料陸續回來時列位跳動。
  const usage = new Map();
  const queue = [...state.profiles];
  await Promise.all(Array.from({ length: Math.min(4, queue.length) }, async () => {
    while (queue.length && revision === state.dashboardRevision) {
      const profile = queue.shift();
      let result;
      try {
        result = await requestJson(`${api.profiles}/${profile.id}/usage`);
      } catch (error) {
        result = { error: errorText(error) };
      }
      if (revision !== state.dashboardRevision) return;
      usage.set(profile.id, result);
      setDashboardLoading(true, ++done, total);
    }
  }));
  if (revision !== state.dashboardRevision) return;
  state.usage = usage;
  state.dashboard.updatedAt = new Date();
  setDashboardLoading(false);
  renderProfiles();
}

// 重新整理按鈕旁顯示上次取得使用量的時間，讓「重新取得」有對照基準。
function renderUpdatedAt() {
  const element = byId("profiles-updated");
  const { updatedAt } = state.dashboard;
  if (!updatedAt) {
    element.textContent = "";
    delete element.dataset.tip;
    return;
  }
  element.textContent = `更新於 ${updatedAt.toLocaleTimeString("zh-TW", { hour: "2-digit", minute: "2-digit", hour12: false })}`;
  element.dataset.tip = `使用量取得時間\n${formatDateTime(updatedAt.toISOString())}`;
}

function profileName(profile) {
  return personName(profile.ownerPersonId) ?? `${TERMS.profile.zh} #${profile.id}`;
}

function usageValue(profile, field) {
  const usage = state.usage.get(profile.id);
  if (!usage) return "載入中…";
  if (usage.error) return "—";
  return formatNumber(usage[field]) ?? "未提供";
}

function buildRow(profile) {
  const usage = state.usage.get(profile.id) ?? null;
  const number = field => (usage && !usage.error ? formatNumber(usage[field]) === null ? null : usage[field] : null);
  return {
    profile,
    id: profile.id,
    name: profileName(profile),
    status: profile.status,
    usage,
    error: usage?.error ?? null,
    limit: number("limit"),
    used: number("used"),
    remaining: number("remaining"),
    rate: usageRate(usage)
  };
}

function buildRows() {
  return state.profiles.map(buildRow);
}

function usageTip(row) {
  if (row.error) return `使用量無法取得\n${row.error}`;
  if (row.rate === null) return "額度或使用量未提供";
  return `使用率 ${formatPercent(row.rate)}\n額度 ${formatNumber(row.limit) ?? "未提供"}\n已使用 ${formatNumber(row.used) ?? "未提供"}\n剩餘 ${formatNumber(row.remaining) ?? "未提供"}`;
}

function usageCell(row, size = 40) {
  if (row.error) {
    const wrapper = el("span", "inline-flex items-center justify-center tone-danger");
    wrapper.dataset.tip = usageTip(row);
    wrapper.style.width = `${size}px`;
    wrapper.style.height = `${size}px`;
    const alert = icon("alert-triangle");
    alert.style.width = `${Math.round(size * 0.55)}px`;
    alert.style.height = `${Math.round(size * 0.55)}px`;
    wrapper.append(alert);
    return wrapper;
  }
  return donut({ rate: row.rate, size, tip: usageTip(row) });
}

function numberCell(value, tip) {
  const cell = el("td", "num", formatNumber(value) ?? "—");
  if (formatNumber(value) === null) cell.classList.add("tone-muted");
  if (tip) cell.dataset.tip = tip;
  return cell;
}

function compareRows(field, direction) {
  if (!field) return () => 0;
  const sign = direction === "desc" ? -1 : 1;
  const type = SORT_COLUMNS[field]?.type ?? "number";
  const statusOrder = Object.keys(STATUS_META);
  return (left, right) => {
    if (type === "text") return left.name.localeCompare(right.name, "zh-Hant-TW") * sign || left.id - right.id;
    if (type === "status") {
      const a = statusOrder.indexOf(left.status);
      const b = statusOrder.indexOf(right.status);
      const rank = value => (value === -1 ? statusOrder.length : value);
      return (rank(a) - rank(b)) * sign || String(left.status).localeCompare(String(right.status)) * sign || left.id - right.id;
    }
    const a = left[field];
    const b = right[field];
    const aKnown = typeof a === "number" && Number.isFinite(a);
    const bKnown = typeof b === "number" && Number.isFinite(b);
    if (aKnown !== bKnown) return aKnown ? -1 : 1;
    if (!aKnown || a === b) return left.id - right.id;
    return (a - b) * sign;
  };
}

// 三張 KPI 卡片的標題固定；載入骨架與正式渲染共用，重新整理時標題不消失。
const KPI_TITLES = Object.freeze({ quota: "整體額度使用率", rate: "使用率分布", status: `${TERMS.profile.zh}狀態` });

function skeletonLine(width, height, inline = false) {
  const line = el("span", "skeleton");
  // inline 模式放在文字段落內，讓段落維持原本的行高，換回真實文字時不會位移。
  line.style.display = inline ? "inline-block" : "block";
  line.style.verticalAlign = inline ? "middle" : "";
  line.style.height = height;
  line.style.width = width;
  return line;
}

// 載入期間保留卡片標題，只有內容換成骨架，避免整塊消失再重現。
function renderKpiSkeleton() {
  const grid = byId("kpi-grid");
  grid.replaceChildren();
  for (const title of Object.values(KPI_TITLES)) {
    const { tile, body } = kpiTile(title);
    tile.setAttribute("aria-busy", "true");
    body.setAttribute("aria-hidden", "true");
    const row = el("div", "kpi-chart-row");
    const circle = el("span", "skeleton skeleton-arc");
    const lines = el("div", "kpi-list");
    lines.style.gap = "0.7rem";
    for (const width of ["85%", "70%", "75%"]) lines.append(skeletonLine(width, "0.9rem"));
    row.append(circle, lines);
    body.append(row);
    grid.append(tile);
  }
}

// KPI 卡片與清單面板共用同一種版面：標題列在上、內容在下。
// hint 可為文字或節點（骨架），節點會包在同樣的 .hint 段落裡以維持高度。
function kpiTile(title, hint) {
  const tile = el("section", "panel kpi");
  tile.setAttribute("aria-label", title);
  const header = el("div", "panel-header");
  const heading = el("div");
  heading.append(el("h2", "", title));
  if (typeof hint === "string") heading.append(el("p", "hint", hint));
  else if (hint) {
    const slot = el("p", "hint");
    slot.append(hint);
    heading.append(slot);
  }
  header.append(heading);
  const body = el("div", "kpi-body");
  tile.append(header, body);
  return { tile, body };
}

// 明細列；segment 對應環狀圖的區段 key，hover 時兩者互相打亮。
function legendItem(label, value, toneClass, iconName, { segment, tip } = {}) {
  const item = el("li");
  if (segment) item.dataset.segment = segment;
  if (tip) item.dataset.tip = tip;
  const legend = el("span", `legend ${toneClass}`);
  legend.append(iconName ? icon(iconName, "icon icon-sm") : el("span", "dot"), el("span", "legend-label", label));
  item.append(legend, el("b", "", String(value)));
  return item;
}

// 可點選的明細列：切換清單篩選條件，aria-pressed 表示目前是否生效。
function filterItem(label, count, toneClass, iconName, { pressed, onToggle, filterKey, segment }) {
  const item = el("li", "is-action");
  const control = el("button", "kpi-item");
  control.type = "button";
  control.dataset.filter = filterKey;
  if (segment) control.dataset.segment = segment;
  control.setAttribute("aria-pressed", String(pressed));
  control.dataset.tip = pressed ? "再點一次取消此篩選" : `點擊後清單只顯示這些${TERMS.profile.zh}`;
  const legend = el("span", `legend ${toneClass}`);
  legend.append(iconName ? icon(iconName, "icon icon-sm") : el("span", "dot"), el("span", "legend-label", label));
  control.append(legend, el("b", "", String(count)));
  control.addEventListener("click", onToggle);
  item.append(control);
  return item;
}

function toggleFilter(set, key) {
  if (set.has(key)) set.delete(key);
  else set.add(key);
  renderProfiles();
}

// 群組全選：已全選就整組清空，否則把所有選項加進去。
function toggleFilterGroup(set, keys) {
  const allSelected = keys.every(key => set.has(key));
  if (allSelected) set.clear();
  else for (const key of keys) set.add(key);
  renderProfiles();
}

// 各篩選維度的全體數量；KPI 卡片與篩選選單共用，數字一律以全體資料計算。
function filterCounts(rows) {
  const statuses = new Map();
  for (const row of rows) statuses.set(row.status, (statuses.get(row.status) ?? 0) + 1);
  const buckets = { danger: 0, warning: 0, success: 0, muted: 0 };
  for (const row of rows) buckets[usageBucket(row.rate)] += 1;
  // 未定義在 STATUS_META 的狀態排在已知狀態之後。
  const statusOrder = [...Object.keys(STATUS_META), ...[...statuses.keys()].filter(key => !STATUS_META[key])];
  return { statuses, buckets, statusOrder };
}

function clearFilters() {
  state.dashboard.statuses.clear();
  state.dashboard.buckets.clear();
  renderProfiles();
}

// KPI 卡片：左側大環狀圖、右側明細列。區段與明細列以 data-segment 連動 hover，
// 狀態／使用率的區段與明細列都可點擊切換清單篩選。
function renderKpis(rows) {
  const grid = byId("kpi-grid");
  grid.replaceChildren();
  const share = (value, total) => (total > 0 ? `${Math.round((value / total) * 100)}%` : "—");
  const chartRow = (chart, list) => {
    const row = el("div", "kpi-chart-row");
    row.append(chart, list);
    return row;
  };

  // 1. 整體額度
  const withNumbers = rows.filter(row => row.limit !== null && row.used !== null);
  const totalLimit = withNumbers.reduce((sum, row) => sum + row.limit, 0);
  const totalUsed = withNumbers.reduce((sum, row) => sum + row.used, 0);
  const totalRemaining = totalLimit - totalUsed;
  const overallRate = totalLimit > 0 ? totalUsed / totalLimit : null;
  const usedTone = usageTone(overallRate);
  const coverage = `${withNumbers.length} / ${rows.length} 個 ${TERMS.profile.zh}納入統計`;
  const quota = kpiTile(KPI_TITLES.quota);
  const quotaChart = ringChart({
    segments: overallRate === null ? [] : [
      { key: "used", label: "已使用", value: totalUsed, valueText: formatNumber(totalUsed), tone: usedTone, tip: `已使用\n${formatNumber(totalUsed)}（${share(totalUsed, totalLimit)}）` },
      { key: "remaining", label: "剩餘", value: Math.max(0, totalRemaining), valueText: formatNumber(Math.max(0, totalRemaining)), track: true, tip: `剩餘\n${formatNumber(Math.max(0, totalRemaining))}（${share(Math.max(0, totalRemaining), totalLimit)}）` }
    ],
    center: {
      value: formatPercent(overallRate),
      tone: overallRate === null ? "tone-muted" : usedTone,
      tip: overallRate === null ? `尚無可統計的額度資料\n${coverage}` : `整體使用率 ${formatPercent(overallRate)}\n${coverage}`
    }
  });
  // 沒有任何 Profile 納入統計時，加總出來的 0 不是真實數值，一律顯示「—」。
  const quotaNumber = value => (withNumbers.length === 0 ? "—" : formatNumber(value) ?? "—");
  const quotaList = el("ul", "kpi-list");
  quotaList.append(
    legendItem("已使用", quotaNumber(totalUsed), usedTone, "activity", { segment: "used" }),
    legendItem("剩餘", overallRate === null ? "—" : formatNumber(totalRemaining), "tone-muted", "pie", { segment: "remaining" }),
    legendItem("額度", quotaNumber(totalLimit), "tone-muted", "database"),
    legendItem("納入統計", `${withNumbers.length} / ${rows.length}`, "tone-muted", "info", { tip: `僅計算有回傳額度與使用量的${TERMS.profile.zh}` })
  );
  quota.body.append(chartRow(quotaChart, quotaList));
  grid.append(quota.tile);

  const { statuses: statusCounts, buckets, statusOrder } = filterCounts(rows);

  // 2. 使用率分布
  const rateTile = kpiTile(KPI_TITLES.rate);
  const rateChart = ringChart({
    segments: Object.entries(USAGE_BUCKETS).map(([key, meta]) => ({
      key: `bucket:${key}`, label: meta.label, value: buckets[key], tone: `tone-${meta.tone}`,
      tip: `${meta.label}\n${buckets[key]} 個（${share(buckets[key], rows.length)}）`,
      pressed: state.dashboard.buckets.has(key),
      onToggle: () => toggleFilter(state.dashboard.buckets, key)
    })),
    center: {
      value: String(buckets.danger),
      label: `> ${Math.round(USAGE_THRESHOLDS.danger * 100)}%`,
      tone: buckets.danger > 0 ? "tone-danger" : "tone-success",
      tip: `${buckets.danger} 個 ${TERMS.profile.zh}使用率 > ${Math.round(USAGE_THRESHOLDS.danger * 100)}%`
    }
  });
  const rateList = el("ul", "kpi-list");
  for (const [key, meta] of Object.entries(USAGE_BUCKETS)) {
    rateList.append(filterItem(meta.label, buckets[key], `tone-${meta.tone}`, undefined, {
      pressed: state.dashboard.buckets.has(key),
      onToggle: () => toggleFilter(state.dashboard.buckets, key),
      filterKey: `bucket:${key}`,
      segment: `bucket:${key}`
    }));
  }
  rateTile.body.append(chartRow(rateChart, rateList));
  grid.append(rateTile.tile);

  // 3. Profile 狀態分布
  const statusTile = kpiTile(KPI_TITLES.status);
  const statusChart = ringChart({
    segments: statusOrder.map(key => {
      const meta = STATUS_META[key];
      const count = statusCounts.get(key) ?? 0;
      return {
        key: `status:${key}`, label: meta?.label ?? key, value: count, tone: `tone-${meta?.tone ?? "muted"}`,
        tip: `${meta?.label ?? key}\n${count} 個（${share(count, rows.length)}）`,
        pressed: state.dashboard.statuses.has(key),
        onToggle: () => toggleFilter(state.dashboard.statuses, key)
      };
    }),
    center: { value: String(rows.length), label: "帳號" }
  });
  const statusList = el("ul", "kpi-list");
  for (const key of statusOrder) {
    const meta = STATUS_META[key];
    statusList.append(filterItem(meta?.label ?? key, statusCounts.get(key) ?? 0, `tone-${meta?.tone ?? "muted"}`, meta?.icon, {
      pressed: state.dashboard.statuses.has(key),
      onToggle: () => toggleFilter(state.dashboard.statuses, key),
      filterKey: `status:${key}`,
      segment: `status:${key}`
    }));
  }
  statusTile.body.append(chartRow(statusChart, statusList));
  grid.append(statusTile.tile);
}

function noMatchState() {
  if (state.profiles.length === 0) return emptyState(`目前沒有${TERMS.profile.zh}`, `尚未建立任何${TERMS.profile.zh}。`);
  const box = emptyState(`沒有符合條件的${TERMS.profile.zh}`, "試著調整搜尋關鍵字或篩選條件。", "search");
  if (activeFilterCount() > 0) {
    const clear = button("清除篩選", clearFilters, "btn btn-secondary btn-sm");
    clear.prepend(icon("x", "icon icon-sm"));
    clear.style.marginTop = "0.5rem";
    box.append(clear);
  }
  return box;
}

function renderProfileTable(rows) {
  const container = byId("profiles-table");
  container.replaceChildren();
  if (rows.length === 0) {
    container.append(noMatchState());
    return;
  }
  const table = el("table");
  const head = el("thead");
  const headRow = el("tr");
  const columns = [
    { key: "name" },
    { key: "status" },
    { key: "rate" },
    { key: "limit", num: true },
    { key: "used", num: true },
    { key: "remaining", num: true },
    { label: "" }
  ];
  const { sortKey, sortDir } = state.dashboard;
  for (const column of columns) {
    const th = el("th", column.num ? "num" : "");
    th.scope = "col";
    if (!column.key) {
      th.textContent = column.label;
      headRow.append(th);
      continue;
    }
    const active = sortKey === column.key;
    const { label, defaultDir } = SORT_COLUMNS[column.key];
    th.setAttribute("aria-sort", active ? (sortDir === "asc" ? "ascending" : "descending") : "none");
    const sortButton = el("button", "th-sort");
    sortButton.type = "button";
    sortButton.dataset.active = String(active);
    const dirText = dir => (dir === "asc" ? "由低到高" : "由高到低");
    sortButton.dataset.tip = !active
      ? `依${label}排序（${dirText(defaultDir)}）`
      : sortDir === defaultDir ? `點擊改為${dirText(sortDir === "asc" ? "desc" : "asc")}` : "點擊取消排序";
    sortButton.append(document.createTextNode(label), icon(active ? (sortDir === "asc" ? "arrow-up" : "arrow-down") : "sort"));
    sortButton.addEventListener("click", () => cycleSort(column.key));
    th.append(sortButton);
    headRow.append(th);
  }
  head.append(headRow);
  table.append(head);
  const body = el("tbody");
  for (const row of rows) {
    const tr = el("tr");
    const nameCell = el("td");
    nameCell.append(el("div", "row-title", row.name), idSub(row.id, "Profile ID"));
    const statusCell = el("td");
    statusCell.append(statusBadge(row.status));
    const rateCell = el("td");
    rateCell.append(usageCell(row));
    const actionCell = el("td", "num");
    const detail = button("查看詳情", () => navigate("profile-detail", row.id), "btn btn-secondary btn-sm");
    detail.append(icon("arrow-right", "icon icon-sm"));
    actionCell.append(detail);
    tr.append(nameCell, statusCell, rateCell, numberCell(row.limit), numberCell(row.used), numberCell(row.remaining), actionCell);
    body.append(tr);
  }
  table.append(body);
  container.append(table);
}

function renderProfileCards(rows) {
  const container = byId("profiles-table");
  container.replaceChildren();
  if (rows.length === 0) {
    container.append(noMatchState());
    container.lastChild.style.gridColumn = "1 / -1";
    return;
  }
  for (const row of rows) {
    const card = el("article", "profile-card");
    const head = el("div", "profile-card-head");
    const title = el("div");
    title.append(el("div", "row-title", row.name), idSub(row.id, "Profile ID"));
    head.append(title, statusBadge(row.status));
    const body = el("div", "profile-card-body");
    const dl = el("dl");
    for (const [label, value] of [["額度", row.limit], ["已使用", row.used], ["剩餘", row.remaining]]) {
      const dd = el("dd", formatNumber(value) === null ? "tone-muted" : "", formatNumber(value) ?? "—");
      dl.append(el("dt", "", label), dd);
    }
    body.append(usageCell(row, 64), dl);
    const foot = el("div", "profile-card-foot");
    const detail = button("查看詳情", () => navigate("profile-detail", row.id), "btn btn-secondary btn-sm");
    detail.append(icon("arrow-right", "icon icon-sm"));
    foot.append(detail);
    card.append(head, body, foot);
    container.append(card);
  }
}

// 篩選維度定義：篩選選單依此列出選項；set() 回傳對應的 state 集合。
const FILTER_DIMENSIONS = Object.freeze({
  status: {
    label: "狀態",
    set: () => state.dashboard.statuses,
    options: counts => counts.statusOrder.map(key => ({
      key,
      label: STATUS_META[key]?.label ?? key,
      icon: STATUS_META[key]?.icon,
      tone: STATUS_META[key]?.tone ?? "muted",
      count: counts.statuses.get(key) ?? 0
    }))
  },
  bucket: {
    label: "使用率",
    set: () => state.dashboard.buckets,
    options: counts => Object.entries(USAGE_BUCKETS).map(([key, meta]) => ({
      key,
      label: meta.label,
      tone: meta.tone,
      count: counts.buckets[key]
    }))
  }
});

function activeFilterCount() {
  return state.dashboard.statuses.size + state.dashboard.buckets.size;
}

// 工具列的篩選按鈕與 popover：勾選即時生效，與 KPI 卡片共用同一份 state。
function renderFilterMenu(counts, matched, total) {
  const count = activeFilterCount();
  const badge = byId("filter-count");
  badge.textContent = String(count);
  badge.hidden = count === 0;
  byId("filter-toggle").classList.toggle("is-active", count > 0);

  const popover = byId("filter-popover");
  popover.replaceChildren();
  for (const [section, dimension] of Object.entries(FILTER_DIMENSIONS)) {
    const group = el("div", "filter-section");
    group.setAttribute("role", "group");
    group.setAttribute("aria-label", dimension.label);
    const options = dimension.options(counts);
    const selectedCount = options.filter(option => dimension.set().has(option.key)).length;
    const head = el("div", "filter-section-head");
    head.append(el("p", "filter-section-title", dimension.label));
    const selectAll = el("label", "filter-select-all");
    const allBox = el("input");
    allBox.type = "checkbox";
    allBox.checked = options.length > 0 && selectedCount === options.length;
    allBox.indeterminate = selectedCount > 0 && selectedCount < options.length;
    allBox.dataset.filter = `${section}:*`;
    allBox.setAttribute("aria-label", `${dimension.label}全選`);
    allBox.addEventListener("change", () => toggleFilterGroup(dimension.set(), options.map(option => option.key)));
    selectAll.dataset.tip = allBox.checked ? "取消整組" : "選取整組";
    selectAll.append(allBox, document.createTextNode("全選"));
    head.append(selectAll);
    group.append(head);
    for (const option of options) {
      const row = el("label", "filter-option");
      const checkbox = el("input");
      checkbox.type = "checkbox";
      checkbox.checked = dimension.set().has(option.key);
      checkbox.dataset.filter = `${section}:${option.key}`;
      checkbox.addEventListener("change", () => toggleFilter(dimension.set(), option.key));
      const legend = el("span", `legend tone-${option.tone}`);
      legend.append(option.icon ? icon(option.icon, "icon icon-sm") : el("span", "dot"), el("span", "legend-label", option.label));
      row.append(checkbox, legend, el("b", "", String(option.count)));
      group.append(row);
    }
    popover.append(group);
  }
  const foot = el("div", "filter-foot");
  foot.append(el("span", "hint", `符合 ${matched} / ${total} 個`));
  const clear = button("清除全部", () => {
    clearFilters();
    // 重繪後原按鈕已被換掉且停用，把焦點移回選單第一個選項。
    setFilterMenuOpen(true);
  }, "btn btn-ghost btn-sm");
  clear.disabled = count === 0;
  foot.append(clear);
  popover.append(foot);
}

function renderProfiles() {
  if (state.dashboardLoading) return;
  tooltip.hide();
  syncToolbar();
  const keyword = byId("profile-filter").value.trim().toLocaleLowerCase();
  const { sortKey, sortDir, statuses, buckets, mode } = state.dashboard;
  const allRows = buildRows();
  const rows = allRows.filter(row => {
    if (statuses.size > 0 && !statuses.has(row.status)) return false;
    if (buckets.size > 0 && !buckets.has(usageBucket(row.rate))) return false;
    if (!keyword) return true;
    // 編號可用「#101」「101」或「編號 101」搜尋。
    return row.name.toLocaleLowerCase().includes(keyword) || String(row.id).includes(keyword.replace(/^(#|編號\s*)/, ""));
  });
  rows.sort(compareRows(sortKey, sortDir));
  byId("profile-count").textContent = `${rows.length} / ${allRows.length} 個 ${TERMS.profile.zh}`;
  renderUpdatedAt();
  renderKpis(allRows);
  const counts = filterCounts(allRows);
  renderFilterMenu(counts, rows.length, allRows.length);
  if (mode === "cards") renderProfileCards(rows);
  else renderProfileTable(rows);
}

async function setProfileStatus(profileId, status) {
  await runSection("detail", async () => {
    await requestJson(`${api.profiles}/${profileId}/status`, { method: "PUT", body: { status } });
    const profile = state.profiles.find(item => item.id === profileId);
    if (profile) profile.status = status;
    await loadDetail();
  });
}

// Grant 表單的日期欄位；失效為必填且必須晚於生效。
const grantDates = {
  from: datetimeField(byId("grant-effective-from")),
  until: null
};
grantDates.until = datetimeField(byId("grant-effective-until"), { after: grantDates.from });
for (const field of Object.values(grantDates)) field.subscribe(() => revalidateForm(byId("grant-form")));

function resetGrantForm() {
  byId("grant-form").reset();
  byId("grant-id").value = "";
  byId("grant-enabled").checked = true;
  grantDates.from.set(new Date());
  grantDates.until.set(addDays(new Date(), 30));
}

// 使用人員下拉：依名稱排序列出所有人員，停用者加註；編輯中的授權指向名單外的人員時仍以「人員 #id」顯示。
function fillOperatorOptions(selectedId = null) {
  const select = byId("grant-operator-id");
  select.replaceChildren(new Option(`請選擇${TERMS.person.zh}`, "", true, selectedId === null));
  select.options[0].disabled = true;
  const persons = [...state.persons].sort((a, b) => String(a.displayName).localeCompare(String(b.displayName), "zh-TW"));
  for (const person of persons) {
    select.append(new Option(`${formatValue(person.displayName)}（編號 ${person.id}）${person.enabled ? "" : "・已停用"}`, String(person.id), false, person.id === selectedId));
  }
  if (selectedId !== null && !personById(selectedId)) select.append(new Option(personLabel(selectedId), String(selectedId), false, true));
}

// 不帶 grant 為新增；帶 grant 為編輯（API 不允許改 Operator，下拉鎖定）。Profile 不再是表單欄位，顯示在副標。
async function openGrantDrawer(grant = null) {
  resetGrantForm();
  try {
    await ensurePersons();
  } catch {
    // 名單抓不到仍可開表單，下拉只剩 placeholder；送出時會被必填擋下。
  }
  fillOperatorOptions(grant?.operatorPersonId ?? null);
  byId("grant-operator-id").disabled = grant !== null;
  if (grant) {
    byId("grant-id").value = grant.id;
    byId("grant-enabled").checked = grant.enabled;
    grantDates.from.set(grant.effectiveFrom);
    grantDates.until.set(grant.effectiveUntil);
    markEditingRow("grants-table", grant.id);
  }
  const profile = state.profiles.find(item => item.id === state.selectedProfileId);
  const profileLabel = `${TERMS.profile.zh} ${profile ? `${profileName(profile)}（編號 ${profile.id}）` : `編號 ${state.selectedProfileId}`}`;
  openDrawer("grant-drawer", {
    title: termNode("grant", grant ? "編輯" : "新增"),
    subtitle: grant ? `${TERMS.grant.zh}編號 ${grant.id} · ${profileLabel}` : profileLabel,
    focusId: grant ? "grant-effective-from" : "grant-operator-id"
  });
}

function grantActions(grant) {
  const actions = el("div", "actions");
  const edit = button("編輯", () => openGrantDrawer(grant), "btn btn-secondary btn-sm");
  edit.prepend(icon("edit", "icon icon-sm"));
  const revoke = button("撤銷", () => revokeGrant(grant), "btn btn-danger btn-sm");
  revoke.prepend(icon("trash", "icon icon-sm"));
  revoke.disabled = Boolean(grant.revokedAt);
  actions.append(edit, revoke);
  return actions;
}

function grantStatusBadge(grant) {
  if (grant.revokedAt) {
    const badge = el("span", "badge badge-danger");
    badge.dataset.tip = `撤銷於 ${formatDateTime(grant.revokedAt)}`;
    badge.append(icon("ban"), document.createTextNode("已撤銷"));
    return badge;
  }
  return boolBadge(grant.enabled);
}

async function loadGrants() {
  const profileId = state.selectedProfileId;
  const revision = state.viewRevision;
  if (profileId === null) return;
  const grants = requireArray(await requestJson(`${api.grants}?profileId=${profileId}`));
  if (revision !== state.viewRevision) return;
  state.grants = grants;
  renderTable("grants-table", [
    { label: termNode("operator"), render: row => personCell(row.operatorPersonId, { sub: `${TERMS.grant.zh}編號 ${row.id}` }) },
    { label: "狀態", render: grantStatusBadge },
    { label: "生效", render: row => dateNode(row.effectiveFrom) },
    { label: "失效", render: row => dateNode(row.effectiveUntil) }
  ], state.grants, grantActions, { rowKey: row => row.id, emptyTitle: `尚無${TERMS.grant.zh}`, emptyDescription: `點擊「新增${TERMS.grant.zh}」讓其他${TERMS.person.zh}使用此${TERMS.profile.zh}。`, emptyIcon: "users" });
}

async function saveGrant(event) {
  event.preventDefault();
  const form = byId("grant-form");
  if (!validateForm(form)) return;
  const id = byId("grant-id").value;
  const body = {
    profileId: state.selectedProfileId,
    operatorPersonId: Number(byId("grant-operator-id").value),
    enabled: byId("grant-enabled").checked,
    effectiveFrom: grantDates.from.value,
    effectiveUntil: grantDates.until.value
  };
  const updateBody = {
    enabled: body.enabled,
    effectiveFrom: body.effectiveFrom,
    effectiveUntil: body.effectiveUntil
  };
  setFormError(form, "");
  setFormBusy(form, true);
  try {
    await requestJson(id ? `${api.grants}/${id}` : api.grants, {
      method: id ? "PUT" : "POST",
      body: id ? updateBody : body
    });
  } catch (error) {
    setFormError(form, errorText(error));
    return;
  } finally {
    setFormBusy(form, false);
  }
  const before = new Set(state.grants.map(grant => grant.id));
  requestCloseDrawer(byId("grant-drawer"), { force: true });
  await runSection("grants", async () => {
    await Promise.all([loadGrants(), loadLeases()]);
    flashRow("grants-table", id ? Number(id) : state.grants.find(grant => !before.has(grant.id))?.id);
  });
}

async function revokeGrant(grant) {
  if (!globalThis.confirm(`確定撤銷「${personLabel(grant.operatorPersonId)}」的${TERMS.grant.zh}（${TERMS.grant.zh}編號 ${grant.id}）？`)) return;
  await runSection("grants", async () => {
    await requestJson(`${api.grants}/${grant.id}`, { method: "DELETE" });
    await Promise.all([loadGrants(), loadLeases()]);
  });
}

function leaseActions(lease) {
  const actions = el("div", "actions is-stacked");
  const releasable = ["ACTIVE", "STALE"].includes(lease.status);
  if (!releasable) {
    actions.append(el("span", "hint", "—"));
    return actions;
  }
  const reason = document.createElement("input");
  reason.placeholder = `${TERMS.forceRelease.zh}原因`;
  reason.maxLength = 500;
  reason.setAttribute("aria-label", `${TERMS.forceRelease.zh}「${personLabel(lease.operatorPersonId)}」的${TERMS.lease.zh} ${lease.id}：原因`);
  const release = button("強制釋放", () => forceRelease(lease, reason), "btn btn-danger btn-sm");
  release.prepend(icon("unlock", "icon icon-sm"));
  actions.append(reason, release);
  return actions;
}

async function loadLeases() {
  const profileId = state.selectedProfileId;
  const revision = state.viewRevision;
  if (profileId === null) return;
  const leases = requireArray(await requestJson(`${api.leases}?profileId=${profileId}`));
  if (revision !== state.viewRevision) return;
  state.leases = leases;
  renderTable("leases-table", [
    // Client 放在人員欄的第二行小字：半寬面板放不下獨立欄位。
    { label: termNode("operator"), render: row => personCell(row.operatorPersonId, { sub: [`紀錄編號 ${formatValue(row.id)}`, `Client ${formatValue(row.clientId)}`] }) },
    { label: "狀態", render: row => leaseBadge(row.status) },
    { label: "期間", render: row => {
      const node = el("div", "row-sub whitespace-nowrap");
      const acquired = el("div");
      acquired.append(document.createTextNode("取得 "), dateNode(row.acquiredAt));
      const ended = el("div");
      ended.append(document.createTextNode("結束 "), dateNode(row.endedAt));
      node.append(acquired, ended);
      return node;
    } }
  ], state.leases, leaseActions, { emptyTitle: `尚無${TERMS.lease.zh}`, emptyDescription: `此${TERMS.profile.zh}目前沒有任何${TERMS.lease.zh}。`, emptyIcon: "clock" });
}

async function forceRelease(lease, reasonInput) {
  const reason = reasonInput.value.trim();
  if (!reason) {
    setSectionMessage("leases", `${TERMS.forceRelease.zh}必須填寫原因。`, "error");
    reasonInput.focus();
    return;
  }
  if (!globalThis.confirm(`確定${TERMS.forceRelease.zh}「${personLabel(lease.operatorPersonId)}」的${TERMS.lease.zh}（${lease.id}）？`)) return;
  await runSection("leases", async () => {
    await requestJson(`${api.leases}/${encodeURIComponent(lease.id)}/force-release`, {
      method: "POST",
      body: { reason }
    });
    await loadLeases();
  });
}

function resultBadge(result) {
  const meta = RESULT_META[String(result).toUpperCase()];
  const badge = el("span", `badge ${meta ? `badge-${meta.tone}` : "badge-muted"}`);
  badge.dataset.tip = `結果：${formatValue(result)}`;
  badge.append(icon(meta?.icon ?? "info"), document.createTextNode(meta?.label ?? formatValue(result)));
  return badge;
}

// 動作代碼：有對照就顯示中文並把原始代碼放 data-tip，沒有就原樣以等寬字呈現。
function auditActionNode(action) {
  const label = AUDIT_ACTION_LABELS[action];
  const node = el("span", label ? "" : "mono", label ?? formatValue(action));
  if (label) node.dataset.tip = `動作代碼：${action}`;
  return node;
}

// 目標：類型改中文，人員與 ChatGPT 帳號能反查時附上名稱；編號小字 hover 顯示原始類型與 ID。
function auditTargetCell(row) {
  const termKey = AUDIT_TARGET_TERMS[row.targetType];
  let title = termKey ? TERMS[termKey].zh : formatValue(row.targetType);
  const name = row.targetType === "PERSON"
    ? personName(row.targetId)
    : row.targetType === "PROFILE"
      ? (profile => (profile ? profileName(profile) : null))(state.profiles.find(item => String(item.id) === String(row.targetId)))
      : null;
  if (name) title += `：${name}`;
  const node = el("div");
  node.append(el("div", "row-title", title), idSub(row.targetId, formatValue(row.targetType)));
  return node;
}

async function loadAudit() {
  const [audit, persons] = await Promise.all([
    requestJson(api.audit),
    state.persons.length ? state.persons : requestJson(api.persons)
  ]);
  state.audit = requireArray(audit);
  setPersons(persons);
  byId("audit-count").textContent = `${state.audit.length} 筆紀錄 · `;
  renderTable("audit-table", [
    { label: "時間", render: row => dateNode(row.occurredAt) },
    { label: termNode("actor"), render: row => personCell(row.actorPersonId) },
    { label: "動作", render: row => auditActionNode(row.action) },
    { label: "目標", render: row => auditTargetCell(row) },
    { label: "結果", render: row => resultBadge(row.result) },
    { label: "原因", value: row => row.reason },
    { label: termNode("correlation"), value: row => row.correlationId, className: "mono" }
  ], state.audit, null, { emptyTitle: "尚無操作紀錄", emptyIcon: "history" });
}

const loaders = Object.freeze({
  persons: loadPersons,
  profiles: loadProfiles,
  grants: loadGrants,
  leases: loadLeases,
  audit: loadAudit
});

function renderDetailQuota(profile) {
  const row = buildRow(profile);
  const loading = !state.usage.has(profile.id);
  const donutBox = byId("detail-donut");
  if (loading) donutBox.replaceChildren(donut({ rate: null, size: 112, stroke: 12, label: "…", tone: "tone-muted" }));
  else donutBox.replaceChildren(usageCell(row, 112));
  for (const [id, value] of [["detail-limit", row.limit], ["detail-used", row.used], ["detail-remaining", row.remaining]]) {
    const target = byId(id);
    const text = formatNumber(value);
    target.textContent = loading ? "…" : text ?? (row.error ? "—" : "未提供");
    target.classList.toggle("tone-muted", loading || text === null);
  }
  const reset = byId("detail-reset");
  const seconds = row.usage?.resetAfterSeconds;
  reset.replaceChildren();
  if (loading) reset.textContent = "…";
  else if (typeof seconds === "number" && Number.isFinite(seconds)) {
    reset.append(document.createTextNode(Math.max(0, seconds / 86400).toFixed(1)), el("small", "", " 天"));
    reset.dataset.tip = `${Math.round(seconds).toLocaleString("zh-TW")} 秒`;
  } else {
    reset.textContent = row.error ? "—" : "未提供";
    delete reset.dataset.tip;
  }
  reset.classList.toggle("tone-muted", loading || typeof seconds !== "number");
  if (row.error) setSectionMessage("detail", `額度摘要無法取得：${row.error}`, "error");
}

function setDetailStat(id, text, muted = false) {
  const target = byId(id);
  target.textContent = text;
  target.classList.toggle("tone-muted", muted);
}

function setDetailRefreshing(refreshing) {
  const control = byId("detail-refresh");
  control.disabled = refreshing;
  control.querySelector(".icon")?.classList.toggle("is-spinning", refreshing);
}

// ------------------------------------------------------------------
// 每日使用量統計區間
// 區間以瀏覽器本地「今天」為基準，日期一律用 YYYY-MM-DD 字串比較（API 的 date 即此格式）。
// bounds 回傳 [起, 迄]（含兩端）；null 代表不過濾（全部）。
// ------------------------------------------------------------------
const USAGE_RANGES = Object.freeze({
  "7d": { label: "近一週", tip: "最近 7 天（含今天）", bounds: today => [addDays(today, -6), today] },
  "prev-week": { label: "上一週", tip: "上週一到上週日", bounds: today => { const monday = addDays(today, -((today.getDay() + 6) % 7)); return [addDays(monday, -7), addDays(monday, -1)]; } },
  "30d": { label: "近一個月", tip: "最近 30 天（含今天）", bounds: today => [addDays(today, -29), today] },
  "this-month": { label: "本月", tip: "本月 1 日到今天", bounds: today => [new Date(today.getFullYear(), today.getMonth(), 1), today] },
  "prev-month": { label: "上個月", tip: "上個月 1 日到月底", bounds: today => [new Date(today.getFullYear(), today.getMonth() - 1, 1), new Date(today.getFullYear(), today.getMonth(), 0)] },
  all: { label: "全部", tip: "帳號回傳的所有每日資料", bounds: null }
});

function addDays(date, days) {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate() + days);
}

function dateKey(date) {
  return `${date.getFullYear()}-${pad2(date.getMonth() + 1)}-${pad2(date.getDate())}`;
}

function formatDateKey(key) {
  return typeof key === "string" && key.length >= 10 ? key.slice(0, 10).replaceAll("-", "/") : formatValue(key);
}

// 區間邊界（YYYY-MM-DD 字串）；「全部」回傳 null。
function usageRangeBounds(key, today = new Date()) {
  const range = USAGE_RANGES[key];
  if (!range?.bounds) return null;
  const [from, to] = range.bounds(today);
  return { from: dateKey(from), to: dateKey(to) };
}

function usageRangeRows(key, daily) {
  const bounds = usageRangeBounds(key);
  if (!bounds) return daily;
  return daily.filter(day => {
    const date = String(day.date ?? "").slice(0, 10);
    return date >= bounds.from && date <= bounds.to;
  });
}

function renderUsageRangeStats(key, rows) {
  const stats = byId("usage-range-stats");
  stats.hidden = rows.length === 0;
  if (!rows.length) return;
  const bounds = usageRangeBounds(key);
  const dates = rows.map(day => String(day.date ?? "").slice(0, 10)).sort();
  const span = bounds ?? { from: dates[0], to: dates[dates.length - 1] };
  const counted = rows.filter(day => typeof day.tokens === "number" && Number.isFinite(day.tokens));
  const total = counted.reduce((sum, day) => sum + day.tokens, 0);
  const peak = counted.reduce((best, day) => (best === null || day.tokens > best.tokens ? day : best), null);

  const spanNode = byId("usage-range-span");
  spanNode.replaceChildren(`${formatDateKey(span.from)} – ${formatDateKey(span.to)}`, " ", Object.assign(el("small"), { textContent: `（${rows.length} 天有資料）` }));
  spanNode.dataset.tip = bounds ? USAGE_RANGES[key].tip : "以回傳資料的第一天到最後一天為區間";

  const totalNode = byId("usage-range-total");
  totalNode.textContent = counted.length ? `${formatNumber(total)} tokens` : "未提供";
  totalNode.classList.toggle("tone-muted", !counted.length);
  totalNode.dataset.tip = `區間內 ${counted.length} 天的 tokens 加總`;

  const averageNode = byId("usage-range-average");
  averageNode.textContent = counted.length ? `${formatNumber(Math.round(total / counted.length))} tokens` : "未提供";
  averageNode.classList.toggle("tone-muted", !counted.length);
  averageNode.dataset.tip = "合計 ÷ 有資料的天數";

  const peakNode = byId("usage-range-peak");
  if (peak) {
    peakNode.replaceChildren(`${formatNumber(peak.tokens)} tokens`, " ", Object.assign(el("small"), { textContent: `（${formatDateKey(peak.date)}）` }));
    peakNode.dataset.tip = `單日最高：${formatDateKey(peak.date)}`;
  } else {
    peakNode.textContent = "未提供";
    delete peakNode.dataset.tip;
  }
  peakNode.classList.toggle("tone-muted", !peak);
}

function buildUsageChart(rows) {
  const canvas = byId("usage-chart");
  const context = canvas.getContext("2d");
  const gradient = context.createLinearGradient(0, 0, 0, canvas.parentElement.clientHeight || 280);
  gradient.addColorStop(0, "rgba(16, 107, 75, 0.28)");
  gradient.addColorStop(1, "rgba(16, 107, 75, 0.02)");
  return new Chart(canvas, {
    type: "line",
    data: {
      labels: rows.map(day => day.date),
      datasets: [{
        label: "每日 tokens",
        data: rows.map(day => day.tokens),
        borderColor: "#106b4b",
        backgroundColor: gradient,
        fill: true,
        borderWidth: 2,
        // 點數少（如近一週）時顯示資料點，長區間只畫線。
        pointRadius: rows.length <= 14 ? 3 : 0,
        pointBackgroundColor: "#106b4b",
        pointHoverRadius: 5,
        pointHoverBackgroundColor: "#106b4b",
        tension: 0.3
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      animation: false,
      interaction: { mode: "index", intersect: false },
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: "#1b2430",
          padding: 10,
          displayColors: false,
          callbacks: { label: item => `${item.parsed.y.toLocaleString("zh-TW")} tokens` }
        }
      },
      scales: {
        x: { grid: { display: false }, ticks: { maxTicksLimit: 8, color: "#66717f" } },
        y: { beginAtZero: true, grid: { color: "#eef1f0" }, ticks: { color: "#66717f", callback: value => value.toLocaleString("zh-TW") } }
      }
    }
  });
}

// 依 state.detail.range 過濾 state.detail.daily，重繪按鈕狀態、區間摘要、折線圖與每日數值表。
// 只動已載入的資料，不重抓 API；loading 時清空畫面並停用區間按鈕。
function renderUsageRange({ loading = false } = {}) {
  const { daily, range } = state.detail;
  const key = USAGE_RANGES[range] ? range : "all";
  const today = new Date();
  for (const control of document.querySelectorAll("[data-usage-range]")) {
    const controlKey = control.dataset.usageRange;
    control.setAttribute("aria-pressed", String(controlKey === key));
    control.disabled = loading || daily.length === 0;
    const bounds = usageRangeBounds(controlKey, today);
    control.dataset.tip = bounds ? `${USAGE_RANGES[controlKey].tip}\n${formatDateKey(bounds.from)} – ${formatDateKey(bounds.to)}` : USAGE_RANGES[controlKey].tip;
  }

  state.chart?.destroy();
  state.chart = null;
  const rows = loading ? [] : usageRangeRows(key, daily);
  byId("chart-empty").hidden = loading || daily.length > 0;
  byId("chart-range-empty").hidden = loading || daily.length === 0 || rows.length > 0;
  byId("usage-chart").hidden = rows.length === 0;
  renderUsageRangeStats(key, rows);
  if (rows.length) state.chart = buildUsageChart(rows);
  if (loading) {
    byId("daily-table").replaceChildren();
    return;
  }
  renderTable("daily-table", [
    { label: "日期", value: row => row.date },
    { label: "Tokens", value: row => row.tokens.toLocaleString("zh-TW"), className: "num" }
  ], rows, null, { emptyTitle: daily.length ? "此區間沒有資料" : "未提供每日資料", emptyIcon: "calendar" });
}

async function loadDetail() {
  const profileId = state.selectedProfileId;
  if (profileId === null || state.view !== "profile-detail") return;
  const revision = ++state.viewRevision;
  state.detail.daily = [];
  renderUsageRange({ loading: true });
  setSectionMessage("detail", "");
  const profile = state.profiles.find(item => item.id === profileId);
  if (!profile) {
    setSectionMessage("detail", `找不到此${TERMS.profile.zh}，請返回儀表板重新整理。`, "error");
    return;
  }
  byId("detail-id").textContent = `編號 ${profileId}`;
  byId("detail-id").dataset.tip = `Profile ID：${profileId}`;
  byId("detail-title").textContent = profileName(profile);
  byId("detail-status-badge").replaceChildren(statusBadge(profile.status));
  byId("profile-actions").replaceChildren(profileActions(profile));
  byId("detail-stats").textContent = "每日使用量載入中…";
  setDetailStat("detail-lifetime", "…", true);
  setDetailStat("detail-asof", "…", true);
  setDetailRefreshing(true);
  if (state.usage.get(profileId)?.error) state.usage.delete(profileId);
  renderDetailQuota(profile);

  const summaryPromise = (async () => {
    if (state.usage.has(profileId)) return;
    let summary;
    try {
      summary = await requestJson(`${api.profiles}/${profileId}/usage`);
    } catch (error) {
      summary = { error: errorText(error) };
    }
    if (revision !== state.viewRevision) return;
    state.usage.set(profileId, summary);
    renderDetailQuota(profile);
  })();

  const detailPromise = runSection("detail", async () => {
    const detail = await requestJson(`${api.profiles}/${profileId}/usage/details`);
    if (revision !== state.viewRevision) return;
    byId("detail-stats").textContent = `ChatGPT 登入名稱：${detail.displayName ?? detail.username ?? "未提供"}`;
    setDetailStat("detail-lifetime", formatNumber(detail.lifetimeTokens) ?? "未提供", formatNumber(detail.lifetimeTokens) === null);
    setDetailStat("detail-asof", detail.statsAsOf ? String(detail.statsAsOf) : "未提供", !detail.statsAsOf);
    state.detail.daily = requireArray(detail.dailyUsage);
    renderUsageRange();
  }, { quiet: true });

  await Promise.all([summaryPromise, detailPromise, runSection("grants", async () => {
    await ensurePersons();
    await loadGrants();
  }, { quiet: true }), runSection("leases", loadLeases, { quiet: true })]);
  if (revision === state.viewRevision) setDetailRefreshing(false);
}

const VIEW_TITLES = Object.freeze({ dashboard: "儀表板", settings: "設定", log: TERMS.audit.zh, "profile-detail": `${TERMS.profile.zh}詳情` });

async function navigate(view, profileId = null) {
  setPopoverOpen(false);
  closeDrawers();
  state.view = view;
  state.selectedProfileId = profileId;
  ++state.viewRevision;
  ++state.dashboardRevision;
  setDashboardLoading(false);
  state.chart?.destroy();
  state.chart = null;
  // 頁面標題顯示在頂欄（與品牌合併），不另佔一列。
  byId("page-title").textContent = VIEW_TITLES[view] ?? "";
  document.title = `${VIEW_TITLES[view] ?? ""} · Codex Profile Sharing 管理台`;
  for (const element of document.querySelectorAll("[data-view]")) element.hidden = element.dataset.view !== view;
  for (const element of document.querySelectorAll("[data-nav]")) element.setAttribute("aria-current", element.dataset.nav === view ? "page" : "false");
  if (view === "dashboard") {
    // 只有從未完整載入過才自動抓資料；之後切回儀表板直接以既有資料重繪，
    // 要最新使用量由使用者按重新整理。
    if (state.dashboard.updatedAt) renderProfiles();
    else await runSection("profiles", loadProfiles, { quiet: true });
  }
  if (view === "settings") await runSection("persons", loadPersons, { quiet: true });
  if (view === "log") await runSection("audit", loadAudit, { quiet: true });
  if (view === "profile-detail") await loadDetail();
}

function renderIdentity(identity) {
  const name = identity?.displayName ?? "未知使用者";
  byId("avatar-initials").textContent = initials(name);
  byId("avatar-initials-lg").textContent = initials(name);
  byId("identity-name").textContent = name;
  byId("identity-role").replaceChildren(roleBadge(identity?.role));
  const details = byId("identity-details");
  details.replaceChildren();
  const fields = [
    ["id", `${TERMS.person.zh}編號`],
    ["normalizedIpAddress", "來源 IP"],
    ["ipAddress", "來源 IP"],
    ["effectiveFrom", "生效時間"],
    ["effectiveUntil", "失效時間"]
  ];
  const seen = new Set();
  for (const [key, label] of fields) {
    if (identity?.[key] === undefined || identity[key] === null || seen.has(label)) continue;
    seen.add(label);
    const dt = document.createElement("dt");
    dt.textContent = label;
    const dd = document.createElement("dd");
    dd.textContent = key.startsWith("effective") ? formatDateTime(identity[key]) ?? "—" : formatValue(identity[key]);
    if (key === "id") dd.dataset.tip = "Person ID";
    details.append(dt, dd);
  }
  details.hidden = details.childElementCount === 0;
}

// 依身分決定管理內容是否顯示；回傳是否具 ADMIN 權限。
function applyIdentity(identity) {
  renderIdentity(identity);
  const admin = identity.role === "ADMIN";
  byId("admin-content").hidden = !admin;
  byId("topbar-nav").hidden = !admin;
  setGlobalMessage(admin ? "" : "目前身分不是管理者（ADMIN），無法使用管理台；管理 API 也會拒絕此來源的操作。");
  return admin;
}

function renderIdentityError(error) {
  byId("avatar-initials").textContent = "!";
  byId("avatar-initials-lg").textContent = "!";
  byId("identity-name").textContent = "無法確認身分";
  byId("identity-role").replaceChildren(el("span", "badge badge-muted", "—"));
  byId("identity-details").replaceChildren();
  setGlobalMessage(errorText(error));
}

async function initialize() {
  ++state.viewRevision;
  ++state.dashboardRevision;
  state.chart?.destroy();
  state.chart = null;
  // 重新初始化視同首次開啟，儀表板要重新抓資料。
  state.dashboard.updatedAt = null;
  byId("admin-content").hidden = true;
  byId("topbar-nav").hidden = true;
  setPopoverOpen(false);
  closeDrawers();
  try {
    const identity = await requestJson(api.me);
    if (applyIdentity(identity)) await navigate("dashboard");
  } catch (error) {
    renderIdentityError(error);
  }
}

// 重新確認身分只重新呼叫 me API，不重載目前頁面；
// 只有在 ADMIN 權限由無變有時，才需要首次載入管理內容。
async function refreshIdentity() {
  const button = byId("refresh-identity");
  button.disabled = true;
  button.querySelector(".icon")?.classList.add("is-spinning");
  try {
    const wasAdmin = !byId("admin-content").hidden;
    const identity = await requestJson(api.me);
    if (applyIdentity(identity) && !wasAdmin) await navigate("dashboard");
  } catch (error) {
    renderIdentityError(error);
  } finally {
    button.disabled = false;
    button.querySelector(".icon")?.classList.remove("is-spinning");
  }
}

for (const dialog of document.querySelectorAll(".drawer")) bindDrawer(dialog);
byId("person-form").addEventListener("submit", savePerson);
byId("person-toggle").addEventListener("click", () => openPersonDrawer());
byId("grant-form").addEventListener("submit", saveGrant);
byId("grant-toggle").addEventListener("click", () => openGrantDrawer());
byId("refresh-identity").addEventListener("click", refreshIdentity);
byId("avatar-button").addEventListener("click", () => setPopoverOpen(byId("identity-popover").hidden));
byId("filter-toggle").addEventListener("click", () => setFilterMenuOpen(byId("filter-popover").hidden));
document.addEventListener("click", event => {
  // 選單內的點擊可能已觸發重繪、把 target 換掉，改用派發當下的路徑判斷是否點在外面。
  const path = event.composedPath();
  const within = selector => path.some(node => node instanceof Element && node.matches(selector));
  if (!byId("identity-popover").hidden && !within(".avatar-wrap")) setPopoverOpen(false);
  if (!byId("filter-popover").hidden && !within(".filter-menu")) setFilterMenuOpen(false);
  const picker = datetimePickers.current;
  if (picker && !path.some(node => node instanceof Element && picker.contains(node))) picker.close();
});
document.addEventListener("keydown", event => {
  if (event.key !== "Escape") return;
  if (!byId("identity-popover").hidden) {
    setPopoverOpen(false);
    byId("avatar-button").focus();
  }
  if (!byId("filter-popover").hidden) {
    setFilterMenuOpen(false);
    byId("filter-toggle").focus();
  }
  if (datetimePickers.current) {
    datetimePickers.current.close(true);
    event.preventDefault(); // 月曆開在 drawer 內時，Esc 只關月曆，不觸發 dialog 的 cancel
  }
});
document.addEventListener("mouseover", event => {
  const target = event.target.closest("[data-tip]");
  if (target) tooltip.show(target);
});
document.addEventListener("mouseout", event => {
  const target = event.target.closest("[data-tip]");
  if (target && !target.contains(event.relatedTarget)) tooltip.hide(target);
});
document.addEventListener("focusin", event => {
  const target = event.target.closest("[data-tip]");
  if (target) tooltip.show(target);
});
document.addEventListener("focusout", event => {
  const target = event.target.closest("[data-tip]");
  if (target) tooltip.hide(target);
});
document.addEventListener("scroll", () => tooltip.hide(), true);
// KPI 卡片：環狀圖區段與明細列以 data-segment 互相打亮（滑鼠與鍵盤焦點皆適用）。
function setSegmentHot(target, hot) {
  const source = target.closest?.("[data-segment]");
  const tile = source?.closest(".kpi");
  if (!tile) return;
  for (const node of tile.querySelectorAll(`[data-segment="${source.dataset.segment}"]`)) node.classList.toggle("is-hot", hot);
}
byId("kpi-grid").addEventListener("mouseover", event => setSegmentHot(event.target, true));
byId("kpi-grid").addEventListener("mouseout", event => {
  const source = event.target.closest?.("[data-segment]");
  if (source && !source.contains(event.relatedTarget)) setSegmentHot(source, false);
});
byId("kpi-grid").addEventListener("focusin", event => setSegmentHot(event.target, true));
byId("kpi-grid").addEventListener("focusout", event => setSegmentHot(event.target, false));
byId("profile-filter").addEventListener("input", renderProfiles);
byId("profile-sort").addEventListener("change", event => setSort(event.target.value || null));
byId("sort-direction").addEventListener("click", () => setSort(state.dashboard.sortKey, state.dashboard.sortDir === "asc" ? "desc" : "asc"));
for (const element of document.querySelectorAll("[data-view-mode]")) element.addEventListener("click", () => setViewMode(element.dataset.viewMode));
loadPrefs();
syncToolbar();
byId("detail-refresh").addEventListener("click", loadDetail);
byId("usage-range").addEventListener("click", event => {
  const control = event.target.closest("[data-usage-range]");
  if (!control || control.disabled || control.dataset.usageRange === state.detail.range) return;
  state.detail.range = control.dataset.usageRange;
  renderUsageRange();
});
for (const link of document.querySelectorAll("[data-nav]")) link.addEventListener("click", () => navigate(link.dataset.nav));
for (const refresh of document.querySelectorAll("[data-refresh]")) {
  refresh.addEventListener("click", () => {
    const section = refresh.dataset.refresh;
    runSection(section, loaders[section], { quiet: true });
  });
}

initialize();