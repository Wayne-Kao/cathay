---
name: spec-to-tests
description: 從規格文件產生測試案例。讀入 Bible／PRD／SRS／前後端系統規格書等需求或規格文件，萃取並正規化需求，依序產出驗收條件，再一對多展開成可執行的測試案例，輸出成單一 JSON 檔並附完整追溯。文件已含驗收條件或測試案例時直接萃取而不重做；文件之間衝突或定義不清時記成待確認事項而不自行猜測。也支援規格改版後帶 baseline 重跑比對變更。Use when generating test cases or acceptance criteria from specification documents, building a requirements traceability matrix, reviewing specs for conflicts and gaps, or re-running against revised specs.
---

# 規格轉測試案例

把任意規格文件轉成 `testcases.json`：需求 → 驗收條件 → 一對多測試案例，外加一份誠實的待確認清單。

## 三條硬性規則

這三條凌駕一切效率考量，違反其中任何一條就是產出失敗。

1. **衝突不得自行裁決。** 文件之間任何矛盾都要寫進 `issues`。可以依仲裁規則挑一方讓流程往下走，但絕不可默默採用後照常產測試案例。
2. **現成的驗收資產一律萃取，不重新發明。** 文件裡已經寫好的驗收條件、測試案例、待確認項，照原意搬進來並在 `from` 記下原始編號，只能補欄位、不得改寫語意。
3. **禁用樣板句。** 步驟與預期結果要具體到陌生人能照著執行並自己判斷通過與否。`scripts/check.py` 會逐條比對禁用清單，命中即錯。

## 流程

### 1. 確認輸入與輸出

問清楚要分析哪些文件；使用者沒指定就掃描工作目錄找規格文件（`.md`／`.docx`／`.pdf`），列出來請他確認範圍。

輸出寫到這些文件的共同根目錄，檔名 `testcases.json`。若該檔已存在，先問清楚是要重跑比對（把舊檔當 baseline）還是覆蓋重來——**不要直接覆蓋**。

要重跑就讀 `references/rerun.md`；首次產生則完全不套用重跑規則，也不要寫 `change` 欄位。

### 2. 盤點文件

逐份判定型別（`BIBLE`／`PRD`／`SRS`／`OTHER`）並登錄進 `docs`，`path` 照磁碟上的實際檔名寫。

先用 grep 抓標題結構建立地圖，不要整份讀進來：

```bash
grep -n "^#\{1,4\} " <file>
```

### 3. 萃取現成的驗收資產

讀 `references/method.md` 的「萃取文件裡現成的驗收資產」，把文件裡已有的驗收條件、測試案例、待確認項先撿出來。這一步要在自己動手寫任何東西之前做完，否則會重複發明。

### 4. 需求正規化

一條需求 = 一個可驗證的斷言。跨文件的同一需求合併成一條、`src` 收多筆；衝突依 `references/method.md` 的仲裁規則處理並記 issue。

寫完 `requirements` 就先落檔，不要等全部做完才寫。

### 5. 驗收條件

每條需求至少一條驗收條件，`then` 必須是看得到的結果。被 issue 擋住而定義不出可判定結果的，填 `blocked` 並**不展開測試案例**——讓缺口被看見，比產出一條基於猜測的假案例好。

### 6. 一對多展開測試案例

對每條驗收條件套 `references/method.md` 的展開矩陣，逐一檢查 `happy`／`boundary`／`negative`／`auth`／`state`／`txn`／`concurrent`／`integration` 八個維度，適用的每個維度至少一條。

**測試案例數量應該明顯多於驗收條件數量。** 如果跑完是一比一，就是沒有真的展開，回頭重做。

同時要有節制：沒有值域限制就不要硬湊 `boundary`，沒有併發語意就不要硬湊 `concurrent`。每條都要能說出它在驗哪個具體風險。

### 7. 檢查與回報

```bash
python3 <skill-dir>/scripts/check.py <path>/testcases.json
```

錯誤全部清乾淨才算完成，警告要逐條看過再決定接受或修正。

要用眼睛看追溯關係，用瀏覽器開 `<skill-dir>/assets/viewer.html` 載入 `testcases.json`：RTM 頁籤把需求 → 驗收條件 → 測試案例展成心智圖，被 issue 擋住的驗收條件標成紅色缺口；Issues 頁籤列出全部待確認事項，並反查各自擋住哪些驗收條件。純檢視，不會動到檔案。

回報時給使用者：各集合的數量與展開比例、萃取了幾筆、被擋住的缺口有幾條、待確認清單摘要（尤其是需要誰去確認）。

## 分批策略

文件動輒上千行、需求動輒數十條，一次全做完會失控。照這個順序分批，每批寫檔後跑一次 `check.py`：

1. 一次做完 `docs` 與 `issues` 的初稿（萃取來的待確認項）
2. 一次做完 `requirements` 全集
3. 分批補 `criteria`，每批約 10 條需求
4. 分批展開 `tests`，每批約 5 條驗收條件
5. 補上過程中新發現的 issue，最後整體檢查

`check.py` 對半成品會報覆蓋率警告，那是正常的，做完再看最後一次的結果。

## 參考資料

- `references/schema.md` — 輸出 JSON 的欄位定義、ID 規則、風險矩陣、完整範例。寫第一筆記錄前先讀。
- `references/method.md` — 文件分層仲裁、萃取規則、需求正規化、驗收條件要求、展開矩陣、可測性紅線、待確認事項分類。整條流程的判斷依據都在這裡。
- `references/rerun.md` — 增量重跑。只在有 baseline 時讀。
- `scripts/check.py` — 驗證輸出。收尾必跑。
- `assets/viewer.html` — 產出後的檢視器。單檔零依賴，瀏覽器開啟後載入 `testcases.json` 即可看 RTM 心智圖、各集合表格與待確認清單。
