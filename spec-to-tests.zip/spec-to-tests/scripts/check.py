#!/usr/bin/env python3
"""驗證 spec-to-tests 產出的 testcases.json。

用法：python3 check.py <path/to/testcases.json>
有錯誤時 exit code 為 1。
"""

import json
import re
import sys
from collections import defaultdict

ID_RE = re.compile(r"^STT-(DOC|REQ|AC|TC|ISS)-(\d{3,})$")
SRC_RE = re.compile(r"^(STT-DOC-\d{3,})#(.+)$")
ROLE_RE = re.compile(r"[（(]\d{3}[）)]")
CODE_RE = re.compile(r"\b[A-Z]{1,3}\d{3,}\b")

ROOT_FIELDS = ["project", "generatedAt", "baseline",
               "docs", "requirements", "criteria", "tests", "issues"]
COLLECTIONS = {"docs": "DOC", "requirements": "REQ",
               "criteria": "AC", "tests": "TC", "issues": "ISS"}

DOC_TYPES = {"BIBLE", "PRD", "SRS", "OTHER"}
TEST_TYPES = {"happy", "boundary", "negative", "auth",
              "state", "txn", "concurrent", "integration"}
ISSUE_TYPES = {"CONFLICT", "PENDING", "AMBIGUOUS", "UNVERIFIABLE", "GAP"}
OWNERS = {"PM", "SA", "RD", "QA", "OPS"}
CHANGES = {"ADDED", "MODIFIED", "REMOVED", "UNCHANGED"}
RISK_SIDES = {"High", "Low"}
MAX_PER_CODE = 8  # 同一類訊息最多列幾筆，避免報告淹沒重點
RISK_LEVEL = {("High", "High"): "High", ("High", "Low"): "Medium",
              ("Low", "High"): "Medium", ("Low", "Low"): "Low"}

# 填空模板的指紋，出現即視為未真正寫出可執行內容
TEMPLATE_MARKERS = [
    "執行觸發動作",
    "建立前置狀態與測試資料",
    "擷取 UI 顯示",
    "expectedResults",
    "verification points",
    "依資料完整性、權限或核心流程影響判定",
    "依黃金路徑頻率、規則複雜度或併行風險判定",
]

# 空話，寫了等於沒寫
VAGUE_MARKERS = [
    "準備測試資料",
    "驗證結果是否正確",
    "確認功能正常",
    "結果符合預期",
    "應正確處理",
    "正常運作",
]


class Report:
    def __init__(self):
        self.errors = []
        self.warnings = []

    def error(self, code, message):
        self.errors.append((code, message))

    def warn(self, code, message):
        self.warnings.append((code, message))


def as_list(value):
    return value if isinstance(value, list) else []


def text_of(record, *fields):
    parts = []
    for field in fields:
        value = record.get(field)
        if isinstance(value, str):
            parts.append(value)
        elif isinstance(value, list):
            parts.extend(item for item in value if isinstance(item, str))
    return "\n".join(parts)


def check_strings(report, record_id, field, values, allow_empty=False):
    """檢查字串陣列欄位：型別、非空、樣板句。"""
    if not isinstance(values, list):
        report.error("FIELD_TYPE", f"{record_id} 的 {field} 必須是陣列")
        return
    if not values and not allow_empty:
        report.error("FIELD_EMPTY", f"{record_id} 的 {field} 不可為空")
    for item in values:
        if not isinstance(item, str) or not item.strip():
            report.error("FIELD_TYPE", f"{record_id} 的 {field} 含空白或非字串項目")
            continue
        for marker in TEMPLATE_MARKERS:
            if marker in item:
                report.error("TEMPLATE",
                             f"{record_id} 的 {field} 出現樣板句「{marker}」：{item[:40]}")
        for marker in VAGUE_MARKERS:
            if marker in item:
                report.warn("VAGUE",
                            f"{record_id} 的 {field} 是空話「{marker}」，寫不出可判定的內容就該記 issue：{item[:40]}")


def check_ids(report, data):
    """ID 格式、KIND 相符、唯一性、序號連續。回傳 id -> collection 對照。"""
    owner_of = {}
    for collection, kind in COLLECTIONS.items():
        seen = set()
        numbers = []
        for index, record in enumerate(as_list(data.get(collection))):
            if not isinstance(record, dict):
                report.error("RECORD_TYPE", f"{collection}[{index}] 不是物件")
                continue
            record_id = record.get("id")
            if not isinstance(record_id, str):
                report.error("ID_MISSING", f"{collection}[{index}] 缺少 id")
                continue
            match = ID_RE.match(record_id)
            if not match:
                report.error("ID_FORMAT",
                             f"{record_id} 不符合 STT-<KIND>-<NNN> 格式")
                continue
            if match.group(1) != kind:
                report.error("ID_KIND",
                             f"{record_id} 出現在 {collection}，KIND 應為 {kind}")
                continue
            if record_id in seen:
                report.error("ID_DUPLICATE", f"{record_id} 重複")
                continue
            seen.add(record_id)
            numbers.append(int(match.group(2)))
            owner_of[record_id] = collection
        if numbers:
            expected = set(range(1, max(numbers) + 1))
            missing = sorted(expected - set(numbers))
            if missing:
                shown = ", ".join(f"{kind}-{n:03d}" for n in missing[:5])
                report.warn("ID_GAP",
                            f"{collection} 序號跳號，缺 {shown}"
                            f"{' 等' if len(missing) > 5 else ''}"
                            "（若非重跑刻意保留，請補上或重編）")
    return owner_of


def check_from(report, data, owner_of):
    """from 只放來源文件的原始編號，不得與本檔 ID 混淆。"""
    for collection in ("requirements", "criteria", "tests", "issues"):
        for record in as_list(data.get(collection)):
            if not isinstance(record, dict):
                continue
            origin = record.get("from")
            if origin is None:
                continue
            record_id = record.get("id", f"{collection}[?]")
            if not isinstance(origin, str) or not origin.strip():
                report.error("FROM_TYPE", f"{record_id} 的 from 必須是非空字串或直接省略")
                continue
            if origin.startswith("STT-"):
                report.error("FROM_CONFUSION",
                             f"{record_id} 的 from 是 {origin}，from 只能放來源文件的原始編號，不能放本檔 ID")
            elif origin in owner_of:
                report.error("FROM_CONFUSION",
                             f"{record_id} 的 from 是 {origin}，與本檔既有 ID 相同")


def check_src(report, record_id, values, doc_ids):
    if not isinstance(values, list) or not values:
        report.error("SRC_EMPTY", f"{record_id} 的 src 不可為空")
        return
    for item in values:
        if not isinstance(item, str):
            report.error("SRC_TYPE", f"{record_id} 的 src 含非字串項目")
            continue
        match = SRC_RE.match(item)
        if not match:
            report.error("SRC_FORMAT",
                         f"{record_id} 的 src「{item}」不符合 STT-DOC-NNN#章節 格式")
            continue
        if match.group(1) not in doc_ids:
            report.error("SRC_MISSING_DOC",
                         f"{record_id} 的 src 指向不存在的文件 {match.group(1)}")


def check_refs(report, record_id, field, values, valid, label, required=False):
    if not isinstance(values, list):
        report.error("FIELD_TYPE", f"{record_id} 的 {field} 必須是陣列")
        return
    if required and not values:
        report.error("REF_EMPTY", f"{record_id} 的 {field} 至少要有一筆{label}")
    for item in values:
        if item not in valid:
            report.error("REF_MISSING",
                         f"{record_id} 的 {field} 指向不存在的{label} {item}")


def check_change(report, data):
    """重跑欄位：全有或全無，changed 只在 MODIFIED 出現。"""
    tagged, untagged = [], []
    for collection in COLLECTIONS:
        for record in as_list(data.get(collection)):
            if not isinstance(record, dict):
                continue
            record_id = record.get("id", "?")
            change = record.get("change")
            if change is None:
                untagged.append(record_id)
            else:
                tagged.append(record_id)
                if change not in CHANGES:
                    report.error("CHANGE_VALUE",
                                 f"{record_id} 的 change「{change}」不在 "
                                 "ADDED/MODIFIED/REMOVED/UNCHANGED 之中")
            changed = record.get("changed")
            if changed is not None:
                if change != "MODIFIED":
                    report.error("CHANGED_MISUSE",
                                 f"{record_id} 只有 change=MODIFIED 時才能有 changed")
                elif not isinstance(changed, list) or not changed:
                    report.error("CHANGED_EMPTY", f"{record_id} 的 changed 不可為空")
            for item in as_list(record.get("was")):
                if not isinstance(item, str) or not ID_RE.match(item):
                    report.error("WAS_FORMAT",
                                 f"{record_id} 的 was 含非 STT ID 的項目 {item}")

    if tagged and untagged:
        report.error("CHANGE_PARTIAL",
                     f"change 欄位只標了一部分：{len(tagged)} 筆有、{len(untagged)} 筆沒有。"
                     "重跑時每筆都要標，首次產生則一律不要標")
    if tagged and not data.get("baseline"):
        report.warn("CHANGE_NO_BASELINE",
                    "有 change 標註但 baseline 是空的，重跑時應填入上一版的 generatedAt")
    if not tagged and data.get("baseline"):
        report.warn("BASELINE_NO_CHANGE",
                    "baseline 有值但沒有任何 change 標註，重跑應逐筆標註變更狀態")
    return bool(tagged)


def looks_multi_dimensional(criterion):
    """粗略判斷這條驗收條件是否明顯該展開成多條測試案例。"""
    blob = text_of(criterion, "given", "when", "then")
    if len(ROLE_RE.findall(blob)) >= 2:
        return "提到多個角色代碼"
    if len(set(CODE_RE.findall(text_of(criterion, "then")))) >= 2:
        return "then 提到多個代碼"
    if text_of(criterion, "then").count("、") >= 2:
        return "then 列舉了多個項目"
    return None


def main():
    if len(sys.argv) != 2:
        print("用法：python3 check.py <path/to/testcases.json>", file=sys.stderr)
        return 2
    path = sys.argv[1]
    try:
        with open(path, encoding="utf-8") as handle:
            data = json.load(handle)
    except FileNotFoundError:
        print(f"找不到檔案：{path}", file=sys.stderr)
        return 2
    except json.JSONDecodeError as exc:
        print(f"JSON 解析失敗：{exc}", file=sys.stderr)
        return 2

    report = Report()

    if not isinstance(data, dict):
        print("根層必須是物件", file=sys.stderr)
        return 2

    for field in ROOT_FIELDS:
        if field not in data:
            report.error("ROOT_MISSING", f"根層缺少 {field}")
    for field in data:
        if field not in ROOT_FIELDS:
            report.error("ROOT_EXTRA", f"根層出現未定義欄位 {field}")
    if not isinstance(data.get("project"), str) or not data.get("project", "").strip():
        report.error("ROOT_PROJECT", "project 必須是非空字串")
    if not isinstance(data.get("generatedAt"), str):
        report.error("ROOT_GENERATED_AT", "generatedAt 必須是 ISO 8601 字串")
    baseline = data.get("baseline", None)
    if baseline is not None and not isinstance(baseline, str):
        report.error("ROOT_BASELINE", "baseline 必須是 null 或上一版的 generatedAt 字串")
    for collection in COLLECTIONS:
        if collection in data and not isinstance(data[collection], list):
            report.error("COLLECTION_TYPE", f"{collection} 必須是陣列")

    owner_of = check_ids(report, data)
    doc_ids = {i for i, c in owner_of.items() if c == "docs"}
    req_ids = {i for i, c in owner_of.items() if c == "requirements"}
    ac_ids = {i for i, c in owner_of.items() if c == "criteria"}
    iss_ids = {i for i, c in owner_of.items() if c == "issues"}
    check_from(report, data, owner_of)
    has_change = check_change(report, data)

    def is_live(record):
        return record.get("change") != "REMOVED"

    # ---- docs ----
    for record in as_list(data.get("docs")):
        if not isinstance(record, dict):
            continue
        record_id = record.get("id", "?")
        if not isinstance(record.get("path"), str) or not record.get("path", "").strip():
            report.error("DOC_PATH", f"{record_id} 缺少 path")
        if record.get("type") not in DOC_TYPES:
            report.error("DOC_TYPE",
                         f"{record_id} 的 type「{record.get('type')}」不在 "
                         "BIBLE/PRD/SRS/OTHER 之中")

    # ---- requirements ----
    for record in as_list(data.get("requirements")):
        if not isinstance(record, dict):
            continue
        record_id = record.get("id", "?")
        text = record.get("text")
        if not isinstance(text, str) or not text.strip():
            report.error("REQ_TEXT", f"{record_id} 缺少 text")
        else:
            for marker in VAGUE_MARKERS:
                if marker in text:
                    report.warn("REQ_VAGUE",
                                f"{record_id} 的 text 含空話「{marker}」，"
                                "無法驗證的敘述應記成 UNVERIFIABLE issue 而不是需求")
        check_src(report, record_id, record.get("src"), doc_ids)

    # ---- criteria ----
    blocked_acs = set()
    for record in as_list(data.get("criteria")):
        if not isinstance(record, dict):
            continue
        record_id = record.get("id", "?")
        check_refs(report, record_id, "req", record.get("req"), req_ids, "需求", required=True)
        check_src(report, record_id, record.get("src"), doc_ids)
        for field in ("given", "when", "then"):
            value = record.get(field)
            if not isinstance(value, str) or not value.strip():
                report.error("AC_GWT", f"{record_id} 缺少 {field}")
                continue
            for marker in TEMPLATE_MARKERS:
                if marker in value:
                    report.error("TEMPLATE", f"{record_id} 的 {field} 出現樣板句「{marker}」")
            for marker in VAGUE_MARKERS:
                if marker in value:
                    report.warn("VAGUE",
                                f"{record_id} 的 {field} 是空話「{marker}」，"
                                "驗收條件必須可判定真假")
        blocked = record.get("blocked")
        if blocked is None:
            report.error("AC_BLOCKED", f"{record_id} 缺少 blocked（沒被擋就填空陣列）")
        else:
            check_refs(report, record_id, "blocked", blocked, iss_ids, "待確認事項")
            if blocked:
                blocked_acs.add(record_id)

    # ---- tests ----
    tests_by_ac = defaultdict(list)
    for record in as_list(data.get("tests")):
        if not isinstance(record, dict):
            continue
        record_id = record.get("id", "?")
        check_refs(report, record_id, "ac", record.get("ac"), ac_ids, "驗收條件", required=True)
        for ac_id in as_list(record.get("ac")):
            tests_by_ac[ac_id].append(record)
            if ac_id in blocked_acs and is_live(record):
                report.error("TEST_ON_BLOCKED",
                             f"{record_id} 掛在被 issue 擋住的 {ac_id} 上；"
                             "被擋的驗收條件不展開測試案例，讓缺口留著")
        title = record.get("title")
        if not isinstance(title, str) or not title.strip():
            report.error("TEST_TITLE", f"{record_id} 缺少 title")
        if record.get("type") not in TEST_TYPES:
            report.error("TEST_TYPE",
                         f"{record_id} 的 type「{record.get('type')}」不在 "
                         + "/".join(sorted(TEST_TYPES)) + " 之中")
        check_strings(report, record_id, "setup", record.get("setup"))
        check_strings(report, record_id, "steps", record.get("steps"))
        check_strings(report, record_id, "expected", record.get("expected"))

        risk = record.get("risk")
        if not isinstance(risk, dict):
            report.error("RISK_MISSING", f"{record_id} 缺少 risk 物件")
        else:
            impact, likelihood = risk.get("impact"), risk.get("likelihood")
            if impact not in RISK_SIDES or likelihood not in RISK_SIDES:
                report.error("RISK_AXES",
                             f"{record_id} 的 impact 與 likelihood 都必須是 High 或 Low")
            else:
                expected_level = RISK_LEVEL[(impact, likelihood)]
                if risk.get("level") != expected_level:
                    report.error("RISK_LEVEL",
                                 f"{record_id} 的 level 應為 {expected_level}"
                                 f"（impact={impact}, likelihood={likelihood}），"
                                 f"實際是 {risk.get('level')}")
            why = risk.get("why")
            if not isinstance(why, str) or not why.strip():
                report.error("RISK_WHY", f"{record_id} 的 risk.why 不可為空")
            else:
                for marker in TEMPLATE_MARKERS:
                    if marker in why:
                        report.error("TEMPLATE",
                                     f"{record_id} 的 risk.why 出現樣板句「{marker}」")

    # ---- issues ----
    for record in as_list(data.get("issues")):
        if not isinstance(record, dict):
            continue
        record_id = record.get("id", "?")
        if record.get("type") not in ISSUE_TYPES:
            report.error("ISSUE_TYPE",
                         f"{record_id} 的 type「{record.get('type')}」不在 "
                         + "/".join(sorted(ISSUE_TYPES)) + " 之中")
        text = record.get("text")
        if not isinstance(text, str) or not text.strip():
            report.error("ISSUE_TEXT", f"{record_id} 缺少 text")
        elif len(text.strip()) < 20:
            report.warn("ISSUE_THIN",
                        f"{record_id} 的 text 太短，必須寫清楚各方分別怎麼說：{text}")
        check_refs(report, record_id, "docs", record.get("docs"), doc_ids, "文件", required=True)
        check_refs(report, record_id, "refs", record.get("refs"), set(owner_of), "記錄")
        if record.get("owner") not in OWNERS:
            report.error("ISSUE_OWNER",
                         f"{record_id} 的 owner「{record.get('owner')}」不在 "
                         + "/".join(sorted(OWNERS)) + " 之中")

    # ---- 覆蓋率 ----
    live_reqs = [r for r in as_list(data.get("requirements"))
                 if isinstance(r, dict) and is_live(r)]
    live_acs = [r for r in as_list(data.get("criteria"))
                if isinstance(r, dict) and is_live(r)]
    live_tests = [r for r in as_list(data.get("tests"))
                  if isinstance(r, dict) and is_live(r)]

    reqs_with_ac = set()
    for record in live_acs:
        reqs_with_ac.update(as_list(record.get("req")))
    for record in live_reqs:
        if record.get("id") not in reqs_with_ac:
            report.warn("REQ_UNCOVERED",
                        f"{record.get('id')} 沒有任何驗收條件")

    known_gaps = 0
    single_test_acs = 0
    for record in live_acs:
        record_id = record.get("id")
        covering = [t for t in tests_by_ac.get(record_id, []) if is_live(t)]
        if record_id in blocked_acs:
            known_gaps += 1
            continue
        if not covering:
            report.warn("AC_UNCOVERED",
                        f"{record_id} 沒有任何測試案例（若是被 issue 擋住，請填 blocked）")
        elif len(covering) == 1:
            single_test_acs += 1
            reason = looks_multi_dimensional(record)
            if reason:
                report.warn("ONE_TO_ONE",
                            f"{record_id} {reason}，卻只有一條測試案例 "
                            f"{covering[0].get('id')}，請照展開矩陣重新檢查")

    testable = len(live_acs) - known_gaps
    if testable >= 5 and single_test_acs / testable >= 0.7:
        report.warn("EXPANSION_FLAT",
                    f"{single_test_acs}/{testable} 條可測的驗收條件只有一條測試案例，"
                    "整體看起來沒有真的展開。一條驗收條件通常對應多條測試案例，"
                    "請逐條回頭套展開矩陣")

    # ---- 報告 ----
    print(f"spec-to-tests 檢查報告：{path}")
    print()
    print("統計")
    print(f"  文件 {len(as_list(data.get('docs')))}"
          f"｜需求 {len(live_reqs)}"
          f"｜驗收條件 {len(live_acs)}"
          f"｜測試案例 {len(live_tests)}"
          f"｜待確認 {len(as_list(data.get('issues')))}")
    if live_reqs:
        print(f"  驗收條件／需求 = {len(live_acs) / len(live_reqs):.2f}")
    if live_acs:
        print(f"  測試案例／驗收條件 = {len(live_tests) / len(live_acs):.2f}")
    extracted = sum(1 for c in ("requirements", "criteria", "tests", "issues")
                    for r in as_list(data.get(c))
                    if isinstance(r, dict) and r.get("from"))
    print(f"  從文件萃取（有 from）：{extracted} 筆")
    print(f"  已知缺口（被 issue 擋住的驗收條件）：{known_gaps}")
    if has_change:
        counts = defaultdict(int)
        for collection in COLLECTIONS:
            for record in as_list(data.get(collection)):
                if isinstance(record, dict) and record.get("change"):
                    counts[record["change"]] += 1
        print("  變更：" + "｜".join(f"{k} {v}" for k, v in sorted(counts.items())))

    for label, items in (("錯誤", report.errors), ("警告", report.warnings)):
        print()
        print(f"{label} ({len(items)})")
        if not items:
            print("  無")
            continue
        grouped = defaultdict(list)
        for code, message in items:
            grouped[code].append(message)
        for code in sorted(grouped, key=lambda c: (-len(grouped[c]), c)):
            messages = grouped[code]
            for message in messages[:MAX_PER_CODE]:
                print(f"  [{code}] {message}")
            if len(messages) > MAX_PER_CODE:
                print(f"  [{code}] … 另有 {len(messages) - MAX_PER_CODE} 筆同類，修法一樣")

    print()
    print("通過" if not report.errors else "未通過：請先清掉全部錯誤")
    return 1 if report.errors else 0


if __name__ == "__main__":
    sys.exit(main())
