#!/usr/bin/env python3
"""驗證 spec-to-tests 產出的 testcases.json。

用法：python3 check.py <path/to/testcases.json>
有錯誤時 exit code 為 1。
"""

import difflib
import json
import math
import os
import re
import sys
from collections import Counter, defaultdict

ID_RE = re.compile(r"^STT-(DOC|REQ|AC|TC|ISS)-(\d{3,})$")
SRC_RE = re.compile(r"^(STT-DOC-\d{3,})#(.+)$")
ROLE_RE = re.compile(r"[（(]\d{3}[）)]")
CODE_RE = re.compile(r"\b[A-Z]{1,3}\d{3,}\b")

ROOT_FIELDS = ["project", "generatedAt", "baseline",
               "docs", "requirements", "criteria", "tests", "issues"]
COLLECTIONS = {"docs": "DOC", "requirements": "REQ",
               "criteria": "AC", "tests": "TC", "issues": "ISS"}

DOC_TYPES = {"BIBLE", "PRD", "SRS", "OTHER"}
TEST_TYPES = {"happy", "boundary", "negative", "auth",
              "state", "txn", "concurrent", "integration"}
ISSUE_TYPES = {"CONFLICT", "PENDING", "AMBIGUOUS", "UNVERIFIABLE", "GAP"}
OWNERS = {"PM", "SA", "RD", "QA", "OPS"}
CHANGES = {"ADDED", "MODIFIED", "REMOVED", "UNCHANGED"}
RISK_SIDES = {"High", "Low"}
MAX_PER_CODE = 8  # 同一類訊息最多列幾筆，避免報告淹沒重點
RISK_LEVEL = {("High", "High"): "High", ("High", "Low"): "Medium",
              ("Low", "High"): "Medium", ("Low", "Low"): "Low"}

# docs 的配發順序：先 BIBLE、再 PRD、再 SRS、最後 OTHER，同型別內按 path 排序
DOC_TYPE_ORDER = {"BIBLE": 0, "PRD": 1, "SRS": 2, "OTHER": 3}

# 重複樣板的判定門檻：同一句在全檔出現超過這個比例就不是巧合，是填空模板。
# setup 不在此列——共用的測試身分與底稿本來就該逐條重複同一組具體值。
REPEAT_RATIO = 0.25
# steps 的收尾若都是同一句通用查核語，代表沒有針對各自的驗證點寫落點
TAIL_RATIO = 0.25
# risk.why 本來就該每條不同，門檻抓緊一點
WHY_REPEAT_RATIO = 0.15
REPEAT_FLOOR = 5

# ---- 萃取現成驗收資產（硬規則 2）----
# 文件裡的資產編號長相：AC-BIBLE-001、SIT-BIBLE-010、TC-001、TBD-003、Q-004
ASSET_ID_RE = re.compile(r"\b([A-Z][A-Z0-9]*(?:-[A-Z][A-Z0-9]*)*)-(\d{3})\b")
MD_HEADING_RE = re.compile(r"^#{1,6}\s+(.*)$")
# 章節標題出現這些字，才把該編號系列認定成「現成的驗收資產」。
# 用「驗收」不用「驗證」是刻意的——「Source Code 驗證清單」是開發稽核待辦，不是驗收資產。
ASSET_SECTION_SIGNALS = [
    "測試", "驗收", "待確認", "TBD", "未決", "Open Issue",
    "Definition of Ready", "Given", "SIT", "UAT", "Acceptance", "Test",
]
# 一個編號系列至少要有這麼多筆，才當成系列看待（避免單一編號的偶然命中）
ASSET_SERIES_FLOOR = 3
# PRD／SRS 整份都在範圍內，它們的現成資產應該幾乎全部有交代
ASSET_INSCOPE_ERROR = 0.60
ASSET_INSCOPE_WARN = 0.85

# ---- 需求對規格的引用覆蓋（顆粒度的絕對量尺）----
# markdown 表格的分隔列（|---|---|），不算資料列
TABLE_SEP_RE = re.compile(r"^\|[\s\-:|]+\|$")
# 規則密度：一份 PRD／SRS 大約每這麼多列表格內容，就該有一條需求引用得到
DOC_ROWS_PER_ANCHOR = 25
# 實際引用到的章節數低於推估值的這個比例，就是需求切得太粗
DOC_CITE_WARN = 0.5

# issues 裡 refs 全空的比例上限：待確認事項要掛得到它影響的需求或驗收條件
ISSUE_ORPHAN_WARN = 0.30
ISSUE_ORPHAN_ERROR = 0.60

# 驗收條件的 then 寫成提問，代表沒有依仲裁規則收斂出可判定的結果
QUESTION_MARKERS = [
    "需確認", "需先確認", "須確認", "須先確認", "待確認",
    "尚待確認", "有待確認", "需釐清", "須釐清", "需先取得", "才能定義",
]

# blocked 的驗收條件佔比上限：超過就代表把「有衝突」直接當成「擋住」
BLOCK_WARN_RATIO = 0.15
BLOCK_ERROR_RATIO = 0.25

# 測試案例／驗收條件的下限。低於這個數就是一對一，沒有真的套展開矩陣
TC_PER_AC_FLOOR = 1.5

# 可測驗收條件裡「只有一條測試案例」的比例上限
FLAT_RATIO = 0.50

# 全檔完全沒有某個維度的測試案例時，用這些訊號回頭確認是不是整批漏了
DIMENSION_SIGNALS = {
    "concurrent": r"併發|並行|同時建立|唯一性|不重複|序號|鎖定|樂觀鎖|悲觀鎖",
    "txn": r"rollback|回滾|交易|transaction",
    "integration": r"批次|檔案交換|上游|下游|第三方|跨系統",
}

# 驗收條件的 then／when 出現這些字眼，代表有失敗路徑要驗
NEGATIVE_SIGNALS = ["拒絕", "錯誤", "失敗", "不得", "不可", "無效", "退回",
                    "擋下", "必填", "禁止", "警告訊息"]
# 這些型別都算有涵蓋失敗路徑
NEGATIVE_KINDS = {"negative", "boundary", "auth", "state"}

# risk.why 取前這麼多字當指紋，用來抓換句話說的填空模板
WHY_FINGERPRINT = 30

# ---- 樣板骨架（換句話說也逃不掉的填空模板）----
# 完全相同的句子由 TEMPLATE_REPEAT 抓；把變動的部分塞在中間、頭尾固定的
# 「QA 依「X」設定本案例輸入值」這種骨架，只能靠頭尾指紋抓。
SHAPE_AFFIX = 8
# 同一個頭或尾出現在超過這個比例的測試案例裡，就是骨架
SHAPE_RATIO = 0.50

# ---- 重跑健全性 ----
# 來源文件沒改版時，REMOVED 佔比的上限。超過就不是規格刪了規則，是整份重寫
RERUN_REMOVED_MAX = 0.30
# 低於這個筆數的重跑不驗（樣本太小，比例沒有意義）
RERUN_FLOOR = 20

# 記錄內文提到的本檔 ID，必須跟該筆的參照欄位對得上
AC_ID_RE = re.compile(r"\bSTT-AC-\d{3,}\b")
REQ_ID_RE = re.compile(r"\bSTT-REQ-\d{3,}\b")

# 填空模板的指紋，出現即視為未真正寫出可執行內容
TEMPLATE_MARKERS = [
    "執行觸發動作",
    "建立前置狀態與測試資料",
    "擷取 UI 顯示",
    "expectedResults",
    "verification points",
    "依資料完整性、權限或核心流程影響判定",
    "依黃金路徑頻率、規則複雜度或併行風險判定",
]

# 空話，寫了等於沒寫
VAGUE_MARKERS = [
    "準備測試資料",
    "規格指定角色",
    "依規格角色",
    "驗證結果是否正確",
    "確認功能正常",
    "結果符合預期",
    "應正確處理",
    "正常運作",
]


class Report:
    def __init__(self):
        self.errors = []
        self.warnings = []

    def error(self, code, message):
        self.errors.append((code, message))

    def warn(self, code, message):
        self.warnings.append((code, message))


def as_list(value):
    return value if isinstance(value, list) else []


def text_of(record, *fields):
    parts = []
    for field in fields:
        value = record.get(field)
        if isinstance(value, str):
            parts.append(value)
        elif isinstance(value, list):
            parts.extend(item for item in value if isinstance(item, str))
    return "\n".join(parts)


def check_strings(report, record_id, field, values, allow_empty=False):
    """檢查字串陣列欄位：型別、非空、樣板句。"""
    if not isinstance(values, list):
        report.error("FIELD_TYPE", f"{record_id} 的 {field} 必須是陣列")
        return
    if not values and not allow_empty:
        report.error("FIELD_EMPTY", f"{record_id} 的 {field} 不可為空")
    for item in values:
        if not isinstance(item, str) or not item.strip():
            report.error("FIELD_TYPE", f"{record_id} 的 {field} 含空白或非字串項目")
            continue
        for marker in TEMPLATE_MARKERS:
            if marker in item:
                report.error("TEMPLATE",
                             f"{record_id} 的 {field} 出現樣板句「{marker}」：{item[:40]}")
        for marker in VAGUE_MARKERS:
            if marker in item:
                report.warn("VAGUE",
                            f"{record_id} 的 {field} 是空話「{marker}」，寫不出可判定的內容就該記 issue：{item[:40]}")


def check_ids(report, data):
    """ID 格式、KIND 相符、唯一性、序號連續。回傳 id -> collection 對照。"""
    owner_of = {}
    for collection, kind in COLLECTIONS.items():
        seen = set()
        numbers = []
        for index, record in enumerate(as_list(data.get(collection))):
            if not isinstance(record, dict):
                report.error("RECORD_TYPE", f"{collection}[{index}] 不是物件")
                continue
            record_id = record.get("id")
            if not isinstance(record_id, str):
                report.error("ID_MISSING", f"{collection}[{index}] 缺少 id")
                continue
            match = ID_RE.match(record_id)
            if not match:
                report.error("ID_FORMAT",
                             f"{record_id} 不符合 STT-<KIND>-<NNN> 格式")
                continue
            if match.group(1) != kind:
                report.error("ID_KIND",
                             f"{record_id} 出現在 {collection}，KIND 應為 {kind}")
                continue
            if record_id in seen:
                report.error("ID_DUPLICATE", f"{record_id} 重複")
                continue
            seen.add(record_id)
            numbers.append(int(match.group(2)))
            owner_of[record_id] = collection
        if numbers:
            expected = set(range(1, max(numbers) + 1))
            missing = sorted(expected - set(numbers))
            if missing:
                shown = ", ".join(f"{kind}-{n:03d}" for n in missing[:5])
                report.warn("ID_GAP",
                            f"{collection} 序號跳號，缺 {shown}"
                            f"{' 等' if len(missing) > 5 else ''}"
                            "（若非重跑刻意保留，請補上或重編）")
    return owner_of


def check_from(report, data, owner_of):
    """from 只放來源文件的原始編號，不得與本檔 ID 混淆。"""
    for collection in ("requirements", "criteria", "tests", "issues"):
        for record in as_list(data.get(collection)):
            if not isinstance(record, dict):
                continue
            origin = record.get("from")
            if origin is None:
                continue
            record_id = record.get("id", f"{collection}[?]")
            if not isinstance(origin, str) or not origin.strip():
                report.error("FROM_TYPE", f"{record_id} 的 from 必須是非空字串或直接省略")
                continue
            if origin.startswith("STT-"):
                report.error("FROM_CONFUSION",
                             f"{record_id} 的 from 是 {origin}，from 只能放來源文件的原始編號，不能放本檔 ID")
            elif origin in owner_of:
                report.error("FROM_CONFUSION",
                             f"{record_id} 的 from 是 {origin}，與本檔既有 ID 相同")


def check_src(report, record_id, values, doc_ids):
    if not isinstance(values, list) or not values:
        report.error("SRC_EMPTY", f"{record_id} 的 src 不可為空")
        return
    for item in values:
        if not isinstance(item, str):
            report.error("SRC_TYPE", f"{record_id} 的 src 含非字串項目")
            continue
        match = SRC_RE.match(item)
        if not match:
            report.error("SRC_FORMAT",
                         f"{record_id} 的 src「{item}」不符合 STT-DOC-NNN#章節 格式")
            continue
        if match.group(1) not in doc_ids:
            report.error("SRC_MISSING_DOC",
                         f"{record_id} 的 src 指向不存在的文件 {match.group(1)}")


def check_refs(report, record_id, field, values, valid, label, required=False):
    if not isinstance(values, list):
        report.error("FIELD_TYPE", f"{record_id} 的 {field} 必須是陣列")
        return
    if required and not values:
        report.error("REF_EMPTY", f"{record_id} 的 {field} 至少要有一筆{label}")
    for item in values:
        if item not in valid:
            report.error("REF_MISSING",
                         f"{record_id} 的 {field} 指向不存在的{label} {item}")


def check_change(report, data):
    """重跑欄位：全有或全無，changed 只在 MODIFIED 出現。"""
    tagged, untagged = [], []
    for collection in COLLECTIONS:
        for record in as_list(data.get(collection)):
            if not isinstance(record, dict):
                continue
            record_id = record.get("id", "?")
            change = record.get("change")
            if change is None:
                untagged.append(record_id)
            else:
                tagged.append(record_id)
                if change not in CHANGES:
                    report.error("CHANGE_VALUE",
                                 f"{record_id} 的 change「{change}」不在 "
                                 "ADDED/MODIFIED/REMOVED/UNCHANGED 之中")
            changed = record.get("changed")
            if changed is not None:
                if change != "MODIFIED":
                    report.error("CHANGED_MISUSE",
                                 f"{record_id} 只有 change=MODIFIED 時才能有 changed")
                elif not isinstance(changed, list) or not changed:
                    report.error("CHANGED_EMPTY", f"{record_id} 的 changed 不可為空")
            for item in as_list(record.get("was")):
                if not isinstance(item, str) or not ID_RE.match(item):
                    report.error("WAS_FORMAT",
                                 f"{record_id} 的 was 含非 STT ID 的項目 {item}")

    if tagged and untagged:
        report.error("CHANGE_PARTIAL",
                     f"change 欄位只標了一部分：{len(tagged)} 筆有、{len(untagged)} 筆沒有。"
                     "重跑時每筆都要標，首次產生則一律不要標")
    if tagged and not data.get("baseline"):
        report.warn("CHANGE_NO_BASELINE",
                    "有 change 標註但 baseline 是空的，重跑時應填入上一版的 generatedAt")
    if not tagged and data.get("baseline"):
        report.warn("BASELINE_NO_CHANGE",
                    "baseline 有值但沒有任何 change 標註，重跑應逐筆標註變更狀態")
    return bool(tagged)


def looks_multi_dimensional(criterion):
    """粗略判斷這條驗收條件是否明顯該展開成多條測試案例。"""
    blob = text_of(criterion, "given", "when", "then")
    if len(ROLE_RE.findall(blob)) >= 2:
        return "提到多個角色代碼"
    if len(set(CODE_RE.findall(text_of(criterion, "then")))) >= 2:
        return "then 提到多個代碼"
    if text_of(criterion, "then").count("、") >= 2:
        return "then 列舉了多個項目"
    return None


def norm(value):
    """去掉空白差異後的比對用字串。"""
    return re.sub(r"\s+", "", value) if isinstance(value, str) else ""


def similar(left, right):
    left, right = norm(left), norm(right)
    if not left or not right:
        return 0.0
    return difflib.SequenceMatcher(None, left, right).ratio()


def live_tests(data):
    """只看這一版還活著的測試案例。

    REMOVED 是 baseline 的殘骸，既不列入覆蓋率分母，也不該讓品質檢查的
    比例被稀釋——上一版留下 100 筆殘骸，這一版的樣板句就會從 100% 被
    稀釋到 50%，剛好躲過門檻。
    """
    return [r for r in as_list(data.get("tests"))
            if isinstance(r, dict) and r.get("change") != "REMOVED"]


def strip_lead(value):
    """剝掉「觀察位置與判定值：」這類固定引導語，只留冒號後真正的內容。

    引導語會讓整句的字元相似度被稀釋，複製貼上的 then 就閃過 ECHO_AC。
    只認開頭 12 字內的冒號，避免把句子中間的冒號當成引導語。
    """
    if not isinstance(value, str):
        return ""
    head, sep, tail = value.partition("：")
    if sep and len(head) <= 12 and tail.strip():
        return tail
    return value


def check_doc_paths(report, data, json_path):
    """path 必須指向磁碟上真實存在的檔案，且用正斜線。"""
    base = os.path.dirname(os.path.abspath(json_path))
    for record in as_list(data.get("docs")):
        if not isinstance(record, dict):
            continue
        record_id = record.get("id", "?")
        path = record.get("path")
        if not isinstance(path, str) or not path.strip():
            continue
        if "\\" in path:
            report.error("DOC_PATH_SEP",
                         f"{record_id} 的 path「{path}」用了反斜線；"
                         "一律寫正斜線，換一台機器跑才不會對不上")
        probe = path.replace("\\", "/")
        if not os.path.exists(os.path.join(base, probe)):
            report.error("DOC_PATH_MISSING",
                         f"{record_id} 的 path「{path}」在 {base} 底下找不到；"
                         "path 要照磁碟上的實際檔名寫，不要照別份文件的引用或功能代號拼")


def doc_sort_key(record):
    """docs 的正規排序：先 BIBLE、再 PRD、再 SRS、最後 OTHER，同型別內按 path。"""
    return (DOC_TYPE_ORDER.get(record.get("type"), 9),
            (record.get("path") or "").replace("\\", "/"))


def check_doc_order(report, data):
    """DOC ID 的配發順序要可重現，否則重跑比對時 baseline 全面錯位。

    比的是「哪個 ID 配給哪份文件」，不是陣列的排列順序——只比陣列順序的話，
    把 BIBLE 擺在第一筆卻配 STT-DOC-005 會整批漏掉。
    重跑時 ID 永不重用，後來新增的文件本來就會排在中間卻拿到較大的序號，
    所以有 baseline 時不驗這條。
    """
    live = [r for r in as_list(data.get("docs")) if isinstance(r, dict)]
    if len(live) < 2 or data.get("baseline"):
        return
    ordered = sorted(live, key=doc_sort_key)
    numbers = []
    for record in ordered:
        matched = ID_RE.match(record.get("id") or "")
        if not matched:
            return  # ID 格式本身有問題，check_ids 會另外報
        numbers.append(int(matched.group(2)))
    if numbers == sorted(numbers):
        return
    fixes = ["{}（{}）應為 STT-DOC-{:03d}".format(
        record.get("id", "?"), os.path.basename(record.get("path") or "?"), want)
        for record, want in zip(ordered, sorted(numbers))
        if int(ID_RE.match(record["id"]).group(2)) != want]
    report.warn("DOC_ORDER",
                "docs 的 ID 沒有照「先 BIBLE、再 PRD、再 SRS、最後 OTHER，"
                "同型別內按 path 排序」配發，重跑時整份 src 都會對不上 baseline："
                + "；".join(fixes))


def count_rule_rows(path):
    """粗估一份規格文件的規則條目數：markdown 表格的資料列數。

    規格書的規則幾乎都寫在表格裡（欄位規格表、DB 影響矩陣、處理結果代碼表），
    表格資料列數比總行數或標題數更貼近「這份文件有幾條規則」。
    """
    rows = 0
    try:
        with open(path, encoding="utf-8") as handle:
            for line in handle:
                stripped = line.strip()
                if stripped.startswith("|") and not TABLE_SEP_RE.match(stripped):
                    rows += 1
    except (OSError, UnicodeDecodeError):
        return None
    return rows


def check_doc_citation(report, data, json_path):
    """PRD／SRS 整份都在範圍內，需求就該引用得到它們的各個章節。

    一份 PRD／SRS 完全沒被任何需求引用，代表那份規格根本沒進到需求裡——
    最常見的是只掃了 PRD 就收工，把 SRS 當背景資料。
    引用到的章節數遠低於文件的規則密度，則代表顆粒度切太粗：
    一整節壓成一條需求，節裡的每條欄位規則與落表規則就沒人測。
    """
    base = os.path.dirname(os.path.abspath(json_path))
    reqs = [r for r in as_list(data.get("requirements")) if isinstance(r, dict)]
    if not reqs:
        return
    anchors = defaultdict(set)
    for record in reqs:
        for item in as_list(record.get("src")):
            matched = SRC_RE.match(item) if isinstance(item, str) else None
            if matched:
                anchors[matched.group(1)].add(matched.group(2).strip())

    uncited = []
    for record in as_list(data.get("docs")):
        if not isinstance(record, dict) or record.get("type") not in ("PRD", "SRS"):
            continue
        doc_id = record.get("id", "?")
        path = record.get("path") or ""
        name = os.path.basename(path) or "?"
        cited = len(anchors.get(doc_id, ()))
        if cited == 0:
            uncited.append(f"{doc_id}（{name}）")
            continue
        rows = count_rule_rows(os.path.join(base, path.replace("\\", "/")))
        if not rows:
            continue
        want = max(2, rows // DOC_ROWS_PER_ANCHOR)
        if cited < want * DOC_CITE_WARN:
            report.warn("REQ_COARSE",
                        f"{doc_id}（{name}）有 {rows} 列表格規則，"
                        f"但只有 {cited} 個章節被需求引用到（推估應有 {want} 個上下）。"
                        "這通常是一整節壓成一條需求：節裡的每條欄位規則、"
                        "每次落表寫入都該各自成為一條需求，回到步驟 5 重切顆粒度")
    if uncited:
        report.error("DOC_UNCITED",
                     f"{'、'.join(uncited)} 沒有被任何需求的 src 引用到。"
                     "PRD／SRS 整份都在範圍內，一份文件零引用代表它根本沒進到需求裡；"
                     "回到步驟 5，逐份文件掃過再做跨文件合併")


def check_scope(report, data):
    """只掛在 BIBLE 上的需求：Bible 講方向，落不到畫面／API／資料表就不是需求。"""
    doc_type = {r.get("id"): r.get("type")
                for r in as_list(data.get("docs")) if isinstance(r, dict)}
    reqs = [r for r in as_list(data.get("requirements")) if isinstance(r, dict)]
    bible_only = []
    for record in reqs:
        srcs = [s for s in as_list(record.get("src")) if isinstance(s, str)]
        if not srcs:
            continue
        if all(doc_type.get(s.split("#")[0]) == "BIBLE" for s in srcs):
            bible_only.append(record)
    for record in bible_only:
        report.warn("BIBLE_ONLY_REQ",
                    f"{record.get('id')} 只源自 BIBLE：{(record.get('text') or '')[:40]}"
                    "…／Bible 講業務方向，不是本模組的可測需求。要嘛補上 PRD／SRS 的落點"
                    "（畫面、API 或資料表），要嘛降級成 UNVERIFIABLE issue")
    if reqs and len(bible_only) / len(reqs) >= 0.20:
        report.error("SCOPE_LEAK",
                     f"{len(bible_only)}/{len(reqs)} 條需求只源自 BIBLE。"
                     "這代表把 Bible 的定義、名詞或範圍敘述整批當成需求萃取了，"
                     "請先做範圍界定：只有明確涉及本模組的段落才進來")


def check_merge(report, data):
    """跨文件合併：同一需求出現在多份文件應合併成一條、src 收多筆。"""
    docs = [r for r in as_list(data.get("docs")) if isinstance(r, dict)]
    reqs = [r for r in as_list(data.get("requirements")) if isinstance(r, dict)]
    if len(docs) < 2 or len(reqs) < 20:
        return
    merged = sum(1 for r in reqs if len(as_list(r.get("src"))) > 1)
    if merged == 0:
        report.error("MERGE_NONE",
                     f"{len(reqs)} 條需求沒有任何一條的 src 收超過一筆。"
                     f"有 {len(docs)} 份文件卻零合併，代表是逐份文件各掃一遍，"
                     "沒有做需求正規化——同一條需求出現在多份文件要合併成一條")
    elif merged / len(reqs) < 0.10:
        report.warn("MERGE_THIN",
                    f"只有 {merged}/{len(reqs)} 條需求跨多份文件；"
                    "請回頭確認是否漏了合併，或是需求切得過細")


def check_echo(report, data):
    """測試案例的 expected 不可只是把驗收條件的 then 複製一次。

    then 是「該看到什麼結果」，expected 要再往下一層：具體的代碼、訊息、欄位值，
    以及在哪裡看得到。兩者高度雷同就代表沒有真的往下寫。
    """
    criteria = {r.get("id"): r for r in as_list(data.get("criteria"))
                if isinstance(r, dict)}
    tests = live_tests(data)
    if len(tests) < REPEAT_FLOOR * 2:
        return
    echoes = []
    for record in tests:
        acs = as_list(record.get("ac"))
        ac = criteria.get(acs[0]) if acs else None
        expected = [i for i in as_list(record.get("expected")) if isinstance(i, str)]
        if not ac or not expected:
            continue
        if max(similar(strip_lead(item), ac.get("then")) for item in expected) >= 0.9:
            echoes.append(record.get("id", "?"))
    ratio = len(echoes) / len(tests)
    if ratio >= 0.25:
        report.error("ECHO_AC",
                     f"{len(echoes)}/{len(tests)} 條測試案例（{ratio:.0%}）的 expected "
                     f"有一條就是所屬驗收條件的 then 原文（剝掉引導語後仍相同），"
                     f"例如 {'、'.join(echoes[:5])}。"
                     "這是機械複製不是展開矩陣：expected 要寫出 then 沒寫的"
                     "具體代碼、訊息、欄位值與觀察位置")
    elif ratio >= 0.10:
        report.warn("ECHO_AC",
                    f"{len(echoes)}/{len(tests)} 條測試案例的 expected 與所屬驗收條件的 "
                    "then 幾乎相同，請確認有往下寫到具體代碼與觀察位置")


def check_repeats(report, data):
    """同一句話在全檔反覆出現，就是換了措辭的填空模板。

    只看 steps 與 expected：setup 重複同一組具體測試身分是規範鼓勵的做法，不罰。
    """
    tests = live_tests(data)
    if len(tests) < REPEAT_FLOOR * 2:
        return
    total = len(tests)
    limit = max(REPEAT_FLOOR, math.ceil(total * REPEAT_RATIO))

    for field in ("steps", "expected"):
        counter = Counter()
        for record in tests:
            for item in as_list(record.get(field)):
                if isinstance(item, str) and item.strip():
                    counter[norm(item)] += 1
        for phrase, count in counter.most_common():
            if count <= limit:
                break
            report.error("TEMPLATE_REPEAT",
                         f"「{phrase[:40]}…」在 {total} 條測試案例的 {field} 裡出現 "
                         f"{count} 次（{count / total:.0%}），超過門檻 {limit}。"
                         "反覆出現的同一句就是填空模板，每條測試案例的這個欄位"
                         "都要寫出自己那條在驗什麼")

    tails = Counter()
    for record in tests:
        steps = [i for i in as_list(record.get("steps"))
                 if isinstance(i, str) and i.strip()]
        if steps:
            tails[norm(steps[-1])] += 1
    if tails:
        phrase, count = tails.most_common(1)[0]
        if count / total >= TAIL_RATIO and count >= REPEAT_FLOOR:
            report.error("TAIL_TEMPLATE",
                         f"{count}/{total} 條測試案例（{count / total:.0%}）都以同一句收尾："
                         f"「{phrase[:40]}…」。通用的「去查一下」收尾等於沒寫驗證點，"
                         "最後一步要指名這一條該看哪個畫面欄位、哪個回應欄位或哪張表")

    why_limit = max(REPEAT_FLOOR, math.ceil(total * WHY_REPEAT_RATIO))
    why_counter = Counter()
    for record in tests:
        risk = record.get("risk")
        if isinstance(risk, dict) and isinstance(risk.get("why"), str):
            why_counter[norm(risk["why"])[:WHY_FINGERPRINT]] += 1
    for phrase, count in why_counter.most_common():
        if count <= why_limit:
            break
        report.error("TEMPLATE_REPEAT",
                     f"risk.why 有 {count} 條都以「{phrase}…」開頭，超過門檻 {why_limit}。"
                     "risk.why 要講這一條的具體風險，不是套同一段話")


def check_shapes(report, data):
    """頭尾固定、中間換填空的骨架句，完全比對抓不到，只能比頭尾指紋。

    TEMPLATE_REPEAT 比的是整句相同，所以「QA 依「A」設定本案例輸入值」與
    「QA 依「B」設定本案例輸入值」會被當成兩句不同的話放過。這裡改比每個項目
    的開頭與結尾各 SHAPE_AFFIX 字，超過門檻比例的測試案例共用同一個頭或尾，
    而且它們彼此又夠不一樣（不是同一句重複），就是換了填空的模板。

    setup 不驗頭尾——共用同一組具體測試身分是規範鼓勵的寫法。改驗另一件事：
    同一筆的某個 setup 項目整個包住另一個項目，那是把同一句話講兩次。
    """
    tests = live_tests(data)
    if len(tests) < REPEAT_FLOOR * 2:
        return
    total = len(tests)
    floor = max(REPEAT_FLOOR, math.ceil(total * SHAPE_RATIO))
    repeat_limit = max(REPEAT_FLOOR, math.ceil(total * REPEAT_RATIO))

    for field in ("steps", "expected"):
        for side, label in ((slice(None, SHAPE_AFFIX), "開頭"),
                            (slice(-SHAPE_AFFIX, None), "結尾")):
            holders = defaultdict(set)       # 指紋 -> 有這個指紋的測試案例 id
            variants = defaultdict(Counter)  # 指紋 -> 這些項目各自出現幾次
            for record in tests:
                record_id = record.get("id", "?")
                for item in as_list(record.get(field)):
                    text = norm(item)
                    if len(text) <= SHAPE_AFFIX:
                        continue  # 太短，頭尾就是全句，交給 TEMPLATE_REPEAT
                    holders[text[side]].add(record_id)
                    variants[text[side]][text] += 1
            for fingerprint, ids in sorted(holders.items(),
                                           key=lambda kv: -len(kv[1])):
                if len(ids) < floor:
                    break
                seen = variants[fingerprint]
                if seen.most_common(1)[0][1] > repeat_limit:
                    continue  # 同一句原文的重複已經由 TEMPLATE_REPEAT 報過
                report.error("TEMPLATE_SHAPE",
                             f"{len(ids)}/{total} 條測試案例（{len(ids) / total:.0%}）的 "
                             f"{field} 有一項以「{fingerprint}」為{label}，"
                             f"中間換了 {len(seen)} 種填空。"
                             "頭尾固定、中間換詞就是填空模板，不因為每句字面不同"
                             "就算寫過了——每條測試案例的這個欄位要用自己的話"
                             "寫出這一條在做什麼、在哪裡看什麼")
                break  # 同一個欄位同一側報一次就夠，修法一樣

    echoed = []
    for record in tests:
        items = [norm(i) for i in as_list(record.get("setup")) if isinstance(i, str)]
        items = [i for i in items if i]
        if any(a != b and a in b for a in items for b in items):
            echoed.append(record.get("id", "?"))
    if echoed and len(echoed) / total >= SHAPE_RATIO:
        report.error("SETUP_ECHO",
                     f"{len(echoed)}/{total} 條測試案例（{len(echoed) / total:.0%}）的 setup "
                     f"有一項整個包住另一項，例如 {'、'.join(echoed[:5])}。"
                     "把同一句前置條件加個殼再寫一次，湊出來的是筆數不是資訊；"
                     "setup 的每一項要各自帶一個別的項目沒有的具體值")


def check_trace(report, data):
    """記錄內文寫到的 STT ID，必須跟這筆自己的參照欄位對得上。

    title 或 risk.why 引用了別條驗收條件的編號，代表這批是複製貼上後
    只改了一部分，追溯關係已經斷了——比對不出來的追溯等於沒有追溯。
    """
    for collection, field_ref, pattern, fields, label in (
            ("tests", "ac", AC_ID_RE, ("title", "risk.why"), "驗收條件"),
            ("criteria", "req", REQ_ID_RE, ("given", "when", "then"), "需求")):
        for record in as_list(data.get(collection)):
            if not isinstance(record, dict):
                continue
            own = set(as_list(record.get(field_ref)))
            for field in fields:
                if field == "risk.why":
                    risk = record.get("risk")
                    value = risk.get("why") if isinstance(risk, dict) else None
                else:
                    value = record.get(field)
                if not isinstance(value, str):
                    continue
                stray = sorted(set(pattern.findall(value)) - own)
                if stray:
                    report.error("TRACE_MISMATCH",
                                 f"{record.get('id', '?')} 的 {field} 提到 "
                                 f"{'、'.join(stray[:3])}，但這筆掛的{label}是 "
                                 f"{'、'.join(sorted(own)) or '（空）'}。"
                                 "內文的編號與參照欄位對不上，追溯就是斷的——"
                                 "要嘛改內文，要嘛把該編號補進參照欄位")


def check_rerun_sanity(report, data):
    """來源文件沒改版，卻把 baseline 整批判成 REMOVED，就是沒做身分比對。

    REMOVED 只給「來源文件已刪除該規則」用。對不上的時候 rerun.md 要求記
    AMBIGUOUS issue、舊的那幾筆維持原狀等人裁決，而不是判死重寫一份。
    """
    docs = [r for r in as_list(data.get("docs")) if isinstance(r, dict)]
    if not docs:
        return
    for record in docs:
        change = record.get("change")
        if change == "UNCHANGED":
            continue
        if change == "MODIFIED" and set(as_list(record.get("changed"))) <= {"path"}:
            continue
        return  # 真的有文件新增、移除或改內容，這裡不評斷

    counts = Counter()
    for collection in ("requirements", "criteria", "tests", "issues"):
        for record in as_list(data.get(collection)):
            if isinstance(record, dict) and record.get("change"):
                counts[record["change"]] += 1
    total = sum(counts.values())
    if total < RERUN_FLOOR:
        return

    removed_ratio = counts["REMOVED"] / total
    detail = ("來源文件沒有改版（docs 全是 UNCHANGED，或只有 path 變），"
              f"但 {total} 筆記錄裡 REMOVED {counts['REMOVED']} 筆"
              f"（{removed_ratio:.0%}）、UNCHANGED {counts['UNCHANGED']} 筆")
    if removed_ratio >= RERUN_REMOVED_MAX:
        report.error("RERUN_WIPE",
                     detail + "。REMOVED 只給「來源文件已刪除該規則」用；"
                     "規格沒動卻整批移除，代表沒有做身分比對，而是重寫一份再把"
                     "baseline 判死。回到 rerun.md：先用 src 比對身分，比不出來的"
                     "記 AMBIGUOUS issue，舊的那幾筆維持原狀等人裁決")
    elif not counts["UNCHANGED"]:
        report.error("RERUN_WIPE",
                     detail + "。規格沒動卻沒有任何一筆 UNCHANGED，"
                     "代表身分比對整批落空。回到 rerun.md 先用 src 對身分，"
                     "對得上且內容相同的要標 UNCHANGED")


def extracted_origins(data):
    """真正被萃取進來的來源編號集合。

    掛不到任何需求／驗收條件（`refs` 全空）的 issue 不算數：那是
    「這個編號不採用」的紀錄，屬於步驟 4 回覆裡的萃取盤點表，
    不是把現成資產搬進產出。不排除的話，把整批不採用理由倒進 issues
    就能把萃取覆蓋率灌到滿分。

    標成 REMOVED 的記錄同理不算數：那是 baseline 的殘骸，已經不在這一版的
    產出裡。不排除的話，重跑時只要把 baseline 整批留成 REMOVED，覆蓋率就會
    停在上一版的水準，看不出這一版其實漏萃取了。
    """
    origins = set()
    for collection in COLLECTIONS:
        for record in as_list(data.get(collection)):
            if not isinstance(record, dict):
                continue
            if record.get("change") == "REMOVED":
                continue
            origin = record.get("from")
            if not isinstance(origin, str) or not origin.strip():
                continue
            if collection == "issues" and not as_list(record.get("refs")):
                continue
            origins.add(origin)
    return origins


def check_issue_refs(report, data):
    """refs 全空的 issue 影響不到任何驗收判定，整批出現就是盤點表倒進來了。

    待確認事項的價值在於「它擋住了什麼」。掛不到需求也掛不到驗收條件的條目，
    PM／SA 拿到手無從判斷要先解哪一則，整份清單就失去可讀性。
    """
    issues = [r for r in as_list(data.get("issues")) if isinstance(r, dict)]
    if len(issues) < 10:
        return
    orphans = [r.get("id", "?") for r in issues if not as_list(r.get("refs"))]
    if not orphans:
        return
    ratio = len(orphans) / len(issues)
    detail = (f"{len(orphans)}/{len(issues)} 則待確認事項（{ratio:.0%}）的 refs 是空的，"
              f"例如 {'、'.join(orphans[:5])}")
    if ratio >= ISSUE_ORPHAN_ERROR:
        report.error("ISSUE_ORPHAN",
                     detail + "。這是把步驟 4 的萃取盤點表倒進 issues 了——"
                     "「這個編號不採用，理由是…」屬於回覆裡的盤點表，不是待確認事項。"
                     "issues 只留真的需要有人去定案、且指得出影響哪條需求或驗收條件的項目")
    elif ratio >= ISSUE_ORPHAN_WARN:
        report.warn("ISSUE_ORPHAN",
                    detail + "。請逐則確認是真的還沒定案，"
                    "還是只是記錄某個編號不採用——後者應該寫在萃取盤點表裡")


def scan_assets(data, json_path):
    """掃描來源文件裡現成的驗收資產編號。

    回傳 {系列名: {"ids": {完整編號}, "docs": {DOC ID}, "in_scope": bool, "section": 標題}}。
    in_scope 指這個系列出自 PRD／SRS——那兩種文件整份都在範圍內，資產應該幾乎全數有交代；
    出自 BIBLE 的資產要先過範圍界定，沒採用是合理的，只做逐系列提醒。
    """
    base = os.path.dirname(os.path.abspath(json_path))
    doc_type = {}
    series = defaultdict(lambda: {"ids": set(), "docs": set(),
                                  "in_scope": False, "section": ""})
    for record in as_list(data.get("docs")):
        if not isinstance(record, dict):
            continue
        path = record.get("path")
        if not isinstance(path, str) or not path.strip():
            continue
        doc_id = record.get("id", "?")
        doc_type[doc_id] = record.get("type")
        try:
            with open(os.path.join(base, path.replace("\\", "/")),
                      encoding="utf-8") as handle:
                lines = handle.readlines()
        except (OSError, UnicodeDecodeError):
            continue  # 讀不到就跳過，DOC_PATH_MISSING 會另外報
        heading = ""
        for line in lines:
            matched = MD_HEADING_RE.match(line)
            if matched:
                heading = matched.group(1).strip()
                continue
            for found in ASSET_ID_RE.finditer(line):
                if not any(signal in heading for signal in ASSET_SECTION_SIGNALS):
                    continue
                entry = series[found.group(1)]
                entry["ids"].add(found.group(0))
                entry["docs"].add(doc_id)
                if doc_type.get(doc_id) in ("PRD", "SRS"):
                    entry["in_scope"] = True
                if not entry["section"]:
                    entry["section"] = heading
    return {name: entry for name, entry in series.items()
            if len(entry["ids"]) >= ASSET_SERIES_FLOOR}


def check_extraction(report, data, json_path):
    """硬規則 2：文件裡已經寫好的驗收資產一律萃取，不重新發明。

    回傳 (現成資產總數, 已萃取數, 範圍內總數, 範圍內已萃取數) 供報告統計用。
    """
    series = scan_assets(data, json_path)
    if not series:
        return None
    extracted = extracted_origins(data)

    all_ids = set()
    in_scope_ids = set()
    for name, entry in series.items():
        all_ids |= entry["ids"]
        if entry["in_scope"]:
            in_scope_ids |= entry["ids"]
        missing = sorted(entry["ids"] - extracted)
        if len(missing) == len(entry["ids"]):
            report.warn("EXTRACT_SERIES_MISS",
                        f"「{entry['section']}」的 {name}-* 共 {len(entry['ids'])} 筆"
                        "現成資產一筆都沒萃取。範圍外可以不採用，但要在萃取盤點表裡"
                        f"逐條寫明不採用的理由，例如 {'、'.join(missing[:3])}")

    hit_all = len(all_ids & extracted)
    hit_scope = len(in_scope_ids & extracted)
    if len(in_scope_ids) >= 5:
        ratio = hit_scope / len(in_scope_ids)
        missing = sorted(in_scope_ids - extracted)
        detail = (f"PRD／SRS 的現成驗收資產只萃取了 {hit_scope}/{len(in_scope_ids)} 筆"
                  f"（{ratio:.0%}），漏掉 {'、'.join(missing[:6])}"
                  + ("…" if len(missing) > 6 else ""))
        if ratio < ASSET_INSCOPE_ERROR:
            report.error("EXTRACT_THIN",
                         detail + "。PRD／SRS 整份都在範圍內，它們寫好的驗收條件、"
                         "測試案例與待確認項要照原意搬進來並在 from 記下原編號，"
                         "回到步驟 4 重做萃取，不要自己重新發明一套")
        elif ratio < ASSET_INSCOPE_WARN:
            report.warn("EXTRACT_THIN",
                        detail + "。請確認漏掉的每一筆都有不採用的理由")
    return len(all_ids), hit_all, len(in_scope_ids), hit_scope


def check_dimensions(report, data, is_live):
    """整份產出完全缺某個維度，但文件語意明明提到了，就是整批漏展開。"""
    tests = [r for r in as_list(data.get("tests")) if isinstance(r, dict) and is_live(r)]
    if len(tests) < 20:
        return
    kinds = Counter(r.get("type") for r in tests)
    blob = "\n".join(text_of(r, "text", "given", "when", "then")
                     for collection in ("requirements", "criteria")
                     for r in as_list(data.get(collection)) if isinstance(r, dict))
    for kind, pattern in DIMENSION_SIGNALS.items():
        if kinds.get(kind, 0):
            continue
        hits = set(re.findall(pattern, blob, re.IGNORECASE))
        if not hits:
            continue
        report.warn("DIM_MISSING",
                    f"全檔沒有任何 {kind} 型的測試案例，但需求與驗收條件裡出現了"
                    f"「{'、'.join(sorted(hits)[:4])}」。回到展開矩陣的 {kind} 那格："
                    "真的不適用就要說得出原因，不是整批跳過")


def check_risk_spread(report, data):
    """風險等級要有鑑別度，全部標 High 等於沒分級。"""
    tests = [r for r in as_list(data.get("tests")) if isinstance(r, dict)]
    levels = Counter(r["risk"].get("level") for r in tests
                     if isinstance(r.get("risk"), dict))
    total = sum(levels.values())
    if total < 20:
        return
    high = levels.get("High", 0) / total
    if high >= 0.70:
        report.warn("RISK_SKEW",
                    f"{levels.get('High', 0)}/{total} 條測試案例是 High（{high:.0%}）。"
                    "風險分級失去鑑別度，回頭照 impact／likelihood 的判斷依據重評："
                    "顯示文字、排序、非關鍵欄位算 Low，邊角情境算 Low likelihood")


def check_negative_coverage(report, tests_by_ac, data, blocked_acs, is_live):
    """有失敗路徑的驗收條件，必須有對應的失敗路徑測試案例。"""
    missing = []
    for record in as_list(data.get("criteria")):
        if not isinstance(record, dict) or not is_live(record):
            continue
        record_id = record.get("id")
        if record_id in blocked_acs:
            continue
        blob = text_of(record, "when", "then")
        if not any(signal in blob for signal in NEGATIVE_SIGNALS):
            continue
        kinds = {t.get("type") for t in tests_by_ac.get(record_id, []) if is_live(t)}
        if not kinds & NEGATIVE_KINDS:
            missing.append(record_id)
    for record_id in missing:
        report.warn("NEGATIVE_MISSING",
                    f"{record_id} 的 when／then 提到失敗或拒絕，卻沒有任何 "
                    "negative／boundary／auth／state 型的測試案例，只驗了正向路徑")

    tests = [r for r in as_list(data.get("tests")) if isinstance(r, dict) and is_live(r)]
    if len(tests) >= 30:
        kinds = Counter(r.get("type") for r in tests)
        negative = kinds.get("negative", 0)
        if negative / len(tests) < 0.10:
            report.warn("NEGATIVE_THIN",
                        f"{len(tests)} 條測試案例裡只有 {negative} 條 negative。"
                        "展開矩陣要求每個獨立錯誤碼各一條，請對照規格的處理結果代碼表"
                        "確認是不是整批漏了")


def main():
    if len(sys.argv) != 2:
        print("用法：python3 check.py <path/to/testcases.json>", file=sys.stderr)
        return 2
    path = sys.argv[1]
    try:
        with open(path, encoding="utf-8") as handle:
            data = json.load(handle)
    except FileNotFoundError:
        print(f"找不到檔案：{path}", file=sys.stderr)
        return 2
    except json.JSONDecodeError as exc:
        print(f"JSON 解析失敗：{exc}", file=sys.stderr)
        return 2

    report = Report()

    if not isinstance(data, dict):
        print("根層必須是物件", file=sys.stderr)
        return 2

    for field in ROOT_FIELDS:
        if field not in data:
            report.error("ROOT_MISSING", f"根層缺少 {field}")
    for field in data:
        if field not in ROOT_FIELDS:
            report.error("ROOT_EXTRA", f"根層出現未定義欄位 {field}")
    if not isinstance(data.get("project"), str) or not data.get("project", "").strip():
        report.error("ROOT_PROJECT", "project 必須是非空字串")
    if not isinstance(data.get("generatedAt"), str):
        report.error("ROOT_GENERATED_AT", "generatedAt 必須是 ISO 8601 字串")
    baseline = data.get("baseline", None)
    if baseline is not None and not isinstance(baseline, str):
        report.error("ROOT_BASELINE", "baseline 必須是 null 或上一版的 generatedAt 字串")
    for collection in COLLECTIONS:
        if collection in data and not isinstance(data[collection], list):
            report.error("COLLECTION_TYPE", f"{collection} 必須是陣列")

    owner_of = check_ids(report, data)
    doc_ids = {i for i, c in owner_of.items() if c == "docs"}
    req_ids = {i for i, c in owner_of.items() if c == "requirements"}
    ac_ids = {i for i, c in owner_of.items() if c == "criteria"}
    iss_ids = {i for i, c in owner_of.items() if c == "issues"}
    check_from(report, data, owner_of)
    has_change = check_change(report, data)
    if has_change:
        check_rerun_sanity(report, data)

    def is_live(record):
        return record.get("change") != "REMOVED"

    # ---- docs ----
    for record in as_list(data.get("docs")):
        if not isinstance(record, dict):
            continue
        record_id = record.get("id", "?")
        if not isinstance(record.get("path"), str) or not record.get("path", "").strip():
            report.error("DOC_PATH", f"{record_id} 缺少 path")
        if record.get("type") not in DOC_TYPES:
            report.error("DOC_TYPE",
                         f"{record_id} 的 type「{record.get('type')}」不在 "
                         "BIBLE/PRD/SRS/OTHER 之中")
    check_doc_paths(report, data, path)
    check_doc_order(report, data)
    check_doc_citation(report, data, path)
    check_issue_refs(report, data)
    assets = check_extraction(report, data, path)

    # ---- requirements ----
    for record in as_list(data.get("requirements")):
        if not isinstance(record, dict):
            continue
        record_id = record.get("id", "?")
        text = record.get("text")
        if not isinstance(text, str) or not text.strip():
            report.error("REQ_TEXT", f"{record_id} 缺少 text")
        else:
            for marker in VAGUE_MARKERS:
                if marker in text:
                    report.warn("REQ_VAGUE",
                                f"{record_id} 的 text 含空話「{marker}」，"
                                "無法驗證的敘述應記成 UNVERIFIABLE issue 而不是需求")
        check_src(report, record_id, record.get("src"), doc_ids)
    check_scope(report, data)
    check_merge(report, data)

    # ---- criteria ----
    blocked_acs = set()
    for record in as_list(data.get("criteria")):
        if not isinstance(record, dict):
            continue
        record_id = record.get("id", "?")
        check_refs(report, record_id, "req", record.get("req"), req_ids, "需求", required=True)
        check_src(report, record_id, record.get("src"), doc_ids)
        for field in ("given", "when", "then"):
            value = record.get(field)
            if not isinstance(value, str) or not value.strip():
                report.error("AC_GWT", f"{record_id} 缺少 {field}")
                continue
            for marker in TEMPLATE_MARKERS:
                if marker in value:
                    report.error("TEMPLATE", f"{record_id} 的 {field} 出現樣板句「{marker}」")
            for marker in VAGUE_MARKERS:
                if marker in value:
                    report.warn("VAGUE",
                                f"{record_id} 的 {field} 是空話「{marker}」，"
                                "驗收條件必須可判定真假")
        then = record.get("then")
        if isinstance(then, str):
            for marker in QUESTION_MARKERS:
                if marker in then:
                    report.error("AC_THEN_QUESTION",
                                 f"{record_id} 的 then 寫成提問「…{marker}…」，"
                                 "但 then 必須是看得到的結果。做法是先依仲裁規則挑一方，"
                                 "寫出那一方的具體可判定結果，再掛 blocked 與 CONFLICT issue"
                                 "——blocked 標記的是「這個答案還沒定案」，"
                                 "不是「寫不出結果」")
                    break
        blocked = record.get("blocked")
        if blocked is None:
            report.error("AC_BLOCKED", f"{record_id} 缺少 blocked（沒被擋就填空陣列）")
        else:
            check_refs(report, record_id, "blocked", blocked, iss_ids, "待確認事項")
            if blocked:
                blocked_acs.add(record_id)

    # ---- tests ----
    tests_by_ac = defaultdict(list)
    for record in as_list(data.get("tests")):
        if not isinstance(record, dict):
            continue
        record_id = record.get("id", "?")
        check_refs(report, record_id, "ac", record.get("ac"), ac_ids, "驗收條件", required=True)
        for ac_id in as_list(record.get("ac")):
            tests_by_ac[ac_id].append(record)
            if ac_id in blocked_acs and is_live(record):
                report.error("TEST_ON_BLOCKED",
                             f"{record_id} 掛在被 issue 擋住的 {ac_id} 上；"
                             "被擋的驗收條件不展開測試案例，讓缺口留著")
        title = record.get("title")
        if not isinstance(title, str) or not title.strip():
            report.error("TEST_TITLE", f"{record_id} 缺少 title")
        if record.get("type") not in TEST_TYPES:
            report.error("TEST_TYPE",
                         f"{record_id} 的 type「{record.get('type')}」不在 "
                         + "/".join(sorted(TEST_TYPES)) + " 之中")
        check_strings(report, record_id, "setup", record.get("setup"))
        check_strings(report, record_id, "steps", record.get("steps"))
        check_strings(report, record_id, "expected", record.get("expected"))

        risk = record.get("risk")
        if not isinstance(risk, dict):
            report.error("RISK_MISSING", f"{record_id} 缺少 risk 物件")
        else:
            impact, likelihood = risk.get("impact"), risk.get("likelihood")
            if impact not in RISK_SIDES or likelihood not in RISK_SIDES:
                report.error("RISK_AXES",
                             f"{record_id} 的 impact 與 likelihood 都必須是 High 或 Low")
            else:
                expected_level = RISK_LEVEL[(impact, likelihood)]
                if risk.get("level") != expected_level:
                    report.error("RISK_LEVEL",
                                 f"{record_id} 的 level 應為 {expected_level}"
                                 f"（impact={impact}, likelihood={likelihood}），"
                                 f"實際是 {risk.get('level')}")
            why = risk.get("why")
            if not isinstance(why, str) or not why.strip():
                report.error("RISK_WHY", f"{record_id} 的 risk.why 不可為空")
            else:
                for marker in TEMPLATE_MARKERS:
                    if marker in why:
                        report.error("TEMPLATE",
                                     f"{record_id} 的 risk.why 出現樣板句「{marker}」")

    check_echo(report, data)
    check_repeats(report, data)
    check_shapes(report, data)
    check_trace(report, data)
    check_risk_spread(report, data)
    check_dimensions(report, data, is_live)

    # ---- issues ----
    for record in as_list(data.get("issues")):
        if not isinstance(record, dict):
            continue
        record_id = record.get("id", "?")
        if record.get("type") not in ISSUE_TYPES:
            report.error("ISSUE_TYPE",
                         f"{record_id} 的 type「{record.get('type')}」不在 "
                         + "/".join(sorted(ISSUE_TYPES)) + " 之中")
        text = record.get("text")
        if not isinstance(text, str) or not text.strip():
            report.error("ISSUE_TEXT", f"{record_id} 缺少 text")
        elif len(text.strip()) < 20:
            report.warn("ISSUE_THIN",
                        f"{record_id} 的 text 太短，必須寫清楚各方分別怎麼說：{text}")
        check_refs(report, record_id, "docs", record.get("docs"), doc_ids, "文件", required=True)
        check_refs(report, record_id, "refs", record.get("refs"), set(owner_of), "記錄")
        if record.get("owner") not in OWNERS:
            report.error("ISSUE_OWNER",
                         f"{record_id} 的 owner「{record.get('owner')}」不在 "
                         + "/".join(sorted(OWNERS)) + " 之中")

    # ---- 覆蓋率 ----
    live_reqs = [r for r in as_list(data.get("requirements"))
                 if isinstance(r, dict) and is_live(r)]
    live_acs = [r for r in as_list(data.get("criteria"))
                if isinstance(r, dict) and is_live(r)]
    live_tests = [r for r in as_list(data.get("tests"))
                  if isinstance(r, dict) and is_live(r)]

    reqs_with_ac = set()
    for record in live_acs:
        reqs_with_ac.update(as_list(record.get("req")))
    for record in live_reqs:
        if record.get("id") not in reqs_with_ac:
            report.error("REQ_UNCOVERED",
                         f"{record.get('id')} 沒有任何驗收條件。"
                         "每條需求至少一條；寫不出可判定結果的，"
                         "該記 issue 並讓驗收條件 blocked，而不是讓需求懸空")

    if live_reqs and len(live_acs) / len(live_reqs) < 1.0:
        report.error("AC_PER_REQ",
                     f"驗收條件／需求 = {len(live_acs) / len(live_reqs):.2f} < 1.00"
                     f"（{len(live_acs)} 條驗收條件對 {len(live_reqs)} 條需求）。"
                     "每條需求至少一條驗收條件，比值低於 1 代表需求切得過細、"
                     "或該合併的沒合併，回頭做需求正規化")

    known_gaps = 0
    single_test_acs = 0
    for record in live_acs:
        record_id = record.get("id")
        covering = [t for t in tests_by_ac.get(record_id, []) if is_live(t)]
        if record_id in blocked_acs:
            known_gaps += 1
            continue
        if not covering:
            report.warn("AC_UNCOVERED",
                        f"{record_id} 沒有任何測試案例（若是被 issue 擋住，請填 blocked）")
        elif len(covering) == 1:
            single_test_acs += 1
            reason = looks_multi_dimensional(record)
            if reason:
                report.warn("ONE_TO_ONE",
                            f"{record_id} {reason}，卻只有一條測試案例 "
                            f"{covering[0].get('id')}，請照展開矩陣重新檢查")

    check_negative_coverage(report, tests_by_ac, data, blocked_acs, is_live)

    testable = len(live_acs) - known_gaps
    if testable >= 5 and single_test_acs / testable >= FLAT_RATIO:
        report.warn("EXPANSION_FLAT",
                    f"{single_test_acs}/{testable} 條可測的驗收條件"
                    f"（{single_test_acs / testable:.0%}）只有一條測試案例，"
                    "整體看起來沒有真的展開。一條驗收條件通常對應多條測試案例，"
                    "請逐條回頭套展開矩陣")

    if live_acs and len(live_acs) >= 20:
        ratio = len(live_tests) / len(live_acs)
        if ratio < TC_PER_AC_FLOOR:
            report.warn("TC_PER_AC",
                        f"測試案例／驗收條件 = {ratio:.2f} < {TC_PER_AC_FLOOR}"
                        f"（{len(live_tests)} 條測試案例對 {len(live_acs)} 條驗收條件）。"
                        "測試案例數量應該明顯多於驗收條件，貼著一比一就是沒有真的"
                        "套展開矩陣，回到步驟 7 逐條把八個維度過一遍")

    if live_acs and len(live_acs) >= 20:
        block_ratio = known_gaps / len(live_acs)
        detail = (f"{known_gaps}/{len(live_acs)} 條驗收條件（{block_ratio:.0%}）"
                  "被 issue 擋住而不展開測試案例")
        if block_ratio >= BLOCK_ERROR_RATIO:
            report.error("BLOCK_HEAVY",
                         detail + "。這代表把「有衝突」直接當成「擋住」了。"
                         "跨層矛盾的正確處理是依仲裁規則挑一方寫出可判定的 then、"
                         "記 CONFLICT issue、照常展開測試案例；"
                         "blocked 只留給仲裁後任一方都給不出可觀察結果的情況")
        elif block_ratio >= BLOCK_WARN_RATIO:
            report.warn("BLOCK_HEAVY",
                        detail + "。請逐條確認是真的仲裁後仍無可觀察結果，"
                        "還是只是有 CONFLICT 就直接擋掉")

    # ---- 報告 ----
    print(f"spec-to-tests 檢查報告：{path}")
    print()
    print("統計")
    print(f"  文件 {len(as_list(data.get('docs')))}"
          f"｜需求 {len(live_reqs)}"
          f"｜驗收條件 {len(live_acs)}"
          f"｜測試案例 {len(live_tests)}"
          f"｜待確認 {len(as_list(data.get('issues')))}")
    if live_reqs:
        print(f"  驗收條件／需求 = {len(live_acs) / len(live_reqs):.2f}")
    if live_acs:
        print(f"  測試案例／驗收條件 = {len(live_tests) / len(live_acs):.2f}")
    extracted = len(extracted_origins(data))
    if assets:
        total_ids, hit_all, scope_ids, hit_scope = assets
        print(f"  從文件萃取（有 from）：{extracted} 筆，"
              f"對應到文件裡 {hit_all}/{total_ids} 筆現成資產"
              f"（其中 PRD／SRS {hit_scope}/{scope_ids}）")
    else:
        print(f"  從文件萃取（有 from）：{extracted} 筆")
    print(f"  已知缺口（被 issue 擋住的驗收條件）：{known_gaps}")
    if has_change:
        counts = defaultdict(int)
        for collection in COLLECTIONS:
            for record in as_list(data.get(collection)):
                if isinstance(record, dict) and record.get("change"):
                    counts[record["change"]] += 1
        print("  變更：" + "｜".join(f"{k} {v}" for k, v in sorted(counts.items())))

    for label, items in (("錯誤", report.errors), ("警告", report.warnings)):
        print()
        print(f"{label} ({len(items)})")
        if not items:
            print("  無")
            continue
        grouped = defaultdict(list)
        for code, message in items:
            grouped[code].append(message)
        for code in sorted(grouped, key=lambda c: (-len(grouped[c]), c)):
            messages = grouped[code]
            for message in messages[:MAX_PER_CODE]:
                print(f"  [{code}] {message}")
            if len(messages) > MAX_PER_CODE:
                print(f"  [{code}] … 另有 {len(messages) - MAX_PER_CODE} 筆同類，修法一樣")

    print()
    print("通過" if not report.errors else "未通過：請先清掉全部錯誤")
    return 1 if report.errors else 0


if __name__ == "__main__":
    sys.exit(main())
