# 增量重跑

只在使用者提供 baseline（上一版 `testcases.json`）時才需要讀這份。首次產生不套用任何本文規則，也不要寫 `change`／`changed`／`was` 欄位。

## 流程

1. 讀入 baseline，建立 `id → 記錄` 索引，並記下每個 KIND 的最大序號。
2. 照常跑一次完整流程產出新內容，但**先不配發 ID**。
3. 把新內容逐筆與 baseline 比對身分（見下）。
4. 對上的沿用 baseline 的 ID；對不上的取該 KIND 最大序號 +1。
5. 逐筆標 `change`。
6. 新檔的 `baseline` 欄位填 baseline 的 `generatedAt`。

## 身分比對

主鍵是 `src`（文件 ID + 章節標題）。同一份文件的同一章節、講同一件事的，視為同一筆。

`src` 對不上時，退而比對語意：`text`（需求）或 `given`／`when`／`then` 三元組（驗收條件）或 `title` + `type`（測試案例）。

三種都對不上就是新項目。

**章節改名、文件改版號、路徑搬移都不算新項目**——文件的 `path` 或版號變了，`docs` 記錄照樣沿用原 `STT-DOC-NNN`，只更新 `path`。

## change 標註

| 值 | 中文 | 何時用 |
| --- | --- | --- |
| `ADDED` | 新增 | baseline 裡沒有這筆 |
| `MODIFIED` | 修改 | 對得上但內容有變 |
| `REMOVED` | 移除 | baseline 有、但來源文件已刪除該規則 |
| `UNCHANGED` | 未變更 | 對得上且內容完全相同 |

每一筆記錄都要有 `change`，四種之一，不可省略。

### MODIFIED

加 `changed` 列出變動的欄位名：

```json
{ "id": "STT-AC-004", "change": "MODIFIED", "changed": ["then", "src"], "...": "..." }
```

只比對實質欄位。ID、`change` 自身、以及純粹的排序變動不算變更。

### REMOVED

保留整筆記錄，只把 `change` 標成 `REMOVED`，不要從檔案刪掉——ID 要留著避免被重用。`REMOVED` 的記錄不列入覆蓋率分母，`check.py` 會自動排除。

一筆需求被標 `REMOVED` 時，掛在它底下的驗收條件與測試案例也要一起標 `REMOVED`。

**`REMOVED` 是給「來源文件刪掉了這條規則」用的，不是給「我這次沒寫出同一條」用的。** 最常見的失敗是照常重跑一次完整流程、卻跳過第 3 步的身分比對，於是新產出的每一筆都變成 `ADDED`、baseline 的每一筆都變成 `REMOVED`，整份看起來像重寫。判準很直接：**文件沒改版，就不該有大量 `REMOVED`，也不該一筆 `UNCHANGED` 都沒有**——`check.py` 會用 `RERUN_WIPE` 擋（docs 全是 `UNCHANGED`／只有 `path` 變，而 `REMOVED` 超過三成或 `UNCHANGED` 掛零時報錯）。對不上就照下面「對不上時」記 `AMBIGUOUS`，不要判死。

`REMOVED` 的記錄也不算萃取。把 baseline 整批留成 `REMOVED` 不會讓萃取覆蓋率變好看——`check.py` 只統計存活記錄的 `from`。

### 拆分與合併

不另設狀態。用 `MODIFIED` 加 `was` 表達來源：

- **拆分**：baseline 的 `STT-REQ-007` 這一版拆成兩條規則。原 ID 留給其中語意最接近的一條並標 `MODIFIED`；另一條取新 ID、標 `ADDED`，兩條都加 `was: ["STT-REQ-007"]`。
- **合併**：baseline 的 `STT-REQ-011` 與 `STT-REQ-012` 併成一條。保留其中一個 ID 標 `MODIFIED` 並加 `was: ["STT-REQ-011", "STT-REQ-012"]`；另一個標 `REMOVED`。

### 對不上時

新舊之間找不出明確對應關係（例如整章重寫，看不出哪條對哪條）時，不要硬猜：

- 該筆先當 `ADDED` 配發新 ID。
- 記一則 `AMBIGUOUS` issue，`refs` 放候選的 baseline ID 與這筆新 ID，`text` 說明為什麼對不上，`owner` 通常是 `SA`。
- 舊的那幾筆維持原狀等人裁決，先不要標 `REMOVED`。

## 回報

重跑結束後，除了一般統計，另外告訴使用者：

- 各 change 狀態的筆數
- 新增與移除的具體項目
- 這次產生的 `AMBIGUOUS` issue（需要人裁決才能收斂）
