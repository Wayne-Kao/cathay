# 輸出格式：testcases.json

## 目錄

- [整體結構](#整體結構)
- [ID 規則](#id-規則)
- [docs](#docs)
- [requirements](#requirements)
- [criteria](#criteria)
- [tests](#tests)
- [issues](#issues)
- [重跑時才出現的欄位](#重跑時才出現的欄位)
- [完整範例](#完整範例)

## 整體結構

輸出單一 JSON 檔，預設檔名 `testcases.json`，放在被分析文件的共同根目錄。

```json
{
  "project": "EPROZ00200",
  "generatedAt": "2026-08-21T10:00:00+08:00",
  "baseline": null,
  "docs": [],
  "requirements": [],
  "criteria": [],
  "tests": [],
  "issues": []
}
```

- `project`：模組或專案代號，取自文件本身的功能代號，不要自創。
- `generatedAt`：ISO 8601 含時區。
- `baseline`：首次產生填 `null`；重跑時填上一版的 `generatedAt`。
- 六個集合都必須存在，即使是空陣列。不要新增其他根層欄位。

## ID 規則

統一格式 `STT-<KIND>-<NNN>`，正規式 `^STT-(DOC|REQ|AC|TC|ISS)-\d{3,}$`。

| KIND | 集合 |
| --- | --- |
| `DOC` | `docs` |
| `REQ` | `requirements` |
| `AC` | `criteria` |
| `TC` | `tests` |
| `ISS` | `issues` |

- 序號三位起跳、不足補零，各 KIND 內從 001 起連續配發。
- 一旦配發永不重用。重跑時新項目取該 KIND 現有最大序號 +1。
- **`DOC` 的配發順序固定**：先 `BIBLE`、再 `PRD`、再 `SRS`、最後 `OTHER`，同型別內按 `path` 字串排序。順序隨機的話，同一批文件在不同機器或不同次執行會拿到不同的 DOC ID，重跑比對時整份 `src` 都會對不上 baseline。`check.py` 用 `DOC_ORDER` 檢查這件事。
- `STT` 前綴讓輸出編號一眼可辨。**來源文件自己的編號（`TC-001`、`AC-BIBLE-001`、`SIT-BIBLE-001`、`TBD-003`、`Q-001`、`REQ-XXX-001` 等）永遠只出現在 `from` 欄位**，不得當成本檔的 `id`，也不得混進 `req`／`ac`／`refs` 等參照欄位。

## docs

| 欄位 | 型別 | 說明 |
| --- | --- | --- |
| `id` | string | `STT-DOC-NNN` |
| `path` | string | 相對於輸出檔所在目錄的實際路徑，照磁碟上的檔名寫 |
| `type` | enum | `BIBLE`｜`PRD`｜`SRS`｜`OTHER` |

`path` 的三條硬性要求，`check.py` 會逐條驗：

- **一律用正斜線 `/`**，Windows 上跑也一樣。反斜線會讓輸出綁死在單一作業系統上（`DOC_PATH_SEP`）。
- **不從功能代號或別份文件的引用去拼**。目錄名跟模組代號常常長得像卻不同（例如目錄叫 `ERPOZ00200`、模組代號是 `EPROZ00200`），拼錯了整份追溯就斷了。
- **寫完先確認檔案存在**（`ls -1 <path>`）。找不到就是 `DOC_PATH_MISSING` 錯誤。

## requirements

| 欄位 | 型別 | 說明 |
| --- | --- | --- |
| `id` | string | `STT-REQ-NNN` |
| `text` | string | 單一可驗證的斷言。一句話塞多個規則要拆成多筆 |
| `src` | string[] | 每筆格式 `STT-DOC-NNN#章節標題`，同一需求出現在多份文件就收多筆 |
| `from` | string? | 來源文件的原始編號，有值代表這筆是萃取來的 |

## criteria

| 欄位 | 型別 | 說明 |
| --- | --- | --- |
| `id` | string | `STT-AC-NNN` |
| `req` | string[] | 對應的 `STT-REQ-NNN`，至少一筆 |
| `given` | string | 前置狀態與執行角色，寫具體 |
| `when` | string | 觸發動作 |
| `then` | string | 可觀察的結果：畫面顯示什麼／API 回什麼／哪張表哪個欄位變成什麼，三者至少一項。**不得寫成提問**（「需先確認是 00 還是 01」） |
| `src` | string[] | 同 requirements |
| `blocked` | string[] | 擋住這條的 `STT-ISS-NNN`；空陣列代表沒被擋 |
| `from` | string? | 來源文件的原始編號 |

`blocked` 非空的驗收條件**不展開測試案例**，讓缺口被看見。

但 `blocked` 標記的是「這個答案還沒定案」，不是「寫不出結果」——即使被擋住，`then` 仍要依仲裁規則寫出勝方的具體可判定結果，答案定案後直接解除即可。有 `CONFLICT` issue 不等於該 `blocked`；判準看 `method.md` 的「`blocked` 不等於「有衝突」」。

## tests

| 欄位 | 型別 | 說明 |
| --- | --- | --- |
| `id` | string | `STT-TC-NNN` |
| `ac` | string[] | 對應的 `STT-AC-NNN`，至少一筆 |
| `title` | string | 一句話講清楚這條在驗什麼 |
| `type` | enum | `happy`｜`boundary`｜`negative`｜`auth`｜`state`｜`txn`｜`concurrent`｜`integration`，同時就是展開維度 |
| `setup` | string[] | 前置狀態與測試資料，要有具體值或明確取值規則 |
| `steps` | string[] | 每步含執行者角色 + 具體操作 + 具體欄位或值 |
| `expected` | string[] | 具體的錯誤碼／訊息／欄位值，並講清楚在哪裡看得到 |
| `risk` | object | 見下 |
| `from` | string? | 來源文件的原始編號 |

### risk

| 欄位 | 說明 |
| --- | --- |
| `impact` | `High`｜`Low` |
| `likelihood` | `High`｜`Low` |
| `level` | 由矩陣推導，不可自填其他值 |
| `why` | 具體說明為何是這個等級：衝擊面一句、發生機率一句 |

推導矩陣：

| impact | likelihood | level |
| --- | --- | --- |
| High | High | `High` |
| High | Low | `Medium` |
| Low | High | `Medium` |
| Low | Low | `Low` |

判斷依據：`impact` 看失效後果——資金、案號唯一性、權限繞過、資料遺失、核心流程卡住算 High；顯示文字、排序、非關鍵欄位算 Low。`likelihood` 看觸發頻率與複雜度——黃金路徑必經、規則分支多、有併發或跨系統算 High；邊角情境、單純且被上游擋掉的算 Low。

來源文件若標了優先度（例如 SIT 矩陣的 P0／P1），映射成對應的 impact／likelihood，並在 `why` 註明來源標示。不另設 `priority` 欄位。

**分級要有鑑別度。** 兩軸都是二分，代表本來就該有相當比例落在 Low 側；如果幾乎每條都是 High，這個欄位就等於沒有作用——`check.py` 在 High 佔比 ≥ 70% 時報 `RISK_SKEW` 警告。實務上常見的 Low 側落點：

| 情境 | 判 Low 的那一軸 |
| --- | --- |
| 驗欄位標題、選項顯示文字、排序、分頁筆數 | `impact` Low |
| 非關鍵欄位的預設值帶入 | `impact` Low |
| 已被上游前端擋掉、只在直呼 API 時才會發生 | `likelihood` Low |
| 單一等價類的邊界值、規則單純沒有分支 | `likelihood` Low |

`why` 要一句講衝擊面、一句講發生機率，而且是**針對這一條**。八成的測試案例套同一段 `why`，會被 `TEMPLATE_REPEAT` 擋下來。

## issues

| 欄位 | 型別 | 說明 |
| --- | --- | --- |
| `id` | string | `STT-ISS-NNN` |
| `type` | enum | `CONFLICT`｜`PENDING`｜`AMBIGUOUS`｜`UNVERIFIABLE`｜`GAP` |
| `text` | string | 必須寫清楚各方分別怎麼說，不能只寫「有衝突」 |
| `docs` | string[] | 相關的 `STT-DOC-NNN` |
| `refs` | string[] | 相關的 REQ／AC／TC ID，可空 |
| `owner` | enum | `PM`｜`SA`｜`RD`｜`QA`｜`OPS` |
| `from` | string? | 來源文件的原始編號，例如 `TBD-003`、`Q-004`；有值代表這則是文件自己已經列出的待確認項 |

## 重跑時才出現的欄位

首次產生**不要寫**這些欄位。只有帶 baseline 重跑時才加，細節見 `references/rerun.md`。

| 欄位 | 說明 |
| --- | --- |
| `change` | `ADDED` 新增｜`MODIFIED` 修改｜`REMOVED` 移除｜`UNCHANGED` 未變更 |
| `changed` | 只在 `MODIFIED` 時出現，列出變動的欄位名 |
| `was` | 拆分／合併時，指向 baseline 的來源 ID |

## 完整範例

```json
{
  "project": "EPROZ00200",
  "generatedAt": "2026-08-21T10:00:00+08:00",
  "baseline": null,
  "docs": [
    { "id": "STT-DOC-001", "path": "bible_v1.1.md", "type": "BIBLE" },
    { "id": "STT-DOC-002", "path": "共用模組/ERPOZ00200/PRD_v1.0.md", "type": "PRD" },
    { "id": "STT-DOC-005", "path": "共用模組/ERPOZ00200/前端系統規格書_v1.11_20260130.md", "type": "SRS" }
  ],
  "requirements": [
    {
      "id": "STT-REQ-001",
      "text": "僅 AO Assistant（001）與 AO（002）可執行新起案件作業。",
      "src": ["STT-DOC-005#作業說明"]
    }
  ],
  "criteria": [
    {
      "id": "STT-AC-001",
      "req": ["STT-REQ-001"],
      "given": "以 CR（003）角色登入且持有有效 session",
      "when": "直接呼叫新起案件 API",
      "then": "系統拒絕並回傳權限不足，案件相關資料表無新增資料",
      "src": ["STT-DOC-005#作業說明"],
      "blocked": []
    }
  ],
  "tests": [
    {
      "id": "STT-TC-001",
      "ac": ["STT-AC-001"],
      "title": "CR 角色直接呼叫建案 API 應被拒絕",
      "type": "auth",
      "setup": [
        "以 CR（003）角色登入取得有效 session",
        "備妥一組欄位完整且合法的建案參數：客戶類型 I、擔保別 S、產品代碼 02、Loan Type 01"
      ],
      "steps": [
        "以 CR 的 session 直接呼叫新起案件 API，帶入上述完整參數（不經過前端畫面）",
        "記下回應的處理結果代碼與訊息",
        "以該次請求的 APP_GEN_DATE 與 branch 條件查案件主檔與歷程表"
      ],
      "expected": [
        "API 回應為權限不足，不得回傳新的 APPLICATION_NO",
        "案件主檔、歷程表、案號序號表皆無新增資料",
        "前端即使隱藏了按鈕也不算通過，必須由 API 層擋下"
      ],
      "risk": {
        "impact": "High",
        "likelihood": "High",
        "level": "High",
        "why": "權限繞過會讓未授權角色建立案件並污染案號序號，後果嚴重；繞過前端直呼 API 是常見的實際攻擊與測試路徑，來源矩陣亦標為 P0。"
      },
      "from": "SIT-BIBLE-010"
    }
  ],
  "issues": [
    {
      "id": "STT-ISS-001",
      "type": "CONFLICT",
      "text": "建案歷程的 APP_PROCESS_CODE 三方說法不一：PRD 記 01，後端 SRS v1.5 記 00，Bible 則把 00 定義為新建案、01 定義為進件中。需確認建案當下應寫入哪一個值。",
      "docs": ["STT-DOC-001", "STT-DOC-002", "STT-DOC-003"],
      "refs": ["STT-REQ-026"],
      "owner": "SA"
    }
  ]
}
```
